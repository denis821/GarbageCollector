gdjs.LevelCode = {};
gdjs.LevelCode.GDGlassBoxObjects1_1final = [];

gdjs.LevelCode.GDGlassBoxObjects2_1final = [];

gdjs.LevelCode.GDOtherBoxObjects2_1final = [];

gdjs.LevelCode.GDPaperBoxObjects1_1final = [];

gdjs.LevelCode.GDPaperBoxObjects2_1final = [];

gdjs.LevelCode.GDPlasticBoxObjects1_1final = [];

gdjs.LevelCode.GDPlasticBoxObjects2_1final = [];

gdjs.LevelCode.GDwaste10Objects1_1final = [];

gdjs.LevelCode.GDwaste11Objects2_1final = [];

gdjs.LevelCode.GDwaste12Objects2_1final = [];

gdjs.LevelCode.GDwaste13Objects2_1final = [];

gdjs.LevelCode.GDwaste14Objects2_1final = [];

gdjs.LevelCode.GDwaste15Objects2_1final = [];

gdjs.LevelCode.GDwaste16Objects1_1final = [];

gdjs.LevelCode.GDwaste17Objects1_1final = [];

gdjs.LevelCode.GDwaste18Objects1_1final = [];

gdjs.LevelCode.GDwaste19Objects1_1final = [];

gdjs.LevelCode.GDwaste1Objects2_1final = [];

gdjs.LevelCode.GDwaste20Objects1_1final = [];

gdjs.LevelCode.GDwaste21Objects1_1final = [];

gdjs.LevelCode.GDwaste22Objects2_1final = [];

gdjs.LevelCode.GDwaste23Objects2_1final = [];

gdjs.LevelCode.GDwaste24Objects2_1final = [];

gdjs.LevelCode.GDwaste25Objects1_1final = [];

gdjs.LevelCode.GDwaste26Objects1_1final = [];

gdjs.LevelCode.GDwaste27Objects2_1final = [];

gdjs.LevelCode.GDwaste28Objects2_1final = [];

gdjs.LevelCode.GDwaste29Objects2_1final = [];

gdjs.LevelCode.GDwaste2Objects2_1final = [];

gdjs.LevelCode.GDwaste30Objects2_1final = [];

gdjs.LevelCode.GDwaste31Objects2_1final = [];

gdjs.LevelCode.GDwaste32Objects1_1final = [];

gdjs.LevelCode.GDwaste33Objects1_1final = [];

gdjs.LevelCode.GDwaste34Objects1_1final = [];

gdjs.LevelCode.GDwaste35Objects2_1final = [];

gdjs.LevelCode.GDwaste36Objects1_1final = [];

gdjs.LevelCode.GDwaste37Objects1_1final = [];

gdjs.LevelCode.GDwaste38Objects2_1final = [];

gdjs.LevelCode.GDwaste39Objects2_1final = [];

gdjs.LevelCode.GDwaste3Objects1_1final = [];

gdjs.LevelCode.GDwaste40Objects2_1final = [];

gdjs.LevelCode.GDwaste4Objects2_1final = [];

gdjs.LevelCode.GDwaste5Objects2_1final = [];

gdjs.LevelCode.GDwaste6Objects2_1final = [];

gdjs.LevelCode.GDwaste7Objects2_1final = [];

gdjs.LevelCode.GDwaste8Objects2_1final = [];

gdjs.LevelCode.GDwaste9Objects2_1final = [];

gdjs.LevelCode.GDPlasticBoxObjects1= [];
gdjs.LevelCode.GDPlasticBoxObjects2= [];
gdjs.LevelCode.GDPlasticBoxObjects3= [];
gdjs.LevelCode.GDPlasticBoxObjects4= [];
gdjs.LevelCode.GDGlassBoxObjects1= [];
gdjs.LevelCode.GDGlassBoxObjects2= [];
gdjs.LevelCode.GDGlassBoxObjects3= [];
gdjs.LevelCode.GDGlassBoxObjects4= [];
gdjs.LevelCode.GDPaperBoxObjects1= [];
gdjs.LevelCode.GDPaperBoxObjects2= [];
gdjs.LevelCode.GDPaperBoxObjects3= [];
gdjs.LevelCode.GDPaperBoxObjects4= [];
gdjs.LevelCode.GDOtherBoxObjects1= [];
gdjs.LevelCode.GDOtherBoxObjects2= [];
gdjs.LevelCode.GDOtherBoxObjects3= [];
gdjs.LevelCode.GDOtherBoxObjects4= [];
gdjs.LevelCode.GDScoreObjects1= [];
gdjs.LevelCode.GDScoreObjects2= [];
gdjs.LevelCode.GDScoreObjects3= [];
gdjs.LevelCode.GDScoreObjects4= [];
gdjs.LevelCode.GDArmObjects1= [];
gdjs.LevelCode.GDArmObjects2= [];
gdjs.LevelCode.GDArmObjects3= [];
gdjs.LevelCode.GDArmObjects4= [];
gdjs.LevelCode.GDPrevObjects1= [];
gdjs.LevelCode.GDPrevObjects2= [];
gdjs.LevelCode.GDPrevObjects3= [];
gdjs.LevelCode.GDPrevObjects4= [];
gdjs.LevelCode.GDStarObjects1= [];
gdjs.LevelCode.GDStarObjects2= [];
gdjs.LevelCode.GDStarObjects3= [];
gdjs.LevelCode.GDStarObjects4= [];
gdjs.LevelCode.GDBackGroundObjects1= [];
gdjs.LevelCode.GDBackGroundObjects2= [];
gdjs.LevelCode.GDBackGroundObjects3= [];
gdjs.LevelCode.GDBackGroundObjects4= [];
gdjs.LevelCode.GDLeftBoxObjects1= [];
gdjs.LevelCode.GDLeftBoxObjects2= [];
gdjs.LevelCode.GDLeftBoxObjects3= [];
gdjs.LevelCode.GDLeftBoxObjects4= [];
gdjs.LevelCode.GDRightBoxObjects1= [];
gdjs.LevelCode.GDRightBoxObjects2= [];
gdjs.LevelCode.GDRightBoxObjects3= [];
gdjs.LevelCode.GDRightBoxObjects4= [];
gdjs.LevelCode.GDSpeedValueObjects1= [];
gdjs.LevelCode.GDSpeedValueObjects2= [];
gdjs.LevelCode.GDSpeedValueObjects3= [];
gdjs.LevelCode.GDSpeedValueObjects4= [];
gdjs.LevelCode.GDCleanButtonObjects1= [];
gdjs.LevelCode.GDCleanButtonObjects2= [];
gdjs.LevelCode.GDCleanButtonObjects3= [];
gdjs.LevelCode.GDCleanButtonObjects4= [];
gdjs.LevelCode.GDLifeObjects1= [];
gdjs.LevelCode.GDLifeObjects2= [];
gdjs.LevelCode.GDLifeObjects3= [];
gdjs.LevelCode.GDLifeObjects4= [];
gdjs.LevelCode.GDwaste1Objects1= [];
gdjs.LevelCode.GDwaste1Objects2= [];
gdjs.LevelCode.GDwaste1Objects3= [];
gdjs.LevelCode.GDwaste1Objects4= [];
gdjs.LevelCode.GDwaste2Objects1= [];
gdjs.LevelCode.GDwaste2Objects2= [];
gdjs.LevelCode.GDwaste2Objects3= [];
gdjs.LevelCode.GDwaste2Objects4= [];
gdjs.LevelCode.GDwaste3Objects1= [];
gdjs.LevelCode.GDwaste3Objects2= [];
gdjs.LevelCode.GDwaste3Objects3= [];
gdjs.LevelCode.GDwaste3Objects4= [];
gdjs.LevelCode.GDwaste4Objects1= [];
gdjs.LevelCode.GDwaste4Objects2= [];
gdjs.LevelCode.GDwaste4Objects3= [];
gdjs.LevelCode.GDwaste4Objects4= [];
gdjs.LevelCode.GDwaste5Objects1= [];
gdjs.LevelCode.GDwaste5Objects2= [];
gdjs.LevelCode.GDwaste5Objects3= [];
gdjs.LevelCode.GDwaste5Objects4= [];
gdjs.LevelCode.GDwaste6Objects1= [];
gdjs.LevelCode.GDwaste6Objects2= [];
gdjs.LevelCode.GDwaste6Objects3= [];
gdjs.LevelCode.GDwaste6Objects4= [];
gdjs.LevelCode.GDwaste7Objects1= [];
gdjs.LevelCode.GDwaste7Objects2= [];
gdjs.LevelCode.GDwaste7Objects3= [];
gdjs.LevelCode.GDwaste7Objects4= [];
gdjs.LevelCode.GDwaste8Objects1= [];
gdjs.LevelCode.GDwaste8Objects2= [];
gdjs.LevelCode.GDwaste8Objects3= [];
gdjs.LevelCode.GDwaste8Objects4= [];
gdjs.LevelCode.GDwaste9Objects1= [];
gdjs.LevelCode.GDwaste9Objects2= [];
gdjs.LevelCode.GDwaste9Objects3= [];
gdjs.LevelCode.GDwaste9Objects4= [];
gdjs.LevelCode.GDwaste10Objects1= [];
gdjs.LevelCode.GDwaste10Objects2= [];
gdjs.LevelCode.GDwaste10Objects3= [];
gdjs.LevelCode.GDwaste10Objects4= [];
gdjs.LevelCode.GDwaste11Objects1= [];
gdjs.LevelCode.GDwaste11Objects2= [];
gdjs.LevelCode.GDwaste11Objects3= [];
gdjs.LevelCode.GDwaste11Objects4= [];
gdjs.LevelCode.GDwaste12Objects1= [];
gdjs.LevelCode.GDwaste12Objects2= [];
gdjs.LevelCode.GDwaste12Objects3= [];
gdjs.LevelCode.GDwaste12Objects4= [];
gdjs.LevelCode.GDwaste13Objects1= [];
gdjs.LevelCode.GDwaste13Objects2= [];
gdjs.LevelCode.GDwaste13Objects3= [];
gdjs.LevelCode.GDwaste13Objects4= [];
gdjs.LevelCode.GDwaste14Objects1= [];
gdjs.LevelCode.GDwaste14Objects2= [];
gdjs.LevelCode.GDwaste14Objects3= [];
gdjs.LevelCode.GDwaste14Objects4= [];
gdjs.LevelCode.GDwaste15Objects1= [];
gdjs.LevelCode.GDwaste15Objects2= [];
gdjs.LevelCode.GDwaste15Objects3= [];
gdjs.LevelCode.GDwaste15Objects4= [];
gdjs.LevelCode.GDwaste17Objects1= [];
gdjs.LevelCode.GDwaste17Objects2= [];
gdjs.LevelCode.GDwaste17Objects3= [];
gdjs.LevelCode.GDwaste17Objects4= [];
gdjs.LevelCode.GDwaste16Objects1= [];
gdjs.LevelCode.GDwaste16Objects2= [];
gdjs.LevelCode.GDwaste16Objects3= [];
gdjs.LevelCode.GDwaste16Objects4= [];
gdjs.LevelCode.GDwaste18Objects1= [];
gdjs.LevelCode.GDwaste18Objects2= [];
gdjs.LevelCode.GDwaste18Objects3= [];
gdjs.LevelCode.GDwaste18Objects4= [];
gdjs.LevelCode.GDwaste19Objects1= [];
gdjs.LevelCode.GDwaste19Objects2= [];
gdjs.LevelCode.GDwaste19Objects3= [];
gdjs.LevelCode.GDwaste19Objects4= [];
gdjs.LevelCode.GDwaste20Objects1= [];
gdjs.LevelCode.GDwaste20Objects2= [];
gdjs.LevelCode.GDwaste20Objects3= [];
gdjs.LevelCode.GDwaste20Objects4= [];
gdjs.LevelCode.GDwaste21Objects1= [];
gdjs.LevelCode.GDwaste21Objects2= [];
gdjs.LevelCode.GDwaste21Objects3= [];
gdjs.LevelCode.GDwaste21Objects4= [];
gdjs.LevelCode.GDwaste22Objects1= [];
gdjs.LevelCode.GDwaste22Objects2= [];
gdjs.LevelCode.GDwaste22Objects3= [];
gdjs.LevelCode.GDwaste22Objects4= [];
gdjs.LevelCode.GDwaste23Objects1= [];
gdjs.LevelCode.GDwaste23Objects2= [];
gdjs.LevelCode.GDwaste23Objects3= [];
gdjs.LevelCode.GDwaste23Objects4= [];
gdjs.LevelCode.GDwaste24Objects1= [];
gdjs.LevelCode.GDwaste24Objects2= [];
gdjs.LevelCode.GDwaste24Objects3= [];
gdjs.LevelCode.GDwaste24Objects4= [];
gdjs.LevelCode.GDwaste25Objects1= [];
gdjs.LevelCode.GDwaste25Objects2= [];
gdjs.LevelCode.GDwaste25Objects3= [];
gdjs.LevelCode.GDwaste25Objects4= [];
gdjs.LevelCode.GDwaste26Objects1= [];
gdjs.LevelCode.GDwaste26Objects2= [];
gdjs.LevelCode.GDwaste26Objects3= [];
gdjs.LevelCode.GDwaste26Objects4= [];
gdjs.LevelCode.GDwaste27Objects1= [];
gdjs.LevelCode.GDwaste27Objects2= [];
gdjs.LevelCode.GDwaste27Objects3= [];
gdjs.LevelCode.GDwaste27Objects4= [];
gdjs.LevelCode.GDwaste29Objects1= [];
gdjs.LevelCode.GDwaste29Objects2= [];
gdjs.LevelCode.GDwaste29Objects3= [];
gdjs.LevelCode.GDwaste29Objects4= [];
gdjs.LevelCode.GDwaste28Objects1= [];
gdjs.LevelCode.GDwaste28Objects2= [];
gdjs.LevelCode.GDwaste28Objects3= [];
gdjs.LevelCode.GDwaste28Objects4= [];
gdjs.LevelCode.GDwaste30Objects1= [];
gdjs.LevelCode.GDwaste30Objects2= [];
gdjs.LevelCode.GDwaste30Objects3= [];
gdjs.LevelCode.GDwaste30Objects4= [];
gdjs.LevelCode.GDwaste31Objects1= [];
gdjs.LevelCode.GDwaste31Objects2= [];
gdjs.LevelCode.GDwaste31Objects3= [];
gdjs.LevelCode.GDwaste31Objects4= [];
gdjs.LevelCode.GDwaste32Objects1= [];
gdjs.LevelCode.GDwaste32Objects2= [];
gdjs.LevelCode.GDwaste32Objects3= [];
gdjs.LevelCode.GDwaste32Objects4= [];
gdjs.LevelCode.GDwaste33Objects1= [];
gdjs.LevelCode.GDwaste33Objects2= [];
gdjs.LevelCode.GDwaste33Objects3= [];
gdjs.LevelCode.GDwaste33Objects4= [];
gdjs.LevelCode.GDwaste34Objects1= [];
gdjs.LevelCode.GDwaste34Objects2= [];
gdjs.LevelCode.GDwaste34Objects3= [];
gdjs.LevelCode.GDwaste34Objects4= [];
gdjs.LevelCode.GDwaste35Objects1= [];
gdjs.LevelCode.GDwaste35Objects2= [];
gdjs.LevelCode.GDwaste35Objects3= [];
gdjs.LevelCode.GDwaste35Objects4= [];
gdjs.LevelCode.GDwaste36Objects1= [];
gdjs.LevelCode.GDwaste36Objects2= [];
gdjs.LevelCode.GDwaste36Objects3= [];
gdjs.LevelCode.GDwaste36Objects4= [];
gdjs.LevelCode.GDwaste37Objects1= [];
gdjs.LevelCode.GDwaste37Objects2= [];
gdjs.LevelCode.GDwaste37Objects3= [];
gdjs.LevelCode.GDwaste37Objects4= [];
gdjs.LevelCode.GDwaste38Objects1= [];
gdjs.LevelCode.GDwaste38Objects2= [];
gdjs.LevelCode.GDwaste38Objects3= [];
gdjs.LevelCode.GDwaste38Objects4= [];
gdjs.LevelCode.GDwaste39Objects1= [];
gdjs.LevelCode.GDwaste39Objects2= [];
gdjs.LevelCode.GDwaste39Objects3= [];
gdjs.LevelCode.GDwaste39Objects4= [];
gdjs.LevelCode.GDwaste40Objects1= [];
gdjs.LevelCode.GDwaste40Objects2= [];
gdjs.LevelCode.GDwaste40Objects3= [];
gdjs.LevelCode.GDwaste40Objects4= [];
gdjs.LevelCode.GDSoundObjects1= [];
gdjs.LevelCode.GDSoundObjects2= [];
gdjs.LevelCode.GDSoundObjects3= [];
gdjs.LevelCode.GDSoundObjects4= [];

gdjs.LevelCode.conditionTrue_0 = {val:false};
gdjs.LevelCode.condition0IsTrue_0 = {val:false};
gdjs.LevelCode.condition1IsTrue_0 = {val:false};
gdjs.LevelCode.condition2IsTrue_0 = {val:false};
gdjs.LevelCode.condition3IsTrue_0 = {val:false};
gdjs.LevelCode.condition4IsTrue_0 = {val:false};
gdjs.LevelCode.conditionTrue_1 = {val:false};
gdjs.LevelCode.condition0IsTrue_1 = {val:false};
gdjs.LevelCode.condition1IsTrue_1 = {val:false};
gdjs.LevelCode.condition2IsTrue_1 = {val:false};
gdjs.LevelCode.condition3IsTrue_1 = {val:false};
gdjs.LevelCode.condition4IsTrue_1 = {val:false};
gdjs.LevelCode.conditionTrue_2 = {val:false};
gdjs.LevelCode.condition0IsTrue_2 = {val:false};
gdjs.LevelCode.condition1IsTrue_2 = {val:false};
gdjs.LevelCode.condition2IsTrue_2 = {val:false};
gdjs.LevelCode.condition3IsTrue_2 = {val:false};
gdjs.LevelCode.condition4IsTrue_2 = {val:false};


gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects1Objects = Hashtable.newFrom({"PlasticBox": gdjs.LevelCode.GDPlasticBoxObjects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects1Objects = Hashtable.newFrom({"GlassBox": gdjs.LevelCode.GDGlassBoxObjects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects1Objects = Hashtable.newFrom({"PaperBox": gdjs.LevelCode.GDPaperBoxObjects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects1Objects = Hashtable.newFrom({"OtherBox": gdjs.LevelCode.GDOtherBoxObjects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects1ObjectsGDgdjs_46LevelCode_46GDwaste2Objects1ObjectsGDgdjs_46LevelCode_46GDwaste3Objects1ObjectsGDgdjs_46LevelCode_46GDwaste4Objects1ObjectsGDgdjs_46LevelCode_46GDwaste5Objects1ObjectsGDgdjs_46LevelCode_46GDwaste6Objects1ObjectsGDgdjs_46LevelCode_46GDwaste7Objects1ObjectsGDgdjs_46LevelCode_46GDwaste8Objects1ObjectsGDgdjs_46LevelCode_46GDwaste9Objects1ObjectsGDgdjs_46LevelCode_46GDwaste10Objects1ObjectsGDgdjs_46LevelCode_46GDwaste11Objects1ObjectsGDgdjs_46LevelCode_46GDwaste12Objects1ObjectsGDgdjs_46LevelCode_46GDwaste13Objects1ObjectsGDgdjs_46LevelCode_46GDwaste14Objects1ObjectsGDgdjs_46LevelCode_46GDwaste15Objects1ObjectsGDgdjs_46LevelCode_46GDwaste17Objects1ObjectsGDgdjs_46LevelCode_46GDwaste18Objects1ObjectsGDgdjs_46LevelCode_46GDwaste19Objects1ObjectsGDgdjs_46LevelCode_46GDwaste16Objects1ObjectsGDgdjs_46LevelCode_46GDwaste20Objects1ObjectsGDgdjs_46LevelCode_46GDwaste21Objects1ObjectsGDgdjs_46LevelCode_46GDwaste22Objects1ObjectsGDgdjs_46LevelCode_46GDwaste23Objects1ObjectsGDgdjs_46LevelCode_46GDwaste24Objects1ObjectsGDgdjs_46LevelCode_46GDwaste25Objects1ObjectsGDgdjs_46LevelCode_46GDwaste26Objects1ObjectsGDgdjs_46LevelCode_46GDwaste27Objects1ObjectsGDgdjs_46LevelCode_46GDwaste29Objects1ObjectsGDgdjs_46LevelCode_46GDwaste30Objects1ObjectsGDgdjs_46LevelCode_46GDwaste31Objects1ObjectsGDgdjs_46LevelCode_46GDwaste32Objects1ObjectsGDgdjs_46LevelCode_46GDwaste33Objects1ObjectsGDgdjs_46LevelCode_46GDwaste34Objects1ObjectsGDgdjs_46LevelCode_46GDwaste35Objects1ObjectsGDgdjs_46LevelCode_46GDwaste36Objects1ObjectsGDgdjs_46LevelCode_46GDwaste37Objects1ObjectsGDgdjs_46LevelCode_46GDwaste38Objects1ObjectsGDgdjs_46LevelCode_46GDwaste39Objects1ObjectsGDgdjs_46LevelCode_46GDwaste40Objects1ObjectsGDgdjs_46LevelCode_46GDwaste28Objects1Objects = Hashtable.newFrom({"waste1": gdjs.LevelCode.GDwaste1Objects1, "waste2": gdjs.LevelCode.GDwaste2Objects1, "waste3": gdjs.LevelCode.GDwaste3Objects1, "waste4": gdjs.LevelCode.GDwaste4Objects1, "waste5": gdjs.LevelCode.GDwaste5Objects1, "waste6": gdjs.LevelCode.GDwaste6Objects1, "waste7": gdjs.LevelCode.GDwaste7Objects1, "waste8": gdjs.LevelCode.GDwaste8Objects1, "waste9": gdjs.LevelCode.GDwaste9Objects1, "waste10": gdjs.LevelCode.GDwaste10Objects1, "waste11": gdjs.LevelCode.GDwaste11Objects1, "waste12": gdjs.LevelCode.GDwaste12Objects1, "waste13": gdjs.LevelCode.GDwaste13Objects1, "waste14": gdjs.LevelCode.GDwaste14Objects1, "waste15": gdjs.LevelCode.GDwaste15Objects1, "waste17": gdjs.LevelCode.GDwaste17Objects1, "waste18": gdjs.LevelCode.GDwaste18Objects1, "waste19": gdjs.LevelCode.GDwaste19Objects1, "waste16": gdjs.LevelCode.GDwaste16Objects1, "waste20": gdjs.LevelCode.GDwaste20Objects1, "waste21": gdjs.LevelCode.GDwaste21Objects1, "waste22": gdjs.LevelCode.GDwaste22Objects1, "waste23": gdjs.LevelCode.GDwaste23Objects1, "waste24": gdjs.LevelCode.GDwaste24Objects1, "waste25": gdjs.LevelCode.GDwaste25Objects1, "waste26": gdjs.LevelCode.GDwaste26Objects1, "waste27": gdjs.LevelCode.GDwaste27Objects1, "waste29": gdjs.LevelCode.GDwaste29Objects1, "waste30": gdjs.LevelCode.GDwaste30Objects1, "waste31": gdjs.LevelCode.GDwaste31Objects1, "waste32": gdjs.LevelCode.GDwaste32Objects1, "waste33": gdjs.LevelCode.GDwaste33Objects1, "waste34": gdjs.LevelCode.GDwaste34Objects1, "waste35": gdjs.LevelCode.GDwaste35Objects1, "waste36": gdjs.LevelCode.GDwaste36Objects1, "waste37": gdjs.LevelCode.GDwaste37Objects1, "waste38": gdjs.LevelCode.GDwaste38Objects1, "waste39": gdjs.LevelCode.GDwaste39Objects1, "waste40": gdjs.LevelCode.GDwaste40Objects1, "waste28": gdjs.LevelCode.GDwaste28Objects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects1ObjectsGDgdjs_46LevelCode_46GDwaste2Objects1ObjectsGDgdjs_46LevelCode_46GDwaste3Objects1ObjectsGDgdjs_46LevelCode_46GDwaste4Objects1ObjectsGDgdjs_46LevelCode_46GDwaste5Objects1ObjectsGDgdjs_46LevelCode_46GDwaste6Objects1ObjectsGDgdjs_46LevelCode_46GDwaste7Objects1ObjectsGDgdjs_46LevelCode_46GDwaste8Objects1ObjectsGDgdjs_46LevelCode_46GDwaste9Objects1ObjectsGDgdjs_46LevelCode_46GDwaste10Objects1ObjectsGDgdjs_46LevelCode_46GDwaste11Objects1ObjectsGDgdjs_46LevelCode_46GDwaste12Objects1ObjectsGDgdjs_46LevelCode_46GDwaste13Objects1ObjectsGDgdjs_46LevelCode_46GDwaste14Objects1ObjectsGDgdjs_46LevelCode_46GDwaste15Objects1ObjectsGDgdjs_46LevelCode_46GDwaste17Objects1ObjectsGDgdjs_46LevelCode_46GDwaste18Objects1ObjectsGDgdjs_46LevelCode_46GDwaste19Objects1ObjectsGDgdjs_46LevelCode_46GDwaste16Objects1ObjectsGDgdjs_46LevelCode_46GDwaste20Objects1ObjectsGDgdjs_46LevelCode_46GDwaste21Objects1ObjectsGDgdjs_46LevelCode_46GDwaste22Objects1ObjectsGDgdjs_46LevelCode_46GDwaste23Objects1ObjectsGDgdjs_46LevelCode_46GDwaste24Objects1ObjectsGDgdjs_46LevelCode_46GDwaste25Objects1ObjectsGDgdjs_46LevelCode_46GDwaste26Objects1ObjectsGDgdjs_46LevelCode_46GDwaste27Objects1ObjectsGDgdjs_46LevelCode_46GDwaste29Objects1ObjectsGDgdjs_46LevelCode_46GDwaste30Objects1ObjectsGDgdjs_46LevelCode_46GDwaste31Objects1ObjectsGDgdjs_46LevelCode_46GDwaste32Objects1ObjectsGDgdjs_46LevelCode_46GDwaste33Objects1ObjectsGDgdjs_46LevelCode_46GDwaste34Objects1ObjectsGDgdjs_46LevelCode_46GDwaste35Objects1ObjectsGDgdjs_46LevelCode_46GDwaste36Objects1ObjectsGDgdjs_46LevelCode_46GDwaste37Objects1ObjectsGDgdjs_46LevelCode_46GDwaste38Objects1ObjectsGDgdjs_46LevelCode_46GDwaste39Objects1ObjectsGDgdjs_46LevelCode_46GDwaste40Objects1ObjectsGDgdjs_46LevelCode_46GDwaste28Objects1Objects = Hashtable.newFrom({"waste1": gdjs.LevelCode.GDwaste1Objects1, "waste2": gdjs.LevelCode.GDwaste2Objects1, "waste3": gdjs.LevelCode.GDwaste3Objects1, "waste4": gdjs.LevelCode.GDwaste4Objects1, "waste5": gdjs.LevelCode.GDwaste5Objects1, "waste6": gdjs.LevelCode.GDwaste6Objects1, "waste7": gdjs.LevelCode.GDwaste7Objects1, "waste8": gdjs.LevelCode.GDwaste8Objects1, "waste9": gdjs.LevelCode.GDwaste9Objects1, "waste10": gdjs.LevelCode.GDwaste10Objects1, "waste11": gdjs.LevelCode.GDwaste11Objects1, "waste12": gdjs.LevelCode.GDwaste12Objects1, "waste13": gdjs.LevelCode.GDwaste13Objects1, "waste14": gdjs.LevelCode.GDwaste14Objects1, "waste15": gdjs.LevelCode.GDwaste15Objects1, "waste17": gdjs.LevelCode.GDwaste17Objects1, "waste18": gdjs.LevelCode.GDwaste18Objects1, "waste19": gdjs.LevelCode.GDwaste19Objects1, "waste16": gdjs.LevelCode.GDwaste16Objects1, "waste20": gdjs.LevelCode.GDwaste20Objects1, "waste21": gdjs.LevelCode.GDwaste21Objects1, "waste22": gdjs.LevelCode.GDwaste22Objects1, "waste23": gdjs.LevelCode.GDwaste23Objects1, "waste24": gdjs.LevelCode.GDwaste24Objects1, "waste25": gdjs.LevelCode.GDwaste25Objects1, "waste26": gdjs.LevelCode.GDwaste26Objects1, "waste27": gdjs.LevelCode.GDwaste27Objects1, "waste29": gdjs.LevelCode.GDwaste29Objects1, "waste30": gdjs.LevelCode.GDwaste30Objects1, "waste31": gdjs.LevelCode.GDwaste31Objects1, "waste32": gdjs.LevelCode.GDwaste32Objects1, "waste33": gdjs.LevelCode.GDwaste33Objects1, "waste34": gdjs.LevelCode.GDwaste34Objects1, "waste35": gdjs.LevelCode.GDwaste35Objects1, "waste36": gdjs.LevelCode.GDwaste36Objects1, "waste37": gdjs.LevelCode.GDwaste37Objects1, "waste38": gdjs.LevelCode.GDwaste38Objects1, "waste39": gdjs.LevelCode.GDwaste39Objects1, "waste40": gdjs.LevelCode.GDwaste40Objects1, "waste28": gdjs.LevelCode.GDwaste28Objects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects1ObjectsGDgdjs_46LevelCode_46GDGlassBoxObjects1ObjectsGDgdjs_46LevelCode_46GDPaperBoxObjects1ObjectsGDgdjs_46LevelCode_46GDOtherBoxObjects1Objects = Hashtable.newFrom({"PlasticBox": gdjs.LevelCode.GDPlasticBoxObjects1, "GlassBox": gdjs.LevelCode.GDGlassBoxObjects1, "PaperBox": gdjs.LevelCode.GDPaperBoxObjects1, "OtherBox": gdjs.LevelCode.GDOtherBoxObjects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects1ObjectsGDgdjs_46LevelCode_46GDwaste2Objects1ObjectsGDgdjs_46LevelCode_46GDwaste3Objects1ObjectsGDgdjs_46LevelCode_46GDwaste4Objects1ObjectsGDgdjs_46LevelCode_46GDwaste5Objects1ObjectsGDgdjs_46LevelCode_46GDwaste6Objects1ObjectsGDgdjs_46LevelCode_46GDwaste7Objects1ObjectsGDgdjs_46LevelCode_46GDwaste8Objects1ObjectsGDgdjs_46LevelCode_46GDwaste9Objects1ObjectsGDgdjs_46LevelCode_46GDwaste10Objects1ObjectsGDgdjs_46LevelCode_46GDwaste11Objects1ObjectsGDgdjs_46LevelCode_46GDwaste12Objects1ObjectsGDgdjs_46LevelCode_46GDwaste13Objects1ObjectsGDgdjs_46LevelCode_46GDwaste14Objects1ObjectsGDgdjs_46LevelCode_46GDwaste15Objects1ObjectsGDgdjs_46LevelCode_46GDwaste17Objects1ObjectsGDgdjs_46LevelCode_46GDwaste18Objects1ObjectsGDgdjs_46LevelCode_46GDwaste19Objects1ObjectsGDgdjs_46LevelCode_46GDwaste16Objects1ObjectsGDgdjs_46LevelCode_46GDwaste20Objects1ObjectsGDgdjs_46LevelCode_46GDwaste21Objects1ObjectsGDgdjs_46LevelCode_46GDwaste22Objects1ObjectsGDgdjs_46LevelCode_46GDwaste23Objects1ObjectsGDgdjs_46LevelCode_46GDwaste24Objects1ObjectsGDgdjs_46LevelCode_46GDwaste25Objects1ObjectsGDgdjs_46LevelCode_46GDwaste26Objects1ObjectsGDgdjs_46LevelCode_46GDwaste27Objects1ObjectsGDgdjs_46LevelCode_46GDwaste29Objects1ObjectsGDgdjs_46LevelCode_46GDwaste30Objects1ObjectsGDgdjs_46LevelCode_46GDwaste31Objects1ObjectsGDgdjs_46LevelCode_46GDwaste32Objects1ObjectsGDgdjs_46LevelCode_46GDwaste33Objects1ObjectsGDgdjs_46LevelCode_46GDwaste34Objects1ObjectsGDgdjs_46LevelCode_46GDwaste35Objects1ObjectsGDgdjs_46LevelCode_46GDwaste36Objects1ObjectsGDgdjs_46LevelCode_46GDwaste37Objects1ObjectsGDgdjs_46LevelCode_46GDwaste38Objects1ObjectsGDgdjs_46LevelCode_46GDwaste39Objects1ObjectsGDgdjs_46LevelCode_46GDwaste40Objects1ObjectsGDgdjs_46LevelCode_46GDwaste28Objects1Objects = Hashtable.newFrom({"waste1": gdjs.LevelCode.GDwaste1Objects1, "waste2": gdjs.LevelCode.GDwaste2Objects1, "waste3": gdjs.LevelCode.GDwaste3Objects1, "waste4": gdjs.LevelCode.GDwaste4Objects1, "waste5": gdjs.LevelCode.GDwaste5Objects1, "waste6": gdjs.LevelCode.GDwaste6Objects1, "waste7": gdjs.LevelCode.GDwaste7Objects1, "waste8": gdjs.LevelCode.GDwaste8Objects1, "waste9": gdjs.LevelCode.GDwaste9Objects1, "waste10": gdjs.LevelCode.GDwaste10Objects1, "waste11": gdjs.LevelCode.GDwaste11Objects1, "waste12": gdjs.LevelCode.GDwaste12Objects1, "waste13": gdjs.LevelCode.GDwaste13Objects1, "waste14": gdjs.LevelCode.GDwaste14Objects1, "waste15": gdjs.LevelCode.GDwaste15Objects1, "waste17": gdjs.LevelCode.GDwaste17Objects1, "waste18": gdjs.LevelCode.GDwaste18Objects1, "waste19": gdjs.LevelCode.GDwaste19Objects1, "waste16": gdjs.LevelCode.GDwaste16Objects1, "waste20": gdjs.LevelCode.GDwaste20Objects1, "waste21": gdjs.LevelCode.GDwaste21Objects1, "waste22": gdjs.LevelCode.GDwaste22Objects1, "waste23": gdjs.LevelCode.GDwaste23Objects1, "waste24": gdjs.LevelCode.GDwaste24Objects1, "waste25": gdjs.LevelCode.GDwaste25Objects1, "waste26": gdjs.LevelCode.GDwaste26Objects1, "waste27": gdjs.LevelCode.GDwaste27Objects1, "waste29": gdjs.LevelCode.GDwaste29Objects1, "waste30": gdjs.LevelCode.GDwaste30Objects1, "waste31": gdjs.LevelCode.GDwaste31Objects1, "waste32": gdjs.LevelCode.GDwaste32Objects1, "waste33": gdjs.LevelCode.GDwaste33Objects1, "waste34": gdjs.LevelCode.GDwaste34Objects1, "waste35": gdjs.LevelCode.GDwaste35Objects1, "waste36": gdjs.LevelCode.GDwaste36Objects1, "waste37": gdjs.LevelCode.GDwaste37Objects1, "waste38": gdjs.LevelCode.GDwaste38Objects1, "waste39": gdjs.LevelCode.GDwaste39Objects1, "waste40": gdjs.LevelCode.GDwaste40Objects1, "waste28": gdjs.LevelCode.GDwaste28Objects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste6Objects2ObjectsGDgdjs_46LevelCode_46GDwaste7Objects2ObjectsGDgdjs_46LevelCode_46GDwaste8Objects2ObjectsGDgdjs_46LevelCode_46GDwaste12Objects2ObjectsGDgdjs_46LevelCode_46GDwaste24Objects2ObjectsGDgdjs_46LevelCode_46GDwaste29Objects2ObjectsGDgdjs_46LevelCode_46GDwaste30Objects2ObjectsGDgdjs_46LevelCode_46GDwaste31Objects2ObjectsGDgdjs_46LevelCode_46GDwaste39Objects2Objects = Hashtable.newFrom({"waste6": gdjs.LevelCode.GDwaste6Objects2, "waste7": gdjs.LevelCode.GDwaste7Objects2, "waste8": gdjs.LevelCode.GDwaste8Objects2, "waste12": gdjs.LevelCode.GDwaste12Objects2, "waste24": gdjs.LevelCode.GDwaste24Objects2, "waste29": gdjs.LevelCode.GDwaste29Objects2, "waste30": gdjs.LevelCode.GDwaste30Objects2, "waste31": gdjs.LevelCode.GDwaste31Objects2, "waste39": gdjs.LevelCode.GDwaste39Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects2Objects = Hashtable.newFrom({"PlasticBox": gdjs.LevelCode.GDPlasticBoxObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3Objects = Hashtable.newFrom({"waste7": gdjs.LevelCode.GDwaste7Objects3, "waste8": gdjs.LevelCode.GDwaste8Objects3, "waste29": gdjs.LevelCode.GDwaste29Objects3, "waste31": gdjs.LevelCode.GDwaste31Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects3Objects = Hashtable.newFrom({"PlasticBox": gdjs.LevelCode.GDPlasticBoxObjects3});gdjs.LevelCode.eventsList0 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects2, gdjs.LevelCode.GDPlasticBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects2, gdjs.LevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects2, gdjs.LevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects2, gdjs.LevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects2, gdjs.LevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects2, gdjs.LevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects2, gdjs.LevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects2, gdjs.LevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects2, gdjs.LevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects2, gdjs.LevelCode.GDwaste8Objects3);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.condition0IsTrue_1.val = false;
gdjs.LevelCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste6Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste6Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste6Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste6Objects3[k] = gdjs.LevelCode.GDwaste6Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste6Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste7Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste7Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste7Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste7Objects3[k] = gdjs.LevelCode.GDwaste7Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste7Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste8Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste8Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste8Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste8Objects3[k] = gdjs.LevelCode.GDwaste8Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste8Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste12Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste12Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste12Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste12Objects3[k] = gdjs.LevelCode.GDwaste12Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste12Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste24Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste24Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste24Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste24Objects3[k] = gdjs.LevelCode.GDwaste24Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste24Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste29Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste29Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste29Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste29Objects3[k] = gdjs.LevelCode.GDwaste29Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste29Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste30Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste30Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste30Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste30Objects3[k] = gdjs.LevelCode.GDwaste30Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste30Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste31Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste31Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste31Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste31Objects3[k] = gdjs.LevelCode.GDwaste31Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste31Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste39Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste39Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste39Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste39Objects3[k] = gdjs.LevelCode.GDwaste39Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste39Objects3.length = k;}if ( gdjs.LevelCode.condition0IsTrue_1.val ) {
{
gdjs.LevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects3Objects, false, runtimeScene, false);
}}
gdjs.LevelCode.conditionTrue_1.val = true && gdjs.LevelCode.condition0IsTrue_1.val && gdjs.LevelCode.condition1IsTrue_1.val;
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDScoreObjects2, gdjs.LevelCode.GDScoreObjects3);

{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.LevelCode.GDScoreObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDScoreObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}
}
{ //Subevents
gdjs.LevelCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste3Objects2ObjectsGDgdjs_46LevelCode_46GDwaste10Objects2ObjectsGDgdjs_46LevelCode_46GDwaste17Objects2ObjectsGDgdjs_46LevelCode_46GDwaste18Objects2ObjectsGDgdjs_46LevelCode_46GDwaste19Objects2ObjectsGDgdjs_46LevelCode_46GDwaste16Objects2ObjectsGDgdjs_46LevelCode_46GDwaste20Objects2ObjectsGDgdjs_46LevelCode_46GDwaste21Objects2ObjectsGDgdjs_46LevelCode_46GDwaste25Objects2ObjectsGDgdjs_46LevelCode_46GDwaste26Objects2ObjectsGDgdjs_46LevelCode_46GDwaste32Objects2ObjectsGDgdjs_46LevelCode_46GDwaste33Objects2ObjectsGDgdjs_46LevelCode_46GDwaste34Objects2ObjectsGDgdjs_46LevelCode_46GDwaste37Objects2ObjectsGDgdjs_46LevelCode_46GDwaste36Objects2Objects = Hashtable.newFrom({"waste3": gdjs.LevelCode.GDwaste3Objects2, "waste10": gdjs.LevelCode.GDwaste10Objects2, "waste17": gdjs.LevelCode.GDwaste17Objects2, "waste18": gdjs.LevelCode.GDwaste18Objects2, "waste19": gdjs.LevelCode.GDwaste19Objects2, "waste16": gdjs.LevelCode.GDwaste16Objects2, "waste20": gdjs.LevelCode.GDwaste20Objects2, "waste21": gdjs.LevelCode.GDwaste21Objects2, "waste25": gdjs.LevelCode.GDwaste25Objects2, "waste26": gdjs.LevelCode.GDwaste26Objects2, "waste32": gdjs.LevelCode.GDwaste32Objects2, "waste33": gdjs.LevelCode.GDwaste33Objects2, "waste34": gdjs.LevelCode.GDwaste34Objects2, "waste37": gdjs.LevelCode.GDwaste37Objects2, "waste36": gdjs.LevelCode.GDwaste36Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects2Objects = Hashtable.newFrom({"OtherBox": gdjs.LevelCode.GDOtherBoxObjects2});gdjs.LevelCode.eventsList2 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects2ObjectsGDgdjs_46LevelCode_46GDwaste4Objects2ObjectsGDgdjs_46LevelCode_46GDwaste9Objects2ObjectsGDgdjs_46LevelCode_46GDwaste11Objects2ObjectsGDgdjs_46LevelCode_46GDwaste15Objects2ObjectsGDgdjs_46LevelCode_46GDwaste22Objects2ObjectsGDgdjs_46LevelCode_46GDwaste38Objects2ObjectsGDgdjs_46LevelCode_46GDwaste40Objects2ObjectsGDgdjs_46LevelCode_46GDwaste5Objects2Objects = Hashtable.newFrom({"waste1": gdjs.LevelCode.GDwaste1Objects2, "waste4": gdjs.LevelCode.GDwaste4Objects2, "waste9": gdjs.LevelCode.GDwaste9Objects2, "waste11": gdjs.LevelCode.GDwaste11Objects2, "waste15": gdjs.LevelCode.GDwaste15Objects2, "waste22": gdjs.LevelCode.GDwaste22Objects2, "waste38": gdjs.LevelCode.GDwaste38Objects2, "waste40": gdjs.LevelCode.GDwaste40Objects2, "waste5": gdjs.LevelCode.GDwaste5Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects2Objects = Hashtable.newFrom({"PaperBox": gdjs.LevelCode.GDPaperBoxObjects2});gdjs.LevelCode.eventsList3 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste13Objects2ObjectsGDgdjs_46LevelCode_46GDwaste14Objects2ObjectsGDgdjs_46LevelCode_46GDwaste2Objects2ObjectsGDgdjs_46LevelCode_46GDwaste23Objects2ObjectsGDgdjs_46LevelCode_46GDwaste27Objects2ObjectsGDgdjs_46LevelCode_46GDwaste28Objects2ObjectsGDgdjs_46LevelCode_46GDwaste35Objects2Objects = Hashtable.newFrom({"waste13": gdjs.LevelCode.GDwaste13Objects2, "waste14": gdjs.LevelCode.GDwaste14Objects2, "waste2": gdjs.LevelCode.GDwaste2Objects2, "waste23": gdjs.LevelCode.GDwaste23Objects2, "waste27": gdjs.LevelCode.GDwaste27Objects2, "waste28": gdjs.LevelCode.GDwaste28Objects2, "waste35": gdjs.LevelCode.GDwaste35Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects2Objects = Hashtable.newFrom({"GlassBox": gdjs.LevelCode.GDGlassBoxObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste27Objects3Objects = Hashtable.newFrom({"waste27": gdjs.LevelCode.GDwaste27Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects3Objects = Hashtable.newFrom({"GlassBox": gdjs.LevelCode.GDGlassBoxObjects3});gdjs.LevelCode.eventsList4 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects2, gdjs.LevelCode.GDGlassBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects2, gdjs.LevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects2, gdjs.LevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects2, gdjs.LevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects2, gdjs.LevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects2, gdjs.LevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects2, gdjs.LevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects2, gdjs.LevelCode.GDwaste35Objects3);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.condition0IsTrue_1.val = false;
gdjs.LevelCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste13Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste13Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste13Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste13Objects3[k] = gdjs.LevelCode.GDwaste13Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste13Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste14Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste14Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste14Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste14Objects3[k] = gdjs.LevelCode.GDwaste14Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste14Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste2Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste2Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste2Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste2Objects3[k] = gdjs.LevelCode.GDwaste2Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste23Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste23Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste23Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste23Objects3[k] = gdjs.LevelCode.GDwaste23Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste23Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste27Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste27Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste27Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste27Objects3[k] = gdjs.LevelCode.GDwaste27Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste27Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste28Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste28Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste28Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste28Objects3[k] = gdjs.LevelCode.GDwaste28Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste28Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste35Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste35Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste35Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDwaste35Objects3[k] = gdjs.LevelCode.GDwaste35Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste35Objects3.length = k;}if ( gdjs.LevelCode.condition0IsTrue_1.val ) {
{
gdjs.LevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste27Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects3Objects, false, runtimeScene, false);
}}
gdjs.LevelCode.conditionTrue_1.val = true && gdjs.LevelCode.condition0IsTrue_1.val && gdjs.LevelCode.condition1IsTrue_1.val;
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDScoreObjects2, gdjs.LevelCode.GDScoreObjects3);

{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.LevelCode.GDScoreObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDScoreObjects3[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}
{ //Subevents
gdjs.LevelCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste6Objects3ObjectsGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste12Objects3ObjectsGDgdjs_46LevelCode_46GDwaste24Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste30Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3ObjectsGDgdjs_46LevelCode_46GDwaste39Objects3Objects = Hashtable.newFrom({"waste6": gdjs.LevelCode.GDwaste6Objects3, "waste7": gdjs.LevelCode.GDwaste7Objects3, "waste8": gdjs.LevelCode.GDwaste8Objects3, "waste12": gdjs.LevelCode.GDwaste12Objects3, "waste24": gdjs.LevelCode.GDwaste24Objects3, "waste29": gdjs.LevelCode.GDwaste29Objects3, "waste30": gdjs.LevelCode.GDwaste30Objects3, "waste31": gdjs.LevelCode.GDwaste31Objects3, "waste39": gdjs.LevelCode.GDwaste39Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects3Objects = Hashtable.newFrom({"GlassBox": gdjs.LevelCode.GDGlassBoxObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste6Objects3ObjectsGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste12Objects3ObjectsGDgdjs_46LevelCode_46GDwaste24Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste30Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3ObjectsGDgdjs_46LevelCode_46GDwaste39Objects3Objects = Hashtable.newFrom({"waste6": gdjs.LevelCode.GDwaste6Objects3, "waste7": gdjs.LevelCode.GDwaste7Objects3, "waste8": gdjs.LevelCode.GDwaste8Objects3, "waste12": gdjs.LevelCode.GDwaste12Objects3, "waste24": gdjs.LevelCode.GDwaste24Objects3, "waste29": gdjs.LevelCode.GDwaste29Objects3, "waste30": gdjs.LevelCode.GDwaste30Objects3, "waste31": gdjs.LevelCode.GDwaste31Objects3, "waste39": gdjs.LevelCode.GDwaste39Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects3Objects = Hashtable.newFrom({"PaperBox": gdjs.LevelCode.GDPaperBoxObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste6Objects3ObjectsGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste12Objects3ObjectsGDgdjs_46LevelCode_46GDwaste24Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste30Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3ObjectsGDgdjs_46LevelCode_46GDwaste39Objects3Objects = Hashtable.newFrom({"waste6": gdjs.LevelCode.GDwaste6Objects3, "waste7": gdjs.LevelCode.GDwaste7Objects3, "waste8": gdjs.LevelCode.GDwaste8Objects3, "waste12": gdjs.LevelCode.GDwaste12Objects3, "waste24": gdjs.LevelCode.GDwaste24Objects3, "waste29": gdjs.LevelCode.GDwaste29Objects3, "waste30": gdjs.LevelCode.GDwaste30Objects3, "waste31": gdjs.LevelCode.GDwaste31Objects3, "waste39": gdjs.LevelCode.GDwaste39Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects3Objects = Hashtable.newFrom({"OtherBox": gdjs.LevelCode.GDOtherBoxObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3Objects = Hashtable.newFrom({"waste7": gdjs.LevelCode.GDwaste7Objects3, "waste8": gdjs.LevelCode.GDwaste8Objects3, "waste29": gdjs.LevelCode.GDwaste29Objects3, "waste31": gdjs.LevelCode.GDwaste31Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects3Objects = Hashtable.newFrom({"PlasticBox": gdjs.LevelCode.GDPlasticBoxObjects3});gdjs.LevelCode.eventsList6 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt man 05.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste13Objects3ObjectsGDgdjs_46LevelCode_46GDwaste14Objects3ObjectsGDgdjs_46LevelCode_46GDwaste2Objects3ObjectsGDgdjs_46LevelCode_46GDwaste23Objects3ObjectsGDgdjs_46LevelCode_46GDwaste27Objects3ObjectsGDgdjs_46LevelCode_46GDwaste28Objects3ObjectsGDgdjs_46LevelCode_46GDwaste35Objects3Objects = Hashtable.newFrom({"waste13": gdjs.LevelCode.GDwaste13Objects3, "waste14": gdjs.LevelCode.GDwaste14Objects3, "waste2": gdjs.LevelCode.GDwaste2Objects3, "waste23": gdjs.LevelCode.GDwaste23Objects3, "waste27": gdjs.LevelCode.GDwaste27Objects3, "waste28": gdjs.LevelCode.GDwaste28Objects3, "waste35": gdjs.LevelCode.GDwaste35Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects3Objects = Hashtable.newFrom({"PlasticBox": gdjs.LevelCode.GDPlasticBoxObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste13Objects3ObjectsGDgdjs_46LevelCode_46GDwaste14Objects3ObjectsGDgdjs_46LevelCode_46GDwaste2Objects3ObjectsGDgdjs_46LevelCode_46GDwaste23Objects3ObjectsGDgdjs_46LevelCode_46GDwaste27Objects3ObjectsGDgdjs_46LevelCode_46GDwaste28Objects3ObjectsGDgdjs_46LevelCode_46GDwaste35Objects3Objects = Hashtable.newFrom({"waste13": gdjs.LevelCode.GDwaste13Objects3, "waste14": gdjs.LevelCode.GDwaste14Objects3, "waste2": gdjs.LevelCode.GDwaste2Objects3, "waste23": gdjs.LevelCode.GDwaste23Objects3, "waste27": gdjs.LevelCode.GDwaste27Objects3, "waste28": gdjs.LevelCode.GDwaste28Objects3, "waste35": gdjs.LevelCode.GDwaste35Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects3Objects = Hashtable.newFrom({"PaperBox": gdjs.LevelCode.GDPaperBoxObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste13Objects3ObjectsGDgdjs_46LevelCode_46GDwaste14Objects3ObjectsGDgdjs_46LevelCode_46GDwaste2Objects3ObjectsGDgdjs_46LevelCode_46GDwaste23Objects3ObjectsGDgdjs_46LevelCode_46GDwaste27Objects3ObjectsGDgdjs_46LevelCode_46GDwaste28Objects3ObjectsGDgdjs_46LevelCode_46GDwaste35Objects3Objects = Hashtable.newFrom({"waste13": gdjs.LevelCode.GDwaste13Objects3, "waste14": gdjs.LevelCode.GDwaste14Objects3, "waste2": gdjs.LevelCode.GDwaste2Objects3, "waste23": gdjs.LevelCode.GDwaste23Objects3, "waste27": gdjs.LevelCode.GDwaste27Objects3, "waste28": gdjs.LevelCode.GDwaste28Objects3, "waste35": gdjs.LevelCode.GDwaste35Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects3Objects = Hashtable.newFrom({"OtherBox": gdjs.LevelCode.GDOtherBoxObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste27Objects3Objects = Hashtable.newFrom({"waste27": gdjs.LevelCode.GDwaste27Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects3Objects = Hashtable.newFrom({"GlassBox": gdjs.LevelCode.GDGlassBoxObjects3});gdjs.LevelCode.eventsList7 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt man 05.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects3ObjectsGDgdjs_46LevelCode_46GDwaste4Objects3ObjectsGDgdjs_46LevelCode_46GDwaste9Objects3ObjectsGDgdjs_46LevelCode_46GDwaste11Objects3ObjectsGDgdjs_46LevelCode_46GDwaste15Objects3ObjectsGDgdjs_46LevelCode_46GDwaste22Objects3ObjectsGDgdjs_46LevelCode_46GDwaste38Objects3ObjectsGDgdjs_46LevelCode_46GDwaste40Objects3ObjectsGDgdjs_46LevelCode_46GDwaste5Objects3Objects = Hashtable.newFrom({"waste1": gdjs.LevelCode.GDwaste1Objects3, "waste4": gdjs.LevelCode.GDwaste4Objects3, "waste9": gdjs.LevelCode.GDwaste9Objects3, "waste11": gdjs.LevelCode.GDwaste11Objects3, "waste15": gdjs.LevelCode.GDwaste15Objects3, "waste22": gdjs.LevelCode.GDwaste22Objects3, "waste38": gdjs.LevelCode.GDwaste38Objects3, "waste40": gdjs.LevelCode.GDwaste40Objects3, "waste5": gdjs.LevelCode.GDwaste5Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects3Objects = Hashtable.newFrom({"PlasticBox": gdjs.LevelCode.GDPlasticBoxObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects3ObjectsGDgdjs_46LevelCode_46GDwaste4Objects3ObjectsGDgdjs_46LevelCode_46GDwaste9Objects3ObjectsGDgdjs_46LevelCode_46GDwaste11Objects3ObjectsGDgdjs_46LevelCode_46GDwaste15Objects3ObjectsGDgdjs_46LevelCode_46GDwaste22Objects3ObjectsGDgdjs_46LevelCode_46GDwaste38Objects3ObjectsGDgdjs_46LevelCode_46GDwaste40Objects3ObjectsGDgdjs_46LevelCode_46GDwaste5Objects3Objects = Hashtable.newFrom({"waste1": gdjs.LevelCode.GDwaste1Objects3, "waste4": gdjs.LevelCode.GDwaste4Objects3, "waste9": gdjs.LevelCode.GDwaste9Objects3, "waste11": gdjs.LevelCode.GDwaste11Objects3, "waste15": gdjs.LevelCode.GDwaste15Objects3, "waste22": gdjs.LevelCode.GDwaste22Objects3, "waste38": gdjs.LevelCode.GDwaste38Objects3, "waste40": gdjs.LevelCode.GDwaste40Objects3, "waste5": gdjs.LevelCode.GDwaste5Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects3Objects = Hashtable.newFrom({"GlassBox": gdjs.LevelCode.GDGlassBoxObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects3ObjectsGDgdjs_46LevelCode_46GDwaste4Objects3ObjectsGDgdjs_46LevelCode_46GDwaste9Objects3ObjectsGDgdjs_46LevelCode_46GDwaste11Objects3ObjectsGDgdjs_46LevelCode_46GDwaste15Objects3ObjectsGDgdjs_46LevelCode_46GDwaste22Objects3ObjectsGDgdjs_46LevelCode_46GDwaste38Objects3ObjectsGDgdjs_46LevelCode_46GDwaste40Objects3ObjectsGDgdjs_46LevelCode_46GDwaste5Objects3Objects = Hashtable.newFrom({"waste1": gdjs.LevelCode.GDwaste1Objects3, "waste4": gdjs.LevelCode.GDwaste4Objects3, "waste9": gdjs.LevelCode.GDwaste9Objects3, "waste11": gdjs.LevelCode.GDwaste11Objects3, "waste15": gdjs.LevelCode.GDwaste15Objects3, "waste22": gdjs.LevelCode.GDwaste22Objects3, "waste38": gdjs.LevelCode.GDwaste38Objects3, "waste40": gdjs.LevelCode.GDwaste40Objects3, "waste5": gdjs.LevelCode.GDwaste5Objects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects3Objects = Hashtable.newFrom({"OtherBox": gdjs.LevelCode.GDOtherBoxObjects3});gdjs.LevelCode.eventsList8 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt man 05.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste3Objects2ObjectsGDgdjs_46LevelCode_46GDwaste10Objects2ObjectsGDgdjs_46LevelCode_46GDwaste17Objects2ObjectsGDgdjs_46LevelCode_46GDwaste18Objects2ObjectsGDgdjs_46LevelCode_46GDwaste19Objects2ObjectsGDgdjs_46LevelCode_46GDwaste16Objects2ObjectsGDgdjs_46LevelCode_46GDwaste20Objects2ObjectsGDgdjs_46LevelCode_46GDwaste21Objects2ObjectsGDgdjs_46LevelCode_46GDwaste25Objects2ObjectsGDgdjs_46LevelCode_46GDwaste26Objects2ObjectsGDgdjs_46LevelCode_46GDwaste32Objects2ObjectsGDgdjs_46LevelCode_46GDwaste33Objects2ObjectsGDgdjs_46LevelCode_46GDwaste34Objects2ObjectsGDgdjs_46LevelCode_46GDwaste37Objects2ObjectsGDgdjs_46LevelCode_46GDwaste36Objects2Objects = Hashtable.newFrom({"waste3": gdjs.LevelCode.GDwaste3Objects2, "waste10": gdjs.LevelCode.GDwaste10Objects2, "waste17": gdjs.LevelCode.GDwaste17Objects2, "waste18": gdjs.LevelCode.GDwaste18Objects2, "waste19": gdjs.LevelCode.GDwaste19Objects2, "waste16": gdjs.LevelCode.GDwaste16Objects2, "waste20": gdjs.LevelCode.GDwaste20Objects2, "waste21": gdjs.LevelCode.GDwaste21Objects2, "waste25": gdjs.LevelCode.GDwaste25Objects2, "waste26": gdjs.LevelCode.GDwaste26Objects2, "waste32": gdjs.LevelCode.GDwaste32Objects2, "waste33": gdjs.LevelCode.GDwaste33Objects2, "waste34": gdjs.LevelCode.GDwaste34Objects2, "waste37": gdjs.LevelCode.GDwaste37Objects2, "waste36": gdjs.LevelCode.GDwaste36Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects2Objects = Hashtable.newFrom({"PlasticBox": gdjs.LevelCode.GDPlasticBoxObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste3Objects2ObjectsGDgdjs_46LevelCode_46GDwaste10Objects2ObjectsGDgdjs_46LevelCode_46GDwaste17Objects2ObjectsGDgdjs_46LevelCode_46GDwaste18Objects2ObjectsGDgdjs_46LevelCode_46GDwaste19Objects2ObjectsGDgdjs_46LevelCode_46GDwaste16Objects2ObjectsGDgdjs_46LevelCode_46GDwaste20Objects2ObjectsGDgdjs_46LevelCode_46GDwaste21Objects2ObjectsGDgdjs_46LevelCode_46GDwaste25Objects2ObjectsGDgdjs_46LevelCode_46GDwaste26Objects2ObjectsGDgdjs_46LevelCode_46GDwaste32Objects2ObjectsGDgdjs_46LevelCode_46GDwaste33Objects2ObjectsGDgdjs_46LevelCode_46GDwaste34Objects2ObjectsGDgdjs_46LevelCode_46GDwaste37Objects2ObjectsGDgdjs_46LevelCode_46GDwaste36Objects2Objects = Hashtable.newFrom({"waste3": gdjs.LevelCode.GDwaste3Objects2, "waste10": gdjs.LevelCode.GDwaste10Objects2, "waste17": gdjs.LevelCode.GDwaste17Objects2, "waste18": gdjs.LevelCode.GDwaste18Objects2, "waste19": gdjs.LevelCode.GDwaste19Objects2, "waste16": gdjs.LevelCode.GDwaste16Objects2, "waste20": gdjs.LevelCode.GDwaste20Objects2, "waste21": gdjs.LevelCode.GDwaste21Objects2, "waste25": gdjs.LevelCode.GDwaste25Objects2, "waste26": gdjs.LevelCode.GDwaste26Objects2, "waste32": gdjs.LevelCode.GDwaste32Objects2, "waste33": gdjs.LevelCode.GDwaste33Objects2, "waste34": gdjs.LevelCode.GDwaste34Objects2, "waste37": gdjs.LevelCode.GDwaste37Objects2, "waste36": gdjs.LevelCode.GDwaste36Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects2Objects = Hashtable.newFrom({"GlassBox": gdjs.LevelCode.GDGlassBoxObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste3Objects2ObjectsGDgdjs_46LevelCode_46GDwaste10Objects2ObjectsGDgdjs_46LevelCode_46GDwaste17Objects2ObjectsGDgdjs_46LevelCode_46GDwaste18Objects2ObjectsGDgdjs_46LevelCode_46GDwaste19Objects2ObjectsGDgdjs_46LevelCode_46GDwaste16Objects2ObjectsGDgdjs_46LevelCode_46GDwaste20Objects2ObjectsGDgdjs_46LevelCode_46GDwaste21Objects2ObjectsGDgdjs_46LevelCode_46GDwaste25Objects2ObjectsGDgdjs_46LevelCode_46GDwaste26Objects2ObjectsGDgdjs_46LevelCode_46GDwaste32Objects2ObjectsGDgdjs_46LevelCode_46GDwaste33Objects2ObjectsGDgdjs_46LevelCode_46GDwaste34Objects2ObjectsGDgdjs_46LevelCode_46GDwaste37Objects2ObjectsGDgdjs_46LevelCode_46GDwaste36Objects2Objects = Hashtable.newFrom({"waste3": gdjs.LevelCode.GDwaste3Objects2, "waste10": gdjs.LevelCode.GDwaste10Objects2, "waste17": gdjs.LevelCode.GDwaste17Objects2, "waste18": gdjs.LevelCode.GDwaste18Objects2, "waste19": gdjs.LevelCode.GDwaste19Objects2, "waste16": gdjs.LevelCode.GDwaste16Objects2, "waste20": gdjs.LevelCode.GDwaste20Objects2, "waste21": gdjs.LevelCode.GDwaste21Objects2, "waste25": gdjs.LevelCode.GDwaste25Objects2, "waste26": gdjs.LevelCode.GDwaste26Objects2, "waste32": gdjs.LevelCode.GDwaste32Objects2, "waste33": gdjs.LevelCode.GDwaste33Objects2, "waste34": gdjs.LevelCode.GDwaste34Objects2, "waste37": gdjs.LevelCode.GDwaste37Objects2, "waste36": gdjs.LevelCode.GDwaste36Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects2Objects = Hashtable.newFrom({"PaperBox": gdjs.LevelCode.GDPaperBoxObjects2});gdjs.LevelCode.eventsList9 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt man 05.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1, gdjs.LevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste6Objects2ObjectsGDgdjs_46LevelCode_46GDwaste7Objects2ObjectsGDgdjs_46LevelCode_46GDwaste8Objects2ObjectsGDgdjs_46LevelCode_46GDwaste12Objects2ObjectsGDgdjs_46LevelCode_46GDwaste24Objects2ObjectsGDgdjs_46LevelCode_46GDwaste29Objects2ObjectsGDgdjs_46LevelCode_46GDwaste30Objects2ObjectsGDgdjs_46LevelCode_46GDwaste31Objects2ObjectsGDgdjs_46LevelCode_46GDwaste39Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.LevelCode.GDScoreObjects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects2);

/* Reuse gdjs.LevelCode.GDwaste12Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects2);

/* Reuse gdjs.LevelCode.GDwaste24Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects2);

/* Reuse gdjs.LevelCode.GDwaste29Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

/* Reuse gdjs.LevelCode.GDwaste30Objects2 */
/* Reuse gdjs.LevelCode.GDwaste31Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects2);

/* Reuse gdjs.LevelCode.GDwaste39Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects2);

/* Reuse gdjs.LevelCode.GDwaste6Objects2 */
/* Reuse gdjs.LevelCode.GDwaste7Objects2 */
/* Reuse gdjs.LevelCode.GDwaste8Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects2);

{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.LevelCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDScoreObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects1, gdjs.LevelCode.GDOtherBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste3Objects2ObjectsGDgdjs_46LevelCode_46GDwaste10Objects2ObjectsGDgdjs_46LevelCode_46GDwaste17Objects2ObjectsGDgdjs_46LevelCode_46GDwaste18Objects2ObjectsGDgdjs_46LevelCode_46GDwaste19Objects2ObjectsGDgdjs_46LevelCode_46GDwaste16Objects2ObjectsGDgdjs_46LevelCode_46GDwaste20Objects2ObjectsGDgdjs_46LevelCode_46GDwaste21Objects2ObjectsGDgdjs_46LevelCode_46GDwaste25Objects2ObjectsGDgdjs_46LevelCode_46GDwaste26Objects2ObjectsGDgdjs_46LevelCode_46GDwaste32Objects2ObjectsGDgdjs_46LevelCode_46GDwaste33Objects2ObjectsGDgdjs_46LevelCode_46GDwaste34Objects2ObjectsGDgdjs_46LevelCode_46GDwaste37Objects2ObjectsGDgdjs_46LevelCode_46GDwaste36Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.LevelCode.GDScoreObjects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects2);

/* Reuse gdjs.LevelCode.GDwaste10Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects2);

/* Reuse gdjs.LevelCode.GDwaste16Objects2 */
/* Reuse gdjs.LevelCode.GDwaste17Objects2 */
/* Reuse gdjs.LevelCode.GDwaste18Objects2 */
/* Reuse gdjs.LevelCode.GDwaste19Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects2);

/* Reuse gdjs.LevelCode.GDwaste20Objects2 */
/* Reuse gdjs.LevelCode.GDwaste21Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects2);

/* Reuse gdjs.LevelCode.GDwaste25Objects2 */
/* Reuse gdjs.LevelCode.GDwaste26Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects2);

/* Reuse gdjs.LevelCode.GDwaste3Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects2);

/* Reuse gdjs.LevelCode.GDwaste32Objects2 */
/* Reuse gdjs.LevelCode.GDwaste33Objects2 */
/* Reuse gdjs.LevelCode.GDwaste34Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects2);

/* Reuse gdjs.LevelCode.GDwaste36Objects2 */
/* Reuse gdjs.LevelCode.GDwaste37Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects2);

{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.LevelCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDScoreObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects1, gdjs.LevelCode.GDPaperBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects2ObjectsGDgdjs_46LevelCode_46GDwaste4Objects2ObjectsGDgdjs_46LevelCode_46GDwaste9Objects2ObjectsGDgdjs_46LevelCode_46GDwaste11Objects2ObjectsGDgdjs_46LevelCode_46GDwaste15Objects2ObjectsGDgdjs_46LevelCode_46GDwaste22Objects2ObjectsGDgdjs_46LevelCode_46GDwaste38Objects2ObjectsGDgdjs_46LevelCode_46GDwaste40Objects2ObjectsGDgdjs_46LevelCode_46GDwaste5Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.LevelCode.GDScoreObjects2);
/* Reuse gdjs.LevelCode.GDwaste1Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

/* Reuse gdjs.LevelCode.GDwaste11Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects2);

/* Reuse gdjs.LevelCode.GDwaste15Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

/* Reuse gdjs.LevelCode.GDwaste22Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

/* Reuse gdjs.LevelCode.GDwaste38Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects2);

/* Reuse gdjs.LevelCode.GDwaste4Objects2 */
/* Reuse gdjs.LevelCode.GDwaste40Objects2 */
/* Reuse gdjs.LevelCode.GDwaste5Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects2);

/* Reuse gdjs.LevelCode.GDwaste9Objects2 */
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.LevelCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDScoreObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1, gdjs.LevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste13Objects2ObjectsGDgdjs_46LevelCode_46GDwaste14Objects2ObjectsGDgdjs_46LevelCode_46GDwaste2Objects2ObjectsGDgdjs_46LevelCode_46GDwaste23Objects2ObjectsGDgdjs_46LevelCode_46GDwaste27Objects2ObjectsGDgdjs_46LevelCode_46GDwaste28Objects2ObjectsGDgdjs_46LevelCode_46GDwaste35Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.LevelCode.GDScoreObjects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects2);

/* Reuse gdjs.LevelCode.GDwaste13Objects2 */
/* Reuse gdjs.LevelCode.GDwaste14Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

/* Reuse gdjs.LevelCode.GDwaste2Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects2);

/* Reuse gdjs.LevelCode.GDwaste23Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

/* Reuse gdjs.LevelCode.GDwaste27Objects2 */
/* Reuse gdjs.LevelCode.GDwaste28Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

/* Reuse gdjs.LevelCode.GDwaste35Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects2);

{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.LevelCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDScoreObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1, gdjs.LevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects1, gdjs.LevelCode.GDOtherBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects1, gdjs.LevelCode.GDPaperBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1, gdjs.LevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 1;
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition1IsTrue_0;
gdjs.LevelCode.GDGlassBoxObjects2_1final.length = 0;gdjs.LevelCode.GDOtherBoxObjects2_1final.length = 0;gdjs.LevelCode.GDPaperBoxObjects2_1final.length = 0;gdjs.LevelCode.GDPlasticBoxObjects2_1final.length = 0;gdjs.LevelCode.GDwaste12Objects2_1final.length = 0;gdjs.LevelCode.GDwaste24Objects2_1final.length = 0;gdjs.LevelCode.GDwaste29Objects2_1final.length = 0;gdjs.LevelCode.GDwaste30Objects2_1final.length = 0;gdjs.LevelCode.GDwaste31Objects2_1final.length = 0;gdjs.LevelCode.GDwaste39Objects2_1final.length = 0;gdjs.LevelCode.GDwaste6Objects2_1final.length = 0;gdjs.LevelCode.GDwaste7Objects2_1final.length = 0;gdjs.LevelCode.GDwaste8Objects2_1final.length = 0;gdjs.LevelCode.condition0IsTrue_1.val = false;
gdjs.LevelCode.condition1IsTrue_1.val = false;
gdjs.LevelCode.condition2IsTrue_1.val = false;
gdjs.LevelCode.condition3IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1, gdjs.LevelCode.GDGlassBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects3);

gdjs.LevelCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste6Objects3ObjectsGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste12Objects3ObjectsGDgdjs_46LevelCode_46GDwaste24Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste30Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3ObjectsGDgdjs_46LevelCode_46GDwaste39Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition0IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDGlassBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDGlassBoxObjects2_1final.indexOf(gdjs.LevelCode.GDGlassBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDGlassBoxObjects2_1final.push(gdjs.LevelCode.GDGlassBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste12Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste12Objects2_1final.indexOf(gdjs.LevelCode.GDwaste12Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste12Objects2_1final.push(gdjs.LevelCode.GDwaste12Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste24Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste24Objects2_1final.indexOf(gdjs.LevelCode.GDwaste24Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste24Objects2_1final.push(gdjs.LevelCode.GDwaste24Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste29Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste29Objects2_1final.indexOf(gdjs.LevelCode.GDwaste29Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste29Objects2_1final.push(gdjs.LevelCode.GDwaste29Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste30Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste30Objects2_1final.indexOf(gdjs.LevelCode.GDwaste30Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste30Objects2_1final.push(gdjs.LevelCode.GDwaste30Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste31Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste31Objects2_1final.indexOf(gdjs.LevelCode.GDwaste31Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste31Objects2_1final.push(gdjs.LevelCode.GDwaste31Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste39Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste39Objects2_1final.indexOf(gdjs.LevelCode.GDwaste39Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste39Objects2_1final.push(gdjs.LevelCode.GDwaste39Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste6Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste6Objects2_1final.indexOf(gdjs.LevelCode.GDwaste6Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste6Objects2_1final.push(gdjs.LevelCode.GDwaste6Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste7Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste7Objects2_1final.indexOf(gdjs.LevelCode.GDwaste7Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste7Objects2_1final.push(gdjs.LevelCode.GDwaste7Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste8Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste8Objects2_1final.indexOf(gdjs.LevelCode.GDwaste8Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste8Objects2_1final.push(gdjs.LevelCode.GDwaste8Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects1, gdjs.LevelCode.GDPaperBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects3);

gdjs.LevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste6Objects3ObjectsGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste12Objects3ObjectsGDgdjs_46LevelCode_46GDwaste24Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste30Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3ObjectsGDgdjs_46LevelCode_46GDwaste39Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition1IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDPaperBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDPaperBoxObjects2_1final.indexOf(gdjs.LevelCode.GDPaperBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDPaperBoxObjects2_1final.push(gdjs.LevelCode.GDPaperBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste12Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste12Objects2_1final.indexOf(gdjs.LevelCode.GDwaste12Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste12Objects2_1final.push(gdjs.LevelCode.GDwaste12Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste24Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste24Objects2_1final.indexOf(gdjs.LevelCode.GDwaste24Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste24Objects2_1final.push(gdjs.LevelCode.GDwaste24Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste29Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste29Objects2_1final.indexOf(gdjs.LevelCode.GDwaste29Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste29Objects2_1final.push(gdjs.LevelCode.GDwaste29Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste30Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste30Objects2_1final.indexOf(gdjs.LevelCode.GDwaste30Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste30Objects2_1final.push(gdjs.LevelCode.GDwaste30Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste31Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste31Objects2_1final.indexOf(gdjs.LevelCode.GDwaste31Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste31Objects2_1final.push(gdjs.LevelCode.GDwaste31Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste39Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste39Objects2_1final.indexOf(gdjs.LevelCode.GDwaste39Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste39Objects2_1final.push(gdjs.LevelCode.GDwaste39Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste6Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste6Objects2_1final.indexOf(gdjs.LevelCode.GDwaste6Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste6Objects2_1final.push(gdjs.LevelCode.GDwaste6Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste7Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste7Objects2_1final.indexOf(gdjs.LevelCode.GDwaste7Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste7Objects2_1final.push(gdjs.LevelCode.GDwaste7Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste8Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste8Objects2_1final.indexOf(gdjs.LevelCode.GDwaste8Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste8Objects2_1final.push(gdjs.LevelCode.GDwaste8Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects1, gdjs.LevelCode.GDOtherBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects3);

gdjs.LevelCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste6Objects3ObjectsGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste12Objects3ObjectsGDgdjs_46LevelCode_46GDwaste24Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste30Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3ObjectsGDgdjs_46LevelCode_46GDwaste39Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition2IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDOtherBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDOtherBoxObjects2_1final.indexOf(gdjs.LevelCode.GDOtherBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDOtherBoxObjects2_1final.push(gdjs.LevelCode.GDOtherBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste12Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste12Objects2_1final.indexOf(gdjs.LevelCode.GDwaste12Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste12Objects2_1final.push(gdjs.LevelCode.GDwaste12Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste24Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste24Objects2_1final.indexOf(gdjs.LevelCode.GDwaste24Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste24Objects2_1final.push(gdjs.LevelCode.GDwaste24Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste29Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste29Objects2_1final.indexOf(gdjs.LevelCode.GDwaste29Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste29Objects2_1final.push(gdjs.LevelCode.GDwaste29Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste30Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste30Objects2_1final.indexOf(gdjs.LevelCode.GDwaste30Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste30Objects2_1final.push(gdjs.LevelCode.GDwaste30Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste31Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste31Objects2_1final.indexOf(gdjs.LevelCode.GDwaste31Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste31Objects2_1final.push(gdjs.LevelCode.GDwaste31Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste39Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste39Objects2_1final.indexOf(gdjs.LevelCode.GDwaste39Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste39Objects2_1final.push(gdjs.LevelCode.GDwaste39Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste6Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste6Objects2_1final.indexOf(gdjs.LevelCode.GDwaste6Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste6Objects2_1final.push(gdjs.LevelCode.GDwaste6Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste7Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste7Objects2_1final.indexOf(gdjs.LevelCode.GDwaste7Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste7Objects2_1final.push(gdjs.LevelCode.GDwaste7Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste8Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste8Objects2_1final.indexOf(gdjs.LevelCode.GDwaste8Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste8Objects2_1final.push(gdjs.LevelCode.GDwaste8Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1, gdjs.LevelCode.GDPlasticBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects3);

{gdjs.LevelCode.conditionTrue_2 = gdjs.LevelCode.condition3IsTrue_1;
gdjs.LevelCode.condition0IsTrue_2.val = false;
gdjs.LevelCode.condition1IsTrue_2.val = false;
{
gdjs.LevelCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste7Objects3ObjectsGDgdjs_46LevelCode_46GDwaste8Objects3ObjectsGDgdjs_46LevelCode_46GDwaste29Objects3ObjectsGDgdjs_46LevelCode_46GDwaste31Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects3Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste6Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste6Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste6Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste6Objects3[k] = gdjs.LevelCode.GDwaste6Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste6Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste7Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste7Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste7Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste7Objects3[k] = gdjs.LevelCode.GDwaste7Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste7Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste8Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste8Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste8Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste8Objects3[k] = gdjs.LevelCode.GDwaste8Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste8Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste12Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste12Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste12Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste12Objects3[k] = gdjs.LevelCode.GDwaste12Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste12Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste24Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste24Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste24Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste24Objects3[k] = gdjs.LevelCode.GDwaste24Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste24Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste29Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste29Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste29Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste29Objects3[k] = gdjs.LevelCode.GDwaste29Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste29Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste30Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste30Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste30Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste30Objects3[k] = gdjs.LevelCode.GDwaste30Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste30Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste31Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste31Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste31Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste31Objects3[k] = gdjs.LevelCode.GDwaste31Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste31Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste39Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste39Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste39Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste39Objects3[k] = gdjs.LevelCode.GDwaste39Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste39Objects3.length = k;}}
gdjs.LevelCode.conditionTrue_2.val = true && gdjs.LevelCode.condition0IsTrue_2.val && gdjs.LevelCode.condition1IsTrue_2.val;
}
if( gdjs.LevelCode.condition3IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDPlasticBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDPlasticBoxObjects2_1final.indexOf(gdjs.LevelCode.GDPlasticBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDPlasticBoxObjects2_1final.push(gdjs.LevelCode.GDPlasticBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste12Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste12Objects2_1final.indexOf(gdjs.LevelCode.GDwaste12Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste12Objects2_1final.push(gdjs.LevelCode.GDwaste12Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste24Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste24Objects2_1final.indexOf(gdjs.LevelCode.GDwaste24Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste24Objects2_1final.push(gdjs.LevelCode.GDwaste24Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste29Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste29Objects2_1final.indexOf(gdjs.LevelCode.GDwaste29Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste29Objects2_1final.push(gdjs.LevelCode.GDwaste29Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste30Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste30Objects2_1final.indexOf(gdjs.LevelCode.GDwaste30Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste30Objects2_1final.push(gdjs.LevelCode.GDwaste30Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste31Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste31Objects2_1final.indexOf(gdjs.LevelCode.GDwaste31Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste31Objects2_1final.push(gdjs.LevelCode.GDwaste31Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste39Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste39Objects2_1final.indexOf(gdjs.LevelCode.GDwaste39Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste39Objects2_1final.push(gdjs.LevelCode.GDwaste39Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste6Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste6Objects2_1final.indexOf(gdjs.LevelCode.GDwaste6Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste6Objects2_1final.push(gdjs.LevelCode.GDwaste6Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste7Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste7Objects2_1final.indexOf(gdjs.LevelCode.GDwaste7Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste7Objects2_1final.push(gdjs.LevelCode.GDwaste7Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste8Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste8Objects2_1final.indexOf(gdjs.LevelCode.GDwaste8Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste8Objects2_1final.push(gdjs.LevelCode.GDwaste8Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects2_1final, gdjs.LevelCode.GDGlassBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects2_1final, gdjs.LevelCode.GDOtherBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects2_1final, gdjs.LevelCode.GDPaperBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects2_1final, gdjs.LevelCode.GDPlasticBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects2_1final, gdjs.LevelCode.GDwaste12Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects2_1final, gdjs.LevelCode.GDwaste24Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects2_1final, gdjs.LevelCode.GDwaste29Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects2_1final, gdjs.LevelCode.GDwaste30Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects2_1final, gdjs.LevelCode.GDwaste31Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects2_1final, gdjs.LevelCode.GDwaste39Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects2_1final, gdjs.LevelCode.GDwaste6Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects2_1final, gdjs.LevelCode.GDwaste7Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects2_1final, gdjs.LevelCode.GDwaste8Objects2);
}
}
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.LevelCode.GDLifeObjects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects2);

/* Reuse gdjs.LevelCode.GDwaste12Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects2);

/* Reuse gdjs.LevelCode.GDwaste24Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects2);

/* Reuse gdjs.LevelCode.GDwaste29Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

/* Reuse gdjs.LevelCode.GDwaste30Objects2 */
/* Reuse gdjs.LevelCode.GDwaste31Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects2);

/* Reuse gdjs.LevelCode.GDwaste39Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects2);

/* Reuse gdjs.LevelCode.GDwaste6Objects2 */
/* Reuse gdjs.LevelCode.GDwaste7Objects2 */
/* Reuse gdjs.LevelCode.GDwaste8Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects2);

{runtimeScene.getGame().getVariables().getFromIndex(2).sub(1);
}{for(var i = 0, len = gdjs.LevelCode.GDLifeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDLifeObjects2[i].setAnimationName("Life" + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1, gdjs.LevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects1, gdjs.LevelCode.GDOtherBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects1, gdjs.LevelCode.GDPaperBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1, gdjs.LevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 2;
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition1IsTrue_0;
gdjs.LevelCode.GDGlassBoxObjects2_1final.length = 0;gdjs.LevelCode.GDOtherBoxObjects2_1final.length = 0;gdjs.LevelCode.GDPaperBoxObjects2_1final.length = 0;gdjs.LevelCode.GDPlasticBoxObjects2_1final.length = 0;gdjs.LevelCode.GDwaste13Objects2_1final.length = 0;gdjs.LevelCode.GDwaste14Objects2_1final.length = 0;gdjs.LevelCode.GDwaste2Objects2_1final.length = 0;gdjs.LevelCode.GDwaste23Objects2_1final.length = 0;gdjs.LevelCode.GDwaste27Objects2_1final.length = 0;gdjs.LevelCode.GDwaste28Objects2_1final.length = 0;gdjs.LevelCode.GDwaste35Objects2_1final.length = 0;gdjs.LevelCode.condition0IsTrue_1.val = false;
gdjs.LevelCode.condition1IsTrue_1.val = false;
gdjs.LevelCode.condition2IsTrue_1.val = false;
gdjs.LevelCode.condition3IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1, gdjs.LevelCode.GDPlasticBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects3);

gdjs.LevelCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste13Objects3ObjectsGDgdjs_46LevelCode_46GDwaste14Objects3ObjectsGDgdjs_46LevelCode_46GDwaste2Objects3ObjectsGDgdjs_46LevelCode_46GDwaste23Objects3ObjectsGDgdjs_46LevelCode_46GDwaste27Objects3ObjectsGDgdjs_46LevelCode_46GDwaste28Objects3ObjectsGDgdjs_46LevelCode_46GDwaste35Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition0IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDPlasticBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDPlasticBoxObjects2_1final.indexOf(gdjs.LevelCode.GDPlasticBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDPlasticBoxObjects2_1final.push(gdjs.LevelCode.GDPlasticBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste13Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste13Objects2_1final.indexOf(gdjs.LevelCode.GDwaste13Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste13Objects2_1final.push(gdjs.LevelCode.GDwaste13Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste14Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste14Objects2_1final.indexOf(gdjs.LevelCode.GDwaste14Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste14Objects2_1final.push(gdjs.LevelCode.GDwaste14Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste2Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste2Objects2_1final.indexOf(gdjs.LevelCode.GDwaste2Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste2Objects2_1final.push(gdjs.LevelCode.GDwaste2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste23Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste23Objects2_1final.indexOf(gdjs.LevelCode.GDwaste23Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste23Objects2_1final.push(gdjs.LevelCode.GDwaste23Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste27Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste27Objects2_1final.indexOf(gdjs.LevelCode.GDwaste27Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste27Objects2_1final.push(gdjs.LevelCode.GDwaste27Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste28Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste28Objects2_1final.indexOf(gdjs.LevelCode.GDwaste28Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste28Objects2_1final.push(gdjs.LevelCode.GDwaste28Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste35Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste35Objects2_1final.indexOf(gdjs.LevelCode.GDwaste35Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste35Objects2_1final.push(gdjs.LevelCode.GDwaste35Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects1, gdjs.LevelCode.GDPaperBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects3);

gdjs.LevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste13Objects3ObjectsGDgdjs_46LevelCode_46GDwaste14Objects3ObjectsGDgdjs_46LevelCode_46GDwaste2Objects3ObjectsGDgdjs_46LevelCode_46GDwaste23Objects3ObjectsGDgdjs_46LevelCode_46GDwaste27Objects3ObjectsGDgdjs_46LevelCode_46GDwaste28Objects3ObjectsGDgdjs_46LevelCode_46GDwaste35Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition1IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDPaperBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDPaperBoxObjects2_1final.indexOf(gdjs.LevelCode.GDPaperBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDPaperBoxObjects2_1final.push(gdjs.LevelCode.GDPaperBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste13Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste13Objects2_1final.indexOf(gdjs.LevelCode.GDwaste13Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste13Objects2_1final.push(gdjs.LevelCode.GDwaste13Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste14Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste14Objects2_1final.indexOf(gdjs.LevelCode.GDwaste14Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste14Objects2_1final.push(gdjs.LevelCode.GDwaste14Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste2Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste2Objects2_1final.indexOf(gdjs.LevelCode.GDwaste2Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste2Objects2_1final.push(gdjs.LevelCode.GDwaste2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste23Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste23Objects2_1final.indexOf(gdjs.LevelCode.GDwaste23Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste23Objects2_1final.push(gdjs.LevelCode.GDwaste23Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste27Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste27Objects2_1final.indexOf(gdjs.LevelCode.GDwaste27Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste27Objects2_1final.push(gdjs.LevelCode.GDwaste27Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste28Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste28Objects2_1final.indexOf(gdjs.LevelCode.GDwaste28Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste28Objects2_1final.push(gdjs.LevelCode.GDwaste28Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste35Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste35Objects2_1final.indexOf(gdjs.LevelCode.GDwaste35Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste35Objects2_1final.push(gdjs.LevelCode.GDwaste35Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects1, gdjs.LevelCode.GDOtherBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects3);

gdjs.LevelCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste13Objects3ObjectsGDgdjs_46LevelCode_46GDwaste14Objects3ObjectsGDgdjs_46LevelCode_46GDwaste2Objects3ObjectsGDgdjs_46LevelCode_46GDwaste23Objects3ObjectsGDgdjs_46LevelCode_46GDwaste27Objects3ObjectsGDgdjs_46LevelCode_46GDwaste28Objects3ObjectsGDgdjs_46LevelCode_46GDwaste35Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition2IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDOtherBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDOtherBoxObjects2_1final.indexOf(gdjs.LevelCode.GDOtherBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDOtherBoxObjects2_1final.push(gdjs.LevelCode.GDOtherBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste13Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste13Objects2_1final.indexOf(gdjs.LevelCode.GDwaste13Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste13Objects2_1final.push(gdjs.LevelCode.GDwaste13Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste14Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste14Objects2_1final.indexOf(gdjs.LevelCode.GDwaste14Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste14Objects2_1final.push(gdjs.LevelCode.GDwaste14Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste2Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste2Objects2_1final.indexOf(gdjs.LevelCode.GDwaste2Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste2Objects2_1final.push(gdjs.LevelCode.GDwaste2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste23Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste23Objects2_1final.indexOf(gdjs.LevelCode.GDwaste23Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste23Objects2_1final.push(gdjs.LevelCode.GDwaste23Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste27Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste27Objects2_1final.indexOf(gdjs.LevelCode.GDwaste27Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste27Objects2_1final.push(gdjs.LevelCode.GDwaste27Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste28Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste28Objects2_1final.indexOf(gdjs.LevelCode.GDwaste28Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste28Objects2_1final.push(gdjs.LevelCode.GDwaste28Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste35Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste35Objects2_1final.indexOf(gdjs.LevelCode.GDwaste35Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste35Objects2_1final.push(gdjs.LevelCode.GDwaste35Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1, gdjs.LevelCode.GDGlassBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects3);

{gdjs.LevelCode.conditionTrue_2 = gdjs.LevelCode.condition3IsTrue_1;
gdjs.LevelCode.condition0IsTrue_2.val = false;
gdjs.LevelCode.condition1IsTrue_2.val = false;
{
gdjs.LevelCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste27Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects3Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste13Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste13Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste13Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste13Objects3[k] = gdjs.LevelCode.GDwaste13Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste13Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste14Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste14Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste14Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste14Objects3[k] = gdjs.LevelCode.GDwaste14Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste14Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste2Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste2Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste2Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste2Objects3[k] = gdjs.LevelCode.GDwaste2Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste23Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste23Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste23Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste23Objects3[k] = gdjs.LevelCode.GDwaste23Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste23Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste27Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste27Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste27Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste27Objects3[k] = gdjs.LevelCode.GDwaste27Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste27Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste28Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste28Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste28Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste28Objects3[k] = gdjs.LevelCode.GDwaste28Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste28Objects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste35Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste35Objects3[i].getVariableNumber(gdjs.LevelCode.GDwaste35Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.LevelCode.condition1IsTrue_2.val = true;
        gdjs.LevelCode.GDwaste35Objects3[k] = gdjs.LevelCode.GDwaste35Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste35Objects3.length = k;}}
gdjs.LevelCode.conditionTrue_2.val = true && gdjs.LevelCode.condition0IsTrue_2.val && gdjs.LevelCode.condition1IsTrue_2.val;
}
if( gdjs.LevelCode.condition3IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDGlassBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDGlassBoxObjects2_1final.indexOf(gdjs.LevelCode.GDGlassBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDGlassBoxObjects2_1final.push(gdjs.LevelCode.GDGlassBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste13Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste13Objects2_1final.indexOf(gdjs.LevelCode.GDwaste13Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste13Objects2_1final.push(gdjs.LevelCode.GDwaste13Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste14Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste14Objects2_1final.indexOf(gdjs.LevelCode.GDwaste14Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste14Objects2_1final.push(gdjs.LevelCode.GDwaste14Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste2Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste2Objects2_1final.indexOf(gdjs.LevelCode.GDwaste2Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste2Objects2_1final.push(gdjs.LevelCode.GDwaste2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste23Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste23Objects2_1final.indexOf(gdjs.LevelCode.GDwaste23Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste23Objects2_1final.push(gdjs.LevelCode.GDwaste23Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste27Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste27Objects2_1final.indexOf(gdjs.LevelCode.GDwaste27Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste27Objects2_1final.push(gdjs.LevelCode.GDwaste27Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste28Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste28Objects2_1final.indexOf(gdjs.LevelCode.GDwaste28Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste28Objects2_1final.push(gdjs.LevelCode.GDwaste28Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste35Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste35Objects2_1final.indexOf(gdjs.LevelCode.GDwaste35Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste35Objects2_1final.push(gdjs.LevelCode.GDwaste35Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects2_1final, gdjs.LevelCode.GDGlassBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects2_1final, gdjs.LevelCode.GDOtherBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects2_1final, gdjs.LevelCode.GDPaperBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects2_1final, gdjs.LevelCode.GDPlasticBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects2_1final, gdjs.LevelCode.GDwaste13Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects2_1final, gdjs.LevelCode.GDwaste14Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects2_1final, gdjs.LevelCode.GDwaste2Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects2_1final, gdjs.LevelCode.GDwaste23Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects2_1final, gdjs.LevelCode.GDwaste27Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects2_1final, gdjs.LevelCode.GDwaste28Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects2_1final, gdjs.LevelCode.GDwaste35Objects2);
}
}
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.LevelCode.GDLifeObjects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects2);

/* Reuse gdjs.LevelCode.GDwaste13Objects2 */
/* Reuse gdjs.LevelCode.GDwaste14Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

/* Reuse gdjs.LevelCode.GDwaste2Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects2);

/* Reuse gdjs.LevelCode.GDwaste23Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

/* Reuse gdjs.LevelCode.GDwaste27Objects2 */
/* Reuse gdjs.LevelCode.GDwaste28Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

/* Reuse gdjs.LevelCode.GDwaste35Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects2);

{runtimeScene.getGame().getVariables().getFromIndex(2).sub(1);
}{for(var i = 0, len = gdjs.LevelCode.GDLifeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDLifeObjects2[i].setAnimationName("Life" + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1, gdjs.LevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects1, gdjs.LevelCode.GDOtherBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1, gdjs.LevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 3;
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition1IsTrue_0;
gdjs.LevelCode.GDGlassBoxObjects2_1final.length = 0;gdjs.LevelCode.GDOtherBoxObjects2_1final.length = 0;gdjs.LevelCode.GDPlasticBoxObjects2_1final.length = 0;gdjs.LevelCode.GDwaste1Objects2_1final.length = 0;gdjs.LevelCode.GDwaste11Objects2_1final.length = 0;gdjs.LevelCode.GDwaste15Objects2_1final.length = 0;gdjs.LevelCode.GDwaste22Objects2_1final.length = 0;gdjs.LevelCode.GDwaste38Objects2_1final.length = 0;gdjs.LevelCode.GDwaste4Objects2_1final.length = 0;gdjs.LevelCode.GDwaste40Objects2_1final.length = 0;gdjs.LevelCode.GDwaste5Objects2_1final.length = 0;gdjs.LevelCode.GDwaste9Objects2_1final.length = 0;gdjs.LevelCode.condition0IsTrue_1.val = false;
gdjs.LevelCode.condition1IsTrue_1.val = false;
gdjs.LevelCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1, gdjs.LevelCode.GDPlasticBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects3);

gdjs.LevelCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects3ObjectsGDgdjs_46LevelCode_46GDwaste4Objects3ObjectsGDgdjs_46LevelCode_46GDwaste9Objects3ObjectsGDgdjs_46LevelCode_46GDwaste11Objects3ObjectsGDgdjs_46LevelCode_46GDwaste15Objects3ObjectsGDgdjs_46LevelCode_46GDwaste22Objects3ObjectsGDgdjs_46LevelCode_46GDwaste38Objects3ObjectsGDgdjs_46LevelCode_46GDwaste40Objects3ObjectsGDgdjs_46LevelCode_46GDwaste5Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition0IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDPlasticBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDPlasticBoxObjects2_1final.indexOf(gdjs.LevelCode.GDPlasticBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDPlasticBoxObjects2_1final.push(gdjs.LevelCode.GDPlasticBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste1Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste1Objects2_1final.indexOf(gdjs.LevelCode.GDwaste1Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste1Objects2_1final.push(gdjs.LevelCode.GDwaste1Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste11Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste11Objects2_1final.indexOf(gdjs.LevelCode.GDwaste11Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste11Objects2_1final.push(gdjs.LevelCode.GDwaste11Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste15Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste15Objects2_1final.indexOf(gdjs.LevelCode.GDwaste15Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste15Objects2_1final.push(gdjs.LevelCode.GDwaste15Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste22Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste22Objects2_1final.indexOf(gdjs.LevelCode.GDwaste22Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste22Objects2_1final.push(gdjs.LevelCode.GDwaste22Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste38Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste38Objects2_1final.indexOf(gdjs.LevelCode.GDwaste38Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste38Objects2_1final.push(gdjs.LevelCode.GDwaste38Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste4Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste4Objects2_1final.indexOf(gdjs.LevelCode.GDwaste4Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste4Objects2_1final.push(gdjs.LevelCode.GDwaste4Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste40Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste40Objects2_1final.indexOf(gdjs.LevelCode.GDwaste40Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste40Objects2_1final.push(gdjs.LevelCode.GDwaste40Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste5Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste5Objects2_1final.indexOf(gdjs.LevelCode.GDwaste5Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste5Objects2_1final.push(gdjs.LevelCode.GDwaste5Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste9Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste9Objects2_1final.indexOf(gdjs.LevelCode.GDwaste9Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste9Objects2_1final.push(gdjs.LevelCode.GDwaste9Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1, gdjs.LevelCode.GDGlassBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects3);

gdjs.LevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects3ObjectsGDgdjs_46LevelCode_46GDwaste4Objects3ObjectsGDgdjs_46LevelCode_46GDwaste9Objects3ObjectsGDgdjs_46LevelCode_46GDwaste11Objects3ObjectsGDgdjs_46LevelCode_46GDwaste15Objects3ObjectsGDgdjs_46LevelCode_46GDwaste22Objects3ObjectsGDgdjs_46LevelCode_46GDwaste38Objects3ObjectsGDgdjs_46LevelCode_46GDwaste40Objects3ObjectsGDgdjs_46LevelCode_46GDwaste5Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition1IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDGlassBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDGlassBoxObjects2_1final.indexOf(gdjs.LevelCode.GDGlassBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDGlassBoxObjects2_1final.push(gdjs.LevelCode.GDGlassBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste1Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste1Objects2_1final.indexOf(gdjs.LevelCode.GDwaste1Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste1Objects2_1final.push(gdjs.LevelCode.GDwaste1Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste11Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste11Objects2_1final.indexOf(gdjs.LevelCode.GDwaste11Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste11Objects2_1final.push(gdjs.LevelCode.GDwaste11Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste15Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste15Objects2_1final.indexOf(gdjs.LevelCode.GDwaste15Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste15Objects2_1final.push(gdjs.LevelCode.GDwaste15Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste22Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste22Objects2_1final.indexOf(gdjs.LevelCode.GDwaste22Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste22Objects2_1final.push(gdjs.LevelCode.GDwaste22Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste38Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste38Objects2_1final.indexOf(gdjs.LevelCode.GDwaste38Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste38Objects2_1final.push(gdjs.LevelCode.GDwaste38Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste4Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste4Objects2_1final.indexOf(gdjs.LevelCode.GDwaste4Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste4Objects2_1final.push(gdjs.LevelCode.GDwaste4Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste40Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste40Objects2_1final.indexOf(gdjs.LevelCode.GDwaste40Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste40Objects2_1final.push(gdjs.LevelCode.GDwaste40Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste5Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste5Objects2_1final.indexOf(gdjs.LevelCode.GDwaste5Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste5Objects2_1final.push(gdjs.LevelCode.GDwaste5Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste9Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste9Objects2_1final.indexOf(gdjs.LevelCode.GDwaste9Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste9Objects2_1final.push(gdjs.LevelCode.GDwaste9Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects1, gdjs.LevelCode.GDOtherBoxObjects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects1, gdjs.LevelCode.GDwaste1Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects1, gdjs.LevelCode.GDwaste11Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects1, gdjs.LevelCode.GDwaste15Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects1, gdjs.LevelCode.GDwaste22Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects1, gdjs.LevelCode.GDwaste38Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects1, gdjs.LevelCode.GDwaste4Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects1, gdjs.LevelCode.GDwaste40Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects1, gdjs.LevelCode.GDwaste5Objects3);

gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects1, gdjs.LevelCode.GDwaste9Objects3);

gdjs.LevelCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects3ObjectsGDgdjs_46LevelCode_46GDwaste4Objects3ObjectsGDgdjs_46LevelCode_46GDwaste9Objects3ObjectsGDgdjs_46LevelCode_46GDwaste11Objects3ObjectsGDgdjs_46LevelCode_46GDwaste15Objects3ObjectsGDgdjs_46LevelCode_46GDwaste22Objects3ObjectsGDgdjs_46LevelCode_46GDwaste38Objects3ObjectsGDgdjs_46LevelCode_46GDwaste40Objects3ObjectsGDgdjs_46LevelCode_46GDwaste5Objects3Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition2IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDOtherBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDOtherBoxObjects2_1final.indexOf(gdjs.LevelCode.GDOtherBoxObjects3[j]) === -1 )
            gdjs.LevelCode.GDOtherBoxObjects2_1final.push(gdjs.LevelCode.GDOtherBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste1Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste1Objects2_1final.indexOf(gdjs.LevelCode.GDwaste1Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste1Objects2_1final.push(gdjs.LevelCode.GDwaste1Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste11Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste11Objects2_1final.indexOf(gdjs.LevelCode.GDwaste11Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste11Objects2_1final.push(gdjs.LevelCode.GDwaste11Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste15Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste15Objects2_1final.indexOf(gdjs.LevelCode.GDwaste15Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste15Objects2_1final.push(gdjs.LevelCode.GDwaste15Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste22Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste22Objects2_1final.indexOf(gdjs.LevelCode.GDwaste22Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste22Objects2_1final.push(gdjs.LevelCode.GDwaste22Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste38Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste38Objects2_1final.indexOf(gdjs.LevelCode.GDwaste38Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste38Objects2_1final.push(gdjs.LevelCode.GDwaste38Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste4Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste4Objects2_1final.indexOf(gdjs.LevelCode.GDwaste4Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste4Objects2_1final.push(gdjs.LevelCode.GDwaste4Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste40Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste40Objects2_1final.indexOf(gdjs.LevelCode.GDwaste40Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste40Objects2_1final.push(gdjs.LevelCode.GDwaste40Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste5Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste5Objects2_1final.indexOf(gdjs.LevelCode.GDwaste5Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste5Objects2_1final.push(gdjs.LevelCode.GDwaste5Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste9Objects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste9Objects2_1final.indexOf(gdjs.LevelCode.GDwaste9Objects3[j]) === -1 )
            gdjs.LevelCode.GDwaste9Objects2_1final.push(gdjs.LevelCode.GDwaste9Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects2_1final, gdjs.LevelCode.GDGlassBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDOtherBoxObjects2_1final, gdjs.LevelCode.GDOtherBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects2_1final, gdjs.LevelCode.GDPlasticBoxObjects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste1Objects2_1final, gdjs.LevelCode.GDwaste1Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste11Objects2_1final, gdjs.LevelCode.GDwaste11Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste15Objects2_1final, gdjs.LevelCode.GDwaste15Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste22Objects2_1final, gdjs.LevelCode.GDwaste22Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste38Objects2_1final, gdjs.LevelCode.GDwaste38Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste4Objects2_1final, gdjs.LevelCode.GDwaste4Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste40Objects2_1final, gdjs.LevelCode.GDwaste40Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste5Objects2_1final, gdjs.LevelCode.GDwaste5Objects2);
gdjs.copyArray(gdjs.LevelCode.GDwaste9Objects2_1final, gdjs.LevelCode.GDwaste9Objects2);
}
}
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.LevelCode.GDLifeObjects2);
/* Reuse gdjs.LevelCode.GDwaste1Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

/* Reuse gdjs.LevelCode.GDwaste11Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste12Objects1, gdjs.LevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste13Objects1, gdjs.LevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste14Objects1, gdjs.LevelCode.GDwaste14Objects2);

/* Reuse gdjs.LevelCode.GDwaste15Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste2Objects1, gdjs.LevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

/* Reuse gdjs.LevelCode.GDwaste22Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste23Objects1, gdjs.LevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste24Objects1, gdjs.LevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste27Objects1, gdjs.LevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste28Objects1, gdjs.LevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste29Objects1, gdjs.LevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste30Objects1, gdjs.LevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste31Objects1, gdjs.LevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste35Objects1, gdjs.LevelCode.GDwaste35Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

/* Reuse gdjs.LevelCode.GDwaste38Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste39Objects1, gdjs.LevelCode.GDwaste39Objects2);

/* Reuse gdjs.LevelCode.GDwaste4Objects2 */
/* Reuse gdjs.LevelCode.GDwaste40Objects2 */
/* Reuse gdjs.LevelCode.GDwaste5Objects2 */
gdjs.copyArray(gdjs.LevelCode.GDwaste6Objects1, gdjs.LevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste7Objects1, gdjs.LevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste8Objects1, gdjs.LevelCode.GDwaste8Objects2);

/* Reuse gdjs.LevelCode.GDwaste9Objects2 */
{runtimeScene.getGame().getVariables().getFromIndex(2).sub(1);
}{for(var i = 0, len = gdjs.LevelCode.GDLifeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDLifeObjects2[i].setAnimationName("Life" + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.LevelCode.GDGlassBoxObjects1 */
/* Reuse gdjs.LevelCode.GDPaperBoxObjects1 */
/* Reuse gdjs.LevelCode.GDPlasticBoxObjects1 */
/* Reuse gdjs.LevelCode.GDwaste10Objects1 */
/* Reuse gdjs.LevelCode.GDwaste16Objects1 */
/* Reuse gdjs.LevelCode.GDwaste17Objects1 */
/* Reuse gdjs.LevelCode.GDwaste18Objects1 */
/* Reuse gdjs.LevelCode.GDwaste19Objects1 */
/* Reuse gdjs.LevelCode.GDwaste20Objects1 */
/* Reuse gdjs.LevelCode.GDwaste21Objects1 */
/* Reuse gdjs.LevelCode.GDwaste25Objects1 */
/* Reuse gdjs.LevelCode.GDwaste26Objects1 */
/* Reuse gdjs.LevelCode.GDwaste3Objects1 */
/* Reuse gdjs.LevelCode.GDwaste32Objects1 */
/* Reuse gdjs.LevelCode.GDwaste33Objects1 */
/* Reuse gdjs.LevelCode.GDwaste34Objects1 */
/* Reuse gdjs.LevelCode.GDwaste36Objects1 */
/* Reuse gdjs.LevelCode.GDwaste37Objects1 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 4;
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition1IsTrue_0;
gdjs.LevelCode.GDGlassBoxObjects1_1final.length = 0;gdjs.LevelCode.GDPaperBoxObjects1_1final.length = 0;gdjs.LevelCode.GDPlasticBoxObjects1_1final.length = 0;gdjs.LevelCode.GDwaste10Objects1_1final.length = 0;gdjs.LevelCode.GDwaste16Objects1_1final.length = 0;gdjs.LevelCode.GDwaste17Objects1_1final.length = 0;gdjs.LevelCode.GDwaste18Objects1_1final.length = 0;gdjs.LevelCode.GDwaste19Objects1_1final.length = 0;gdjs.LevelCode.GDwaste20Objects1_1final.length = 0;gdjs.LevelCode.GDwaste21Objects1_1final.length = 0;gdjs.LevelCode.GDwaste25Objects1_1final.length = 0;gdjs.LevelCode.GDwaste26Objects1_1final.length = 0;gdjs.LevelCode.GDwaste3Objects1_1final.length = 0;gdjs.LevelCode.GDwaste32Objects1_1final.length = 0;gdjs.LevelCode.GDwaste33Objects1_1final.length = 0;gdjs.LevelCode.GDwaste34Objects1_1final.length = 0;gdjs.LevelCode.GDwaste36Objects1_1final.length = 0;gdjs.LevelCode.GDwaste37Objects1_1final.length = 0;gdjs.LevelCode.condition0IsTrue_1.val = false;
gdjs.LevelCode.condition1IsTrue_1.val = false;
gdjs.LevelCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1, gdjs.LevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

gdjs.LevelCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste3Objects2ObjectsGDgdjs_46LevelCode_46GDwaste10Objects2ObjectsGDgdjs_46LevelCode_46GDwaste17Objects2ObjectsGDgdjs_46LevelCode_46GDwaste18Objects2ObjectsGDgdjs_46LevelCode_46GDwaste19Objects2ObjectsGDgdjs_46LevelCode_46GDwaste16Objects2ObjectsGDgdjs_46LevelCode_46GDwaste20Objects2ObjectsGDgdjs_46LevelCode_46GDwaste21Objects2ObjectsGDgdjs_46LevelCode_46GDwaste25Objects2ObjectsGDgdjs_46LevelCode_46GDwaste26Objects2ObjectsGDgdjs_46LevelCode_46GDwaste32Objects2ObjectsGDgdjs_46LevelCode_46GDwaste33Objects2ObjectsGDgdjs_46LevelCode_46GDwaste34Objects2ObjectsGDgdjs_46LevelCode_46GDwaste37Objects2ObjectsGDgdjs_46LevelCode_46GDwaste36Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects2Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition0IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDPlasticBoxObjects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDPlasticBoxObjects1_1final.indexOf(gdjs.LevelCode.GDPlasticBoxObjects2[j]) === -1 )
            gdjs.LevelCode.GDPlasticBoxObjects1_1final.push(gdjs.LevelCode.GDPlasticBoxObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste10Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste10Objects1_1final.indexOf(gdjs.LevelCode.GDwaste10Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste10Objects1_1final.push(gdjs.LevelCode.GDwaste10Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste16Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste16Objects1_1final.indexOf(gdjs.LevelCode.GDwaste16Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste16Objects1_1final.push(gdjs.LevelCode.GDwaste16Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste17Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste17Objects1_1final.indexOf(gdjs.LevelCode.GDwaste17Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste17Objects1_1final.push(gdjs.LevelCode.GDwaste17Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste18Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste18Objects1_1final.indexOf(gdjs.LevelCode.GDwaste18Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste18Objects1_1final.push(gdjs.LevelCode.GDwaste18Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste19Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste19Objects1_1final.indexOf(gdjs.LevelCode.GDwaste19Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste19Objects1_1final.push(gdjs.LevelCode.GDwaste19Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste20Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste20Objects1_1final.indexOf(gdjs.LevelCode.GDwaste20Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste20Objects1_1final.push(gdjs.LevelCode.GDwaste20Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste21Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste21Objects1_1final.indexOf(gdjs.LevelCode.GDwaste21Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste21Objects1_1final.push(gdjs.LevelCode.GDwaste21Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste25Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste25Objects1_1final.indexOf(gdjs.LevelCode.GDwaste25Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste25Objects1_1final.push(gdjs.LevelCode.GDwaste25Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste26Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste26Objects1_1final.indexOf(gdjs.LevelCode.GDwaste26Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste26Objects1_1final.push(gdjs.LevelCode.GDwaste26Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste3Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste3Objects1_1final.indexOf(gdjs.LevelCode.GDwaste3Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste3Objects1_1final.push(gdjs.LevelCode.GDwaste3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste32Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste32Objects1_1final.indexOf(gdjs.LevelCode.GDwaste32Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste32Objects1_1final.push(gdjs.LevelCode.GDwaste32Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste33Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste33Objects1_1final.indexOf(gdjs.LevelCode.GDwaste33Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste33Objects1_1final.push(gdjs.LevelCode.GDwaste33Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste34Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste34Objects1_1final.indexOf(gdjs.LevelCode.GDwaste34Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste34Objects1_1final.push(gdjs.LevelCode.GDwaste34Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste36Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste36Objects1_1final.indexOf(gdjs.LevelCode.GDwaste36Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste36Objects1_1final.push(gdjs.LevelCode.GDwaste36Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste37Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste37Objects1_1final.indexOf(gdjs.LevelCode.GDwaste37Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste37Objects1_1final.push(gdjs.LevelCode.GDwaste37Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1, gdjs.LevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

gdjs.LevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste3Objects2ObjectsGDgdjs_46LevelCode_46GDwaste10Objects2ObjectsGDgdjs_46LevelCode_46GDwaste17Objects2ObjectsGDgdjs_46LevelCode_46GDwaste18Objects2ObjectsGDgdjs_46LevelCode_46GDwaste19Objects2ObjectsGDgdjs_46LevelCode_46GDwaste16Objects2ObjectsGDgdjs_46LevelCode_46GDwaste20Objects2ObjectsGDgdjs_46LevelCode_46GDwaste21Objects2ObjectsGDgdjs_46LevelCode_46GDwaste25Objects2ObjectsGDgdjs_46LevelCode_46GDwaste26Objects2ObjectsGDgdjs_46LevelCode_46GDwaste32Objects2ObjectsGDgdjs_46LevelCode_46GDwaste33Objects2ObjectsGDgdjs_46LevelCode_46GDwaste34Objects2ObjectsGDgdjs_46LevelCode_46GDwaste37Objects2ObjectsGDgdjs_46LevelCode_46GDwaste36Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects2Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition1IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDGlassBoxObjects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDGlassBoxObjects1_1final.indexOf(gdjs.LevelCode.GDGlassBoxObjects2[j]) === -1 )
            gdjs.LevelCode.GDGlassBoxObjects1_1final.push(gdjs.LevelCode.GDGlassBoxObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste10Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste10Objects1_1final.indexOf(gdjs.LevelCode.GDwaste10Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste10Objects1_1final.push(gdjs.LevelCode.GDwaste10Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste16Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste16Objects1_1final.indexOf(gdjs.LevelCode.GDwaste16Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste16Objects1_1final.push(gdjs.LevelCode.GDwaste16Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste17Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste17Objects1_1final.indexOf(gdjs.LevelCode.GDwaste17Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste17Objects1_1final.push(gdjs.LevelCode.GDwaste17Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste18Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste18Objects1_1final.indexOf(gdjs.LevelCode.GDwaste18Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste18Objects1_1final.push(gdjs.LevelCode.GDwaste18Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste19Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste19Objects1_1final.indexOf(gdjs.LevelCode.GDwaste19Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste19Objects1_1final.push(gdjs.LevelCode.GDwaste19Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste20Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste20Objects1_1final.indexOf(gdjs.LevelCode.GDwaste20Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste20Objects1_1final.push(gdjs.LevelCode.GDwaste20Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste21Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste21Objects1_1final.indexOf(gdjs.LevelCode.GDwaste21Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste21Objects1_1final.push(gdjs.LevelCode.GDwaste21Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste25Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste25Objects1_1final.indexOf(gdjs.LevelCode.GDwaste25Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste25Objects1_1final.push(gdjs.LevelCode.GDwaste25Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste26Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste26Objects1_1final.indexOf(gdjs.LevelCode.GDwaste26Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste26Objects1_1final.push(gdjs.LevelCode.GDwaste26Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste3Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste3Objects1_1final.indexOf(gdjs.LevelCode.GDwaste3Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste3Objects1_1final.push(gdjs.LevelCode.GDwaste3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste32Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste32Objects1_1final.indexOf(gdjs.LevelCode.GDwaste32Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste32Objects1_1final.push(gdjs.LevelCode.GDwaste32Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste33Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste33Objects1_1final.indexOf(gdjs.LevelCode.GDwaste33Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste33Objects1_1final.push(gdjs.LevelCode.GDwaste33Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste34Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste34Objects1_1final.indexOf(gdjs.LevelCode.GDwaste34Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste34Objects1_1final.push(gdjs.LevelCode.GDwaste34Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste36Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste36Objects1_1final.indexOf(gdjs.LevelCode.GDwaste36Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste36Objects1_1final.push(gdjs.LevelCode.GDwaste36Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste37Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste37Objects1_1final.indexOf(gdjs.LevelCode.GDwaste37Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste37Objects1_1final.push(gdjs.LevelCode.GDwaste37Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects1, gdjs.LevelCode.GDPaperBoxObjects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1, gdjs.LevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1, gdjs.LevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1, gdjs.LevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1, gdjs.LevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1, gdjs.LevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1, gdjs.LevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1, gdjs.LevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1, gdjs.LevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1, gdjs.LevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1, gdjs.LevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1, gdjs.LevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1, gdjs.LevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1, gdjs.LevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1, gdjs.LevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1, gdjs.LevelCode.GDwaste37Objects2);

gdjs.LevelCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste3Objects2ObjectsGDgdjs_46LevelCode_46GDwaste10Objects2ObjectsGDgdjs_46LevelCode_46GDwaste17Objects2ObjectsGDgdjs_46LevelCode_46GDwaste18Objects2ObjectsGDgdjs_46LevelCode_46GDwaste19Objects2ObjectsGDgdjs_46LevelCode_46GDwaste16Objects2ObjectsGDgdjs_46LevelCode_46GDwaste20Objects2ObjectsGDgdjs_46LevelCode_46GDwaste21Objects2ObjectsGDgdjs_46LevelCode_46GDwaste25Objects2ObjectsGDgdjs_46LevelCode_46GDwaste26Objects2ObjectsGDgdjs_46LevelCode_46GDwaste32Objects2ObjectsGDgdjs_46LevelCode_46GDwaste33Objects2ObjectsGDgdjs_46LevelCode_46GDwaste34Objects2ObjectsGDgdjs_46LevelCode_46GDwaste37Objects2ObjectsGDgdjs_46LevelCode_46GDwaste36Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects2Objects, false, runtimeScene, false);
if( gdjs.LevelCode.condition2IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDPaperBoxObjects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDPaperBoxObjects1_1final.indexOf(gdjs.LevelCode.GDPaperBoxObjects2[j]) === -1 )
            gdjs.LevelCode.GDPaperBoxObjects1_1final.push(gdjs.LevelCode.GDPaperBoxObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste10Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste10Objects1_1final.indexOf(gdjs.LevelCode.GDwaste10Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste10Objects1_1final.push(gdjs.LevelCode.GDwaste10Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste16Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste16Objects1_1final.indexOf(gdjs.LevelCode.GDwaste16Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste16Objects1_1final.push(gdjs.LevelCode.GDwaste16Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste17Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste17Objects1_1final.indexOf(gdjs.LevelCode.GDwaste17Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste17Objects1_1final.push(gdjs.LevelCode.GDwaste17Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste18Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste18Objects1_1final.indexOf(gdjs.LevelCode.GDwaste18Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste18Objects1_1final.push(gdjs.LevelCode.GDwaste18Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste19Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste19Objects1_1final.indexOf(gdjs.LevelCode.GDwaste19Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste19Objects1_1final.push(gdjs.LevelCode.GDwaste19Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste20Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste20Objects1_1final.indexOf(gdjs.LevelCode.GDwaste20Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste20Objects1_1final.push(gdjs.LevelCode.GDwaste20Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste21Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste21Objects1_1final.indexOf(gdjs.LevelCode.GDwaste21Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste21Objects1_1final.push(gdjs.LevelCode.GDwaste21Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste25Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste25Objects1_1final.indexOf(gdjs.LevelCode.GDwaste25Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste25Objects1_1final.push(gdjs.LevelCode.GDwaste25Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste26Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste26Objects1_1final.indexOf(gdjs.LevelCode.GDwaste26Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste26Objects1_1final.push(gdjs.LevelCode.GDwaste26Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste3Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste3Objects1_1final.indexOf(gdjs.LevelCode.GDwaste3Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste3Objects1_1final.push(gdjs.LevelCode.GDwaste3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste32Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste32Objects1_1final.indexOf(gdjs.LevelCode.GDwaste32Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste32Objects1_1final.push(gdjs.LevelCode.GDwaste32Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste33Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste33Objects1_1final.indexOf(gdjs.LevelCode.GDwaste33Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste33Objects1_1final.push(gdjs.LevelCode.GDwaste33Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste34Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste34Objects1_1final.indexOf(gdjs.LevelCode.GDwaste34Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste34Objects1_1final.push(gdjs.LevelCode.GDwaste34Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste36Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste36Objects1_1final.indexOf(gdjs.LevelCode.GDwaste36Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste36Objects1_1final.push(gdjs.LevelCode.GDwaste36Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDwaste37Objects2.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDwaste37Objects1_1final.indexOf(gdjs.LevelCode.GDwaste37Objects2[j]) === -1 )
            gdjs.LevelCode.GDwaste37Objects1_1final.push(gdjs.LevelCode.GDwaste37Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDGlassBoxObjects1_1final, gdjs.LevelCode.GDGlassBoxObjects1);
gdjs.copyArray(gdjs.LevelCode.GDPaperBoxObjects1_1final, gdjs.LevelCode.GDPaperBoxObjects1);
gdjs.copyArray(gdjs.LevelCode.GDPlasticBoxObjects1_1final, gdjs.LevelCode.GDPlasticBoxObjects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste10Objects1_1final, gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste16Objects1_1final, gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste17Objects1_1final, gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste18Objects1_1final, gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste19Objects1_1final, gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste20Objects1_1final, gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste21Objects1_1final, gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste25Objects1_1final, gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste26Objects1_1final, gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste3Objects1_1final, gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste32Objects1_1final, gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste33Objects1_1final, gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste34Objects1_1final, gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste36Objects1_1final, gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(gdjs.LevelCode.GDwaste37Objects1_1final, gdjs.LevelCode.GDwaste37Objects1);
}
}
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.LevelCode.GDLifeObjects1);
/* Reuse gdjs.LevelCode.GDwaste1Objects1 */
/* Reuse gdjs.LevelCode.GDwaste10Objects1 */
/* Reuse gdjs.LevelCode.GDwaste11Objects1 */
/* Reuse gdjs.LevelCode.GDwaste12Objects1 */
/* Reuse gdjs.LevelCode.GDwaste13Objects1 */
/* Reuse gdjs.LevelCode.GDwaste14Objects1 */
/* Reuse gdjs.LevelCode.GDwaste15Objects1 */
/* Reuse gdjs.LevelCode.GDwaste16Objects1 */
/* Reuse gdjs.LevelCode.GDwaste17Objects1 */
/* Reuse gdjs.LevelCode.GDwaste18Objects1 */
/* Reuse gdjs.LevelCode.GDwaste19Objects1 */
/* Reuse gdjs.LevelCode.GDwaste2Objects1 */
/* Reuse gdjs.LevelCode.GDwaste20Objects1 */
/* Reuse gdjs.LevelCode.GDwaste21Objects1 */
/* Reuse gdjs.LevelCode.GDwaste22Objects1 */
/* Reuse gdjs.LevelCode.GDwaste23Objects1 */
/* Reuse gdjs.LevelCode.GDwaste24Objects1 */
/* Reuse gdjs.LevelCode.GDwaste25Objects1 */
/* Reuse gdjs.LevelCode.GDwaste26Objects1 */
/* Reuse gdjs.LevelCode.GDwaste27Objects1 */
/* Reuse gdjs.LevelCode.GDwaste28Objects1 */
/* Reuse gdjs.LevelCode.GDwaste29Objects1 */
/* Reuse gdjs.LevelCode.GDwaste3Objects1 */
/* Reuse gdjs.LevelCode.GDwaste30Objects1 */
/* Reuse gdjs.LevelCode.GDwaste31Objects1 */
/* Reuse gdjs.LevelCode.GDwaste32Objects1 */
/* Reuse gdjs.LevelCode.GDwaste33Objects1 */
/* Reuse gdjs.LevelCode.GDwaste34Objects1 */
/* Reuse gdjs.LevelCode.GDwaste35Objects1 */
/* Reuse gdjs.LevelCode.GDwaste36Objects1 */
/* Reuse gdjs.LevelCode.GDwaste37Objects1 */
/* Reuse gdjs.LevelCode.GDwaste38Objects1 */
/* Reuse gdjs.LevelCode.GDwaste39Objects1 */
/* Reuse gdjs.LevelCode.GDwaste4Objects1 */
/* Reuse gdjs.LevelCode.GDwaste40Objects1 */
/* Reuse gdjs.LevelCode.GDwaste5Objects1 */
/* Reuse gdjs.LevelCode.GDwaste6Objects1 */
/* Reuse gdjs.LevelCode.GDwaste7Objects1 */
/* Reuse gdjs.LevelCode.GDwaste8Objects1 */
/* Reuse gdjs.LevelCode.GDwaste9Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(2).sub(1);
}{for(var i = 0, len = gdjs.LevelCode.GDLifeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDLifeObjects1[i].setAnimationName("Life" + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPrevObjects1Objects = Hashtable.newFrom({"Prev": gdjs.LevelCode.GDPrevObjects1});gdjs.LevelCode.eventsList11 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "start.mp3", 1, true, 100, 1);
}}

}


};gdjs.LevelCode.eventsList12 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "ModeMenu", false);
}
{ //Subevents
gdjs.LevelCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects1ObjectsGDgdjs_46LevelCode_46GDwaste2Objects1ObjectsGDgdjs_46LevelCode_46GDwaste3Objects1ObjectsGDgdjs_46LevelCode_46GDwaste4Objects1ObjectsGDgdjs_46LevelCode_46GDwaste5Objects1ObjectsGDgdjs_46LevelCode_46GDwaste6Objects1ObjectsGDgdjs_46LevelCode_46GDwaste7Objects1ObjectsGDgdjs_46LevelCode_46GDwaste8Objects1ObjectsGDgdjs_46LevelCode_46GDwaste9Objects1ObjectsGDgdjs_46LevelCode_46GDwaste10Objects1ObjectsGDgdjs_46LevelCode_46GDwaste11Objects1ObjectsGDgdjs_46LevelCode_46GDwaste12Objects1ObjectsGDgdjs_46LevelCode_46GDwaste13Objects1ObjectsGDgdjs_46LevelCode_46GDwaste14Objects1ObjectsGDgdjs_46LevelCode_46GDwaste15Objects1ObjectsGDgdjs_46LevelCode_46GDwaste17Objects1ObjectsGDgdjs_46LevelCode_46GDwaste18Objects1ObjectsGDgdjs_46LevelCode_46GDwaste19Objects1ObjectsGDgdjs_46LevelCode_46GDwaste16Objects1ObjectsGDgdjs_46LevelCode_46GDwaste20Objects1ObjectsGDgdjs_46LevelCode_46GDwaste21Objects1ObjectsGDgdjs_46LevelCode_46GDwaste22Objects1ObjectsGDgdjs_46LevelCode_46GDwaste23Objects1ObjectsGDgdjs_46LevelCode_46GDwaste24Objects1ObjectsGDgdjs_46LevelCode_46GDwaste25Objects1ObjectsGDgdjs_46LevelCode_46GDwaste26Objects1ObjectsGDgdjs_46LevelCode_46GDwaste27Objects1ObjectsGDgdjs_46LevelCode_46GDwaste29Objects1ObjectsGDgdjs_46LevelCode_46GDwaste30Objects1ObjectsGDgdjs_46LevelCode_46GDwaste31Objects1ObjectsGDgdjs_46LevelCode_46GDwaste32Objects1ObjectsGDgdjs_46LevelCode_46GDwaste33Objects1ObjectsGDgdjs_46LevelCode_46GDwaste34Objects1ObjectsGDgdjs_46LevelCode_46GDwaste35Objects1ObjectsGDgdjs_46LevelCode_46GDwaste36Objects1ObjectsGDgdjs_46LevelCode_46GDwaste37Objects1ObjectsGDgdjs_46LevelCode_46GDwaste38Objects1ObjectsGDgdjs_46LevelCode_46GDwaste39Objects1ObjectsGDgdjs_46LevelCode_46GDwaste40Objects1ObjectsGDgdjs_46LevelCode_46GDwaste28Objects1Objects = Hashtable.newFrom({"waste1": gdjs.LevelCode.GDwaste1Objects1, "waste2": gdjs.LevelCode.GDwaste2Objects1, "waste3": gdjs.LevelCode.GDwaste3Objects1, "waste4": gdjs.LevelCode.GDwaste4Objects1, "waste5": gdjs.LevelCode.GDwaste5Objects1, "waste6": gdjs.LevelCode.GDwaste6Objects1, "waste7": gdjs.LevelCode.GDwaste7Objects1, "waste8": gdjs.LevelCode.GDwaste8Objects1, "waste9": gdjs.LevelCode.GDwaste9Objects1, "waste10": gdjs.LevelCode.GDwaste10Objects1, "waste11": gdjs.LevelCode.GDwaste11Objects1, "waste12": gdjs.LevelCode.GDwaste12Objects1, "waste13": gdjs.LevelCode.GDwaste13Objects1, "waste14": gdjs.LevelCode.GDwaste14Objects1, "waste15": gdjs.LevelCode.GDwaste15Objects1, "waste17": gdjs.LevelCode.GDwaste17Objects1, "waste18": gdjs.LevelCode.GDwaste18Objects1, "waste19": gdjs.LevelCode.GDwaste19Objects1, "waste16": gdjs.LevelCode.GDwaste16Objects1, "waste20": gdjs.LevelCode.GDwaste20Objects1, "waste21": gdjs.LevelCode.GDwaste21Objects1, "waste22": gdjs.LevelCode.GDwaste22Objects1, "waste23": gdjs.LevelCode.GDwaste23Objects1, "waste24": gdjs.LevelCode.GDwaste24Objects1, "waste25": gdjs.LevelCode.GDwaste25Objects1, "waste26": gdjs.LevelCode.GDwaste26Objects1, "waste27": gdjs.LevelCode.GDwaste27Objects1, "waste29": gdjs.LevelCode.GDwaste29Objects1, "waste30": gdjs.LevelCode.GDwaste30Objects1, "waste31": gdjs.LevelCode.GDwaste31Objects1, "waste32": gdjs.LevelCode.GDwaste32Objects1, "waste33": gdjs.LevelCode.GDwaste33Objects1, "waste34": gdjs.LevelCode.GDwaste34Objects1, "waste35": gdjs.LevelCode.GDwaste35Objects1, "waste36": gdjs.LevelCode.GDwaste36Objects1, "waste37": gdjs.LevelCode.GDwaste37Objects1, "waste38": gdjs.LevelCode.GDwaste38Objects1, "waste39": gdjs.LevelCode.GDwaste39Objects1, "waste40": gdjs.LevelCode.GDwaste40Objects1, "waste28": gdjs.LevelCode.GDwaste28Objects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDCleanButtonObjects1Objects = Hashtable.newFrom({"CleanButton": gdjs.LevelCode.GDCleanButtonObjects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDCleanButtonObjects1Objects = Hashtable.newFrom({"CleanButton": gdjs.LevelCode.GDCleanButtonObjects1});gdjs.LevelCode.eventsList13 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "помыть.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.eventsList14 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].returnVariable(gdjs.LevelCode.GDwaste1Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].returnVariable(gdjs.LevelCode.GDwaste2Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].returnVariable(gdjs.LevelCode.GDwaste3Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].returnVariable(gdjs.LevelCode.GDwaste4Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].returnVariable(gdjs.LevelCode.GDwaste5Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].returnVariable(gdjs.LevelCode.GDwaste6Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].returnVariable(gdjs.LevelCode.GDwaste7Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].returnVariable(gdjs.LevelCode.GDwaste8Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].returnVariable(gdjs.LevelCode.GDwaste9Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].returnVariable(gdjs.LevelCode.GDwaste10Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].returnVariable(gdjs.LevelCode.GDwaste11Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].returnVariable(gdjs.LevelCode.GDwaste12Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].returnVariable(gdjs.LevelCode.GDwaste13Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].returnVariable(gdjs.LevelCode.GDwaste14Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].returnVariable(gdjs.LevelCode.GDwaste15Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].returnVariable(gdjs.LevelCode.GDwaste17Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].returnVariable(gdjs.LevelCode.GDwaste18Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].returnVariable(gdjs.LevelCode.GDwaste19Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].returnVariable(gdjs.LevelCode.GDwaste16Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].returnVariable(gdjs.LevelCode.GDwaste20Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].returnVariable(gdjs.LevelCode.GDwaste21Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].returnVariable(gdjs.LevelCode.GDwaste22Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].returnVariable(gdjs.LevelCode.GDwaste23Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].returnVariable(gdjs.LevelCode.GDwaste24Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].returnVariable(gdjs.LevelCode.GDwaste25Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].returnVariable(gdjs.LevelCode.GDwaste26Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].returnVariable(gdjs.LevelCode.GDwaste27Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].returnVariable(gdjs.LevelCode.GDwaste29Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].returnVariable(gdjs.LevelCode.GDwaste30Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].returnVariable(gdjs.LevelCode.GDwaste31Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].returnVariable(gdjs.LevelCode.GDwaste32Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].returnVariable(gdjs.LevelCode.GDwaste33Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].returnVariable(gdjs.LevelCode.GDwaste34Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].returnVariable(gdjs.LevelCode.GDwaste35Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].returnVariable(gdjs.LevelCode.GDwaste36Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].returnVariable(gdjs.LevelCode.GDwaste37Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].returnVariable(gdjs.LevelCode.GDwaste38Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].returnVariable(gdjs.LevelCode.GDwaste39Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].returnVariable(gdjs.LevelCode.GDwaste40Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].returnVariable(gdjs.LevelCode.GDwaste28Objects1[i].getVariables().get("Clean")).setNumber(1);
}
}
{ //Subevents
gdjs.LevelCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList15 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.LevelCode.GDSoundObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDSoundObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDSoundObjects2[i].setAnimationName("On");
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "play.mp3", 1, true, 70, 1);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 0;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.LevelCode.GDSoundObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDSoundObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDSoundObjects1[i].setAnimationName("Off");
}
}}

}


};gdjs.LevelCode.eventsList16 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition1IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12551676);
}
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "игра окончена.mp3", false, 100, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDSoundObjects1Objects = Hashtable.newFrom({"Sound": gdjs.LevelCode.GDSoundObjects1});gdjs.LevelCode.eventsList17 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 0;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "play.mp3", 1, false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}}

}


};gdjs.LevelCode.eventsList18 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDSoundObjects1, gdjs.LevelCode.GDSoundObjects2);

{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(0);
}{for(var i = 0, len = gdjs.LevelCode.GDSoundObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDSoundObjects2[i].setAnimationName("Off");
}
}{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 0;
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDSoundObjects1 */
{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(1);
}{for(var i = 0, len = gdjs.LevelCode.GDSoundObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDSoundObjects1[i].setAnimationName("On");
}
}
{ //Subevents
gdjs.LevelCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.LevelCode.GDSoundObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDSoundObjects1Objects, runtimeScene, true, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}
{ //Subevents
gdjs.LevelCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList20 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(4), true);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Score", false);
}}

}


};gdjs.LevelCode.eventsList21 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlasticBox"), gdjs.LevelCode.GDPlasticBoxObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlasticBoxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlasticBox"), gdjs.LevelCode.GDPlasticBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GlassBox"), gdjs.LevelCode.GDGlassBoxObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDGlassBoxObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDGlassBoxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(2);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GlassBox"), gdjs.LevelCode.GDGlassBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.LevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.LevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(2);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PaperBox"), gdjs.LevelCode.GDPaperBoxObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPaperBoxObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPaperBoxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(3);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PaperBox"), gdjs.LevelCode.GDPaperBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.LevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.LevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(3);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("OtherBox"), gdjs.LevelCode.GDOtherBoxObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDOtherBoxObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDOtherBoxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(4);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("OtherBox"), gdjs.LevelCode.GDOtherBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.LevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.LevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(4);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.5, "WasteCreation");
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects1ObjectsGDgdjs_46LevelCode_46GDwaste2Objects1ObjectsGDgdjs_46LevelCode_46GDwaste3Objects1ObjectsGDgdjs_46LevelCode_46GDwaste4Objects1ObjectsGDgdjs_46LevelCode_46GDwaste5Objects1ObjectsGDgdjs_46LevelCode_46GDwaste6Objects1ObjectsGDgdjs_46LevelCode_46GDwaste7Objects1ObjectsGDgdjs_46LevelCode_46GDwaste8Objects1ObjectsGDgdjs_46LevelCode_46GDwaste9Objects1ObjectsGDgdjs_46LevelCode_46GDwaste10Objects1ObjectsGDgdjs_46LevelCode_46GDwaste11Objects1ObjectsGDgdjs_46LevelCode_46GDwaste12Objects1ObjectsGDgdjs_46LevelCode_46GDwaste13Objects1ObjectsGDgdjs_46LevelCode_46GDwaste14Objects1ObjectsGDgdjs_46LevelCode_46GDwaste15Objects1ObjectsGDgdjs_46LevelCode_46GDwaste17Objects1ObjectsGDgdjs_46LevelCode_46GDwaste18Objects1ObjectsGDgdjs_46LevelCode_46GDwaste19Objects1ObjectsGDgdjs_46LevelCode_46GDwaste16Objects1ObjectsGDgdjs_46LevelCode_46GDwaste20Objects1ObjectsGDgdjs_46LevelCode_46GDwaste21Objects1ObjectsGDgdjs_46LevelCode_46GDwaste22Objects1ObjectsGDgdjs_46LevelCode_46GDwaste23Objects1ObjectsGDgdjs_46LevelCode_46GDwaste24Objects1ObjectsGDgdjs_46LevelCode_46GDwaste25Objects1ObjectsGDgdjs_46LevelCode_46GDwaste26Objects1ObjectsGDgdjs_46LevelCode_46GDwaste27Objects1ObjectsGDgdjs_46LevelCode_46GDwaste29Objects1ObjectsGDgdjs_46LevelCode_46GDwaste30Objects1ObjectsGDgdjs_46LevelCode_46GDwaste31Objects1ObjectsGDgdjs_46LevelCode_46GDwaste32Objects1ObjectsGDgdjs_46LevelCode_46GDwaste33Objects1ObjectsGDgdjs_46LevelCode_46GDwaste34Objects1ObjectsGDgdjs_46LevelCode_46GDwaste35Objects1ObjectsGDgdjs_46LevelCode_46GDwaste36Objects1ObjectsGDgdjs_46LevelCode_46GDwaste37Objects1ObjectsGDgdjs_46LevelCode_46GDwaste38Objects1ObjectsGDgdjs_46LevelCode_46GDwaste39Objects1ObjectsGDgdjs_46LevelCode_46GDwaste40Objects1ObjectsGDgdjs_46LevelCode_46GDwaste28Objects1Objects) < 1;
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.LevelCode.GDLifeObjects1);
/* Reuse gdjs.LevelCode.GDwaste1Objects1 */
/* Reuse gdjs.LevelCode.GDwaste10Objects1 */
/* Reuse gdjs.LevelCode.GDwaste11Objects1 */
/* Reuse gdjs.LevelCode.GDwaste12Objects1 */
/* Reuse gdjs.LevelCode.GDwaste13Objects1 */
/* Reuse gdjs.LevelCode.GDwaste14Objects1 */
/* Reuse gdjs.LevelCode.GDwaste15Objects1 */
/* Reuse gdjs.LevelCode.GDwaste16Objects1 */
/* Reuse gdjs.LevelCode.GDwaste17Objects1 */
/* Reuse gdjs.LevelCode.GDwaste18Objects1 */
/* Reuse gdjs.LevelCode.GDwaste19Objects1 */
/* Reuse gdjs.LevelCode.GDwaste2Objects1 */
/* Reuse gdjs.LevelCode.GDwaste20Objects1 */
/* Reuse gdjs.LevelCode.GDwaste21Objects1 */
/* Reuse gdjs.LevelCode.GDwaste22Objects1 */
/* Reuse gdjs.LevelCode.GDwaste23Objects1 */
/* Reuse gdjs.LevelCode.GDwaste24Objects1 */
/* Reuse gdjs.LevelCode.GDwaste25Objects1 */
/* Reuse gdjs.LevelCode.GDwaste26Objects1 */
/* Reuse gdjs.LevelCode.GDwaste27Objects1 */
/* Reuse gdjs.LevelCode.GDwaste28Objects1 */
/* Reuse gdjs.LevelCode.GDwaste29Objects1 */
/* Reuse gdjs.LevelCode.GDwaste3Objects1 */
/* Reuse gdjs.LevelCode.GDwaste30Objects1 */
/* Reuse gdjs.LevelCode.GDwaste31Objects1 */
/* Reuse gdjs.LevelCode.GDwaste32Objects1 */
/* Reuse gdjs.LevelCode.GDwaste33Objects1 */
/* Reuse gdjs.LevelCode.GDwaste34Objects1 */
/* Reuse gdjs.LevelCode.GDwaste35Objects1 */
/* Reuse gdjs.LevelCode.GDwaste36Objects1 */
/* Reuse gdjs.LevelCode.GDwaste37Objects1 */
/* Reuse gdjs.LevelCode.GDwaste38Objects1 */
/* Reuse gdjs.LevelCode.GDwaste39Objects1 */
/* Reuse gdjs.LevelCode.GDwaste4Objects1 */
/* Reuse gdjs.LevelCode.GDwaste40Objects1 */
/* Reuse gdjs.LevelCode.GDwaste5Objects1 */
/* Reuse gdjs.LevelCode.GDwaste6Objects1 */
/* Reuse gdjs.LevelCode.GDwaste7Objects1 */
/* Reuse gdjs.LevelCode.GDwaste8Objects1 */
/* Reuse gdjs.LevelCode.GDwaste9Objects1 */
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects1ObjectsGDgdjs_46LevelCode_46GDwaste2Objects1ObjectsGDgdjs_46LevelCode_46GDwaste3Objects1ObjectsGDgdjs_46LevelCode_46GDwaste4Objects1ObjectsGDgdjs_46LevelCode_46GDwaste5Objects1ObjectsGDgdjs_46LevelCode_46GDwaste6Objects1ObjectsGDgdjs_46LevelCode_46GDwaste7Objects1ObjectsGDgdjs_46LevelCode_46GDwaste8Objects1ObjectsGDgdjs_46LevelCode_46GDwaste9Objects1ObjectsGDgdjs_46LevelCode_46GDwaste10Objects1ObjectsGDgdjs_46LevelCode_46GDwaste11Objects1ObjectsGDgdjs_46LevelCode_46GDwaste12Objects1ObjectsGDgdjs_46LevelCode_46GDwaste13Objects1ObjectsGDgdjs_46LevelCode_46GDwaste14Objects1ObjectsGDgdjs_46LevelCode_46GDwaste15Objects1ObjectsGDgdjs_46LevelCode_46GDwaste17Objects1ObjectsGDgdjs_46LevelCode_46GDwaste18Objects1ObjectsGDgdjs_46LevelCode_46GDwaste19Objects1ObjectsGDgdjs_46LevelCode_46GDwaste16Objects1ObjectsGDgdjs_46LevelCode_46GDwaste20Objects1ObjectsGDgdjs_46LevelCode_46GDwaste21Objects1ObjectsGDgdjs_46LevelCode_46GDwaste22Objects1ObjectsGDgdjs_46LevelCode_46GDwaste23Objects1ObjectsGDgdjs_46LevelCode_46GDwaste24Objects1ObjectsGDgdjs_46LevelCode_46GDwaste25Objects1ObjectsGDgdjs_46LevelCode_46GDwaste26Objects1ObjectsGDgdjs_46LevelCode_46GDwaste27Objects1ObjectsGDgdjs_46LevelCode_46GDwaste29Objects1ObjectsGDgdjs_46LevelCode_46GDwaste30Objects1ObjectsGDgdjs_46LevelCode_46GDwaste31Objects1ObjectsGDgdjs_46LevelCode_46GDwaste32Objects1ObjectsGDgdjs_46LevelCode_46GDwaste33Objects1ObjectsGDgdjs_46LevelCode_46GDwaste34Objects1ObjectsGDgdjs_46LevelCode_46GDwaste35Objects1ObjectsGDgdjs_46LevelCode_46GDwaste36Objects1ObjectsGDgdjs_46LevelCode_46GDwaste37Objects1ObjectsGDgdjs_46LevelCode_46GDwaste38Objects1ObjectsGDgdjs_46LevelCode_46GDwaste39Objects1ObjectsGDgdjs_46LevelCode_46GDwaste40Objects1ObjectsGDgdjs_46LevelCode_46GDwaste28Objects1Objects, "waste" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 40)), 376, 360, "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "WasteCreation");
}{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].returnVariable(gdjs.LevelCode.GDwaste1Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].returnVariable(gdjs.LevelCode.GDwaste2Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].returnVariable(gdjs.LevelCode.GDwaste3Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].returnVariable(gdjs.LevelCode.GDwaste4Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].returnVariable(gdjs.LevelCode.GDwaste5Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].returnVariable(gdjs.LevelCode.GDwaste6Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].returnVariable(gdjs.LevelCode.GDwaste7Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].returnVariable(gdjs.LevelCode.GDwaste8Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].returnVariable(gdjs.LevelCode.GDwaste9Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].returnVariable(gdjs.LevelCode.GDwaste10Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].returnVariable(gdjs.LevelCode.GDwaste11Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].returnVariable(gdjs.LevelCode.GDwaste12Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].returnVariable(gdjs.LevelCode.GDwaste13Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].returnVariable(gdjs.LevelCode.GDwaste14Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].returnVariable(gdjs.LevelCode.GDwaste15Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].returnVariable(gdjs.LevelCode.GDwaste17Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].returnVariable(gdjs.LevelCode.GDwaste18Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].returnVariable(gdjs.LevelCode.GDwaste19Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].returnVariable(gdjs.LevelCode.GDwaste16Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].returnVariable(gdjs.LevelCode.GDwaste20Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].returnVariable(gdjs.LevelCode.GDwaste21Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].returnVariable(gdjs.LevelCode.GDwaste22Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].returnVariable(gdjs.LevelCode.GDwaste23Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].returnVariable(gdjs.LevelCode.GDwaste24Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].returnVariable(gdjs.LevelCode.GDwaste25Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].returnVariable(gdjs.LevelCode.GDwaste26Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].returnVariable(gdjs.LevelCode.GDwaste27Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].returnVariable(gdjs.LevelCode.GDwaste29Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].returnVariable(gdjs.LevelCode.GDwaste30Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].returnVariable(gdjs.LevelCode.GDwaste31Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].returnVariable(gdjs.LevelCode.GDwaste32Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].returnVariable(gdjs.LevelCode.GDwaste33Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].returnVariable(gdjs.LevelCode.GDwaste34Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].returnVariable(gdjs.LevelCode.GDwaste35Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].returnVariable(gdjs.LevelCode.GDwaste36Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].returnVariable(gdjs.LevelCode.GDwaste37Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].returnVariable(gdjs.LevelCode.GDwaste38Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].returnVariable(gdjs.LevelCode.GDwaste39Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].returnVariable(gdjs.LevelCode.GDwaste40Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].returnVariable(gdjs.LevelCode.GDwaste28Objects1[i].getVariables().get("Clean")).setNumber(0);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}{for(var i = 0, len = gdjs.LevelCode.GDLifeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDLifeObjects1[i].setAnimationName("Life" + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}}

}


{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 0;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = !(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 0);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].addPolarForce(0, 0, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GlassBox"), gdjs.LevelCode.GDGlassBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("OtherBox"), gdjs.LevelCode.GDOtherBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("PaperBox"), gdjs.LevelCode.GDPaperBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlasticBox"), gdjs.LevelCode.GDPlasticBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlasticBoxObjects1ObjectsGDgdjs_46LevelCode_46GDGlassBoxObjects1ObjectsGDgdjs_46LevelCode_46GDPaperBoxObjects1ObjectsGDgdjs_46LevelCode_46GDOtherBoxObjects1Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects1ObjectsGDgdjs_46LevelCode_46GDwaste2Objects1ObjectsGDgdjs_46LevelCode_46GDwaste3Objects1ObjectsGDgdjs_46LevelCode_46GDwaste4Objects1ObjectsGDgdjs_46LevelCode_46GDwaste5Objects1ObjectsGDgdjs_46LevelCode_46GDwaste6Objects1ObjectsGDgdjs_46LevelCode_46GDwaste7Objects1ObjectsGDgdjs_46LevelCode_46GDwaste8Objects1ObjectsGDgdjs_46LevelCode_46GDwaste9Objects1ObjectsGDgdjs_46LevelCode_46GDwaste10Objects1ObjectsGDgdjs_46LevelCode_46GDwaste11Objects1ObjectsGDgdjs_46LevelCode_46GDwaste12Objects1ObjectsGDgdjs_46LevelCode_46GDwaste13Objects1ObjectsGDgdjs_46LevelCode_46GDwaste14Objects1ObjectsGDgdjs_46LevelCode_46GDwaste15Objects1ObjectsGDgdjs_46LevelCode_46GDwaste17Objects1ObjectsGDgdjs_46LevelCode_46GDwaste18Objects1ObjectsGDgdjs_46LevelCode_46GDwaste19Objects1ObjectsGDgdjs_46LevelCode_46GDwaste16Objects1ObjectsGDgdjs_46LevelCode_46GDwaste20Objects1ObjectsGDgdjs_46LevelCode_46GDwaste21Objects1ObjectsGDgdjs_46LevelCode_46GDwaste22Objects1ObjectsGDgdjs_46LevelCode_46GDwaste23Objects1ObjectsGDgdjs_46LevelCode_46GDwaste24Objects1ObjectsGDgdjs_46LevelCode_46GDwaste25Objects1ObjectsGDgdjs_46LevelCode_46GDwaste26Objects1ObjectsGDgdjs_46LevelCode_46GDwaste27Objects1ObjectsGDgdjs_46LevelCode_46GDwaste29Objects1ObjectsGDgdjs_46LevelCode_46GDwaste30Objects1ObjectsGDgdjs_46LevelCode_46GDwaste31Objects1ObjectsGDgdjs_46LevelCode_46GDwaste32Objects1ObjectsGDgdjs_46LevelCode_46GDwaste33Objects1ObjectsGDgdjs_46LevelCode_46GDwaste34Objects1ObjectsGDgdjs_46LevelCode_46GDwaste35Objects1ObjectsGDgdjs_46LevelCode_46GDwaste36Objects1ObjectsGDgdjs_46LevelCode_46GDwaste37Objects1ObjectsGDgdjs_46LevelCode_46GDwaste38Objects1ObjectsGDgdjs_46LevelCode_46GDwaste39Objects1ObjectsGDgdjs_46LevelCode_46GDwaste40Objects1ObjectsGDgdjs_46LevelCode_46GDwaste28Objects1Objects, false, runtimeScene, true);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Prev"), gdjs.LevelCode.GDPrevObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPrevObjects1Objects, runtimeScene, true, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("CleanButton"), gdjs.LevelCode.GDCleanButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDwaste1Objects1ObjectsGDgdjs_46LevelCode_46GDwaste2Objects1ObjectsGDgdjs_46LevelCode_46GDwaste3Objects1ObjectsGDgdjs_46LevelCode_46GDwaste4Objects1ObjectsGDgdjs_46LevelCode_46GDwaste5Objects1ObjectsGDgdjs_46LevelCode_46GDwaste6Objects1ObjectsGDgdjs_46LevelCode_46GDwaste7Objects1ObjectsGDgdjs_46LevelCode_46GDwaste8Objects1ObjectsGDgdjs_46LevelCode_46GDwaste9Objects1ObjectsGDgdjs_46LevelCode_46GDwaste10Objects1ObjectsGDgdjs_46LevelCode_46GDwaste11Objects1ObjectsGDgdjs_46LevelCode_46GDwaste12Objects1ObjectsGDgdjs_46LevelCode_46GDwaste13Objects1ObjectsGDgdjs_46LevelCode_46GDwaste14Objects1ObjectsGDgdjs_46LevelCode_46GDwaste15Objects1ObjectsGDgdjs_46LevelCode_46GDwaste17Objects1ObjectsGDgdjs_46LevelCode_46GDwaste18Objects1ObjectsGDgdjs_46LevelCode_46GDwaste19Objects1ObjectsGDgdjs_46LevelCode_46GDwaste16Objects1ObjectsGDgdjs_46LevelCode_46GDwaste20Objects1ObjectsGDgdjs_46LevelCode_46GDwaste21Objects1ObjectsGDgdjs_46LevelCode_46GDwaste22Objects1ObjectsGDgdjs_46LevelCode_46GDwaste23Objects1ObjectsGDgdjs_46LevelCode_46GDwaste24Objects1ObjectsGDgdjs_46LevelCode_46GDwaste25Objects1ObjectsGDgdjs_46LevelCode_46GDwaste26Objects1ObjectsGDgdjs_46LevelCode_46GDwaste27Objects1ObjectsGDgdjs_46LevelCode_46GDwaste29Objects1ObjectsGDgdjs_46LevelCode_46GDwaste30Objects1ObjectsGDgdjs_46LevelCode_46GDwaste31Objects1ObjectsGDgdjs_46LevelCode_46GDwaste32Objects1ObjectsGDgdjs_46LevelCode_46GDwaste33Objects1ObjectsGDgdjs_46LevelCode_46GDwaste34Objects1ObjectsGDgdjs_46LevelCode_46GDwaste35Objects1ObjectsGDgdjs_46LevelCode_46GDwaste36Objects1ObjectsGDgdjs_46LevelCode_46GDwaste37Objects1ObjectsGDgdjs_46LevelCode_46GDwaste38Objects1ObjectsGDgdjs_46LevelCode_46GDwaste39Objects1ObjectsGDgdjs_46LevelCode_46GDwaste40Objects1ObjectsGDgdjs_46LevelCode_46GDwaste28Objects1Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDCleanButtonObjects1Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.LevelCode.GDLifeObjects1);
/* Reuse gdjs.LevelCode.GDwaste1Objects1 */
/* Reuse gdjs.LevelCode.GDwaste10Objects1 */
/* Reuse gdjs.LevelCode.GDwaste11Objects1 */
/* Reuse gdjs.LevelCode.GDwaste12Objects1 */
/* Reuse gdjs.LevelCode.GDwaste13Objects1 */
/* Reuse gdjs.LevelCode.GDwaste14Objects1 */
/* Reuse gdjs.LevelCode.GDwaste15Objects1 */
/* Reuse gdjs.LevelCode.GDwaste16Objects1 */
/* Reuse gdjs.LevelCode.GDwaste17Objects1 */
/* Reuse gdjs.LevelCode.GDwaste18Objects1 */
/* Reuse gdjs.LevelCode.GDwaste19Objects1 */
/* Reuse gdjs.LevelCode.GDwaste2Objects1 */
/* Reuse gdjs.LevelCode.GDwaste20Objects1 */
/* Reuse gdjs.LevelCode.GDwaste21Objects1 */
/* Reuse gdjs.LevelCode.GDwaste22Objects1 */
/* Reuse gdjs.LevelCode.GDwaste23Objects1 */
/* Reuse gdjs.LevelCode.GDwaste24Objects1 */
/* Reuse gdjs.LevelCode.GDwaste25Objects1 */
/* Reuse gdjs.LevelCode.GDwaste26Objects1 */
/* Reuse gdjs.LevelCode.GDwaste27Objects1 */
/* Reuse gdjs.LevelCode.GDwaste28Objects1 */
/* Reuse gdjs.LevelCode.GDwaste29Objects1 */
/* Reuse gdjs.LevelCode.GDwaste3Objects1 */
/* Reuse gdjs.LevelCode.GDwaste30Objects1 */
/* Reuse gdjs.LevelCode.GDwaste31Objects1 */
/* Reuse gdjs.LevelCode.GDwaste32Objects1 */
/* Reuse gdjs.LevelCode.GDwaste33Objects1 */
/* Reuse gdjs.LevelCode.GDwaste34Objects1 */
/* Reuse gdjs.LevelCode.GDwaste35Objects1 */
/* Reuse gdjs.LevelCode.GDwaste36Objects1 */
/* Reuse gdjs.LevelCode.GDwaste37Objects1 */
/* Reuse gdjs.LevelCode.GDwaste38Objects1 */
/* Reuse gdjs.LevelCode.GDwaste39Objects1 */
/* Reuse gdjs.LevelCode.GDwaste4Objects1 */
/* Reuse gdjs.LevelCode.GDwaste40Objects1 */
/* Reuse gdjs.LevelCode.GDwaste5Objects1 */
/* Reuse gdjs.LevelCode.GDwaste6Objects1 */
/* Reuse gdjs.LevelCode.GDwaste7Objects1 */
/* Reuse gdjs.LevelCode.GDwaste8Objects1 */
/* Reuse gdjs.LevelCode.GDwaste9Objects1 */
{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).sub(1);
}{for(var i = 0, len = gdjs.LevelCode.GDLifeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDLifeObjects1[i].setAnimationName("Life" + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CleanButton"), gdjs.LevelCode.GDCleanButtonObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDCleanButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste31Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste31Objects1[i].getVariableNumber(gdjs.LevelCode.GDwaste31Objects1[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDwaste31Objects1[k] = gdjs.LevelCode.GDwaste31Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste31Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDwaste31Objects1 */
{for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].setAnimationName("Clean");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste29Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste29Objects1[i].getVariableNumber(gdjs.LevelCode.GDwaste29Objects1[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDwaste29Objects1[k] = gdjs.LevelCode.GDwaste29Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste29Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDwaste29Objects1 */
{for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].setAnimationName("Clean");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste27Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste27Objects1[i].getVariableNumber(gdjs.LevelCode.GDwaste27Objects1[i].getVariables().get("Clean")) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDwaste27Objects1[k] = gdjs.LevelCode.GDwaste27Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste27Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDwaste27Objects1 */
{for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].setAnimationName("Clean");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste8Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste8Objects1[i].getVariableNumber(gdjs.LevelCode.GDwaste8Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDwaste8Objects1[k] = gdjs.LevelCode.GDwaste8Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste8Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDwaste8Objects1 */
{for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].setAnimationName("Clean");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDwaste7Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDwaste7Objects1[i].getVariableNumber(gdjs.LevelCode.GDwaste7Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDwaste7Objects1[k] = gdjs.LevelCode.GDwaste7Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDwaste7Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDwaste7Objects1 */
{for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].setAnimationName("Clean");
}
}}

}


{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(5);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}
{ //Subevents
gdjs.LevelCode.eventsList15(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.LevelCode.GDLifeObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.LevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.LevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.LevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.LevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.LevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.LevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.LevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.LevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.LevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.LevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.LevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.LevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.LevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.LevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.LevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.LevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.LevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.LevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.LevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.LevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.LevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.LevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.LevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.LevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.LevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.LevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.LevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.LevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.LevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.LevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.LevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.LevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.LevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.LevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.LevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.LevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.LevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.LevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.LevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.LevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDLifeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDLifeObjects1[i].setAnimationName("");
}
}{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(4), true);
}{for(var i = 0, len = gdjs.LevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste8Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste9Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste10Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste11Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste12Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste13Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste14Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste15Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste17Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste18Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste19Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste16Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste20Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste21Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste22Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste23Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste24Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste25Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste26Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste27Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste29Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste30Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste31Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste32Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste33Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste34Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste35Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste36Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste37Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste38Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste39Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste40Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDwaste28Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "WasteCreation");
}
{ //Subevents
gdjs.LevelCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 15;
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 9;
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SpeedValue"), gdjs.LevelCode.GDSpeedValueObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}{for(var i = 0, len = gdjs.LevelCode.GDSpeedValueObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDSpeedValueObjects1[i].setAnimationName(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))));
}
}}

}


{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList19(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2, "GameOver");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "GameOver");
}
{ //Subevents
gdjs.LevelCode.eventsList20(runtimeScene);} //End of subevents
}

}


};

gdjs.LevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LevelCode.GDPlasticBoxObjects1.length = 0;
gdjs.LevelCode.GDPlasticBoxObjects2.length = 0;
gdjs.LevelCode.GDPlasticBoxObjects3.length = 0;
gdjs.LevelCode.GDPlasticBoxObjects4.length = 0;
gdjs.LevelCode.GDGlassBoxObjects1.length = 0;
gdjs.LevelCode.GDGlassBoxObjects2.length = 0;
gdjs.LevelCode.GDGlassBoxObjects3.length = 0;
gdjs.LevelCode.GDGlassBoxObjects4.length = 0;
gdjs.LevelCode.GDPaperBoxObjects1.length = 0;
gdjs.LevelCode.GDPaperBoxObjects2.length = 0;
gdjs.LevelCode.GDPaperBoxObjects3.length = 0;
gdjs.LevelCode.GDPaperBoxObjects4.length = 0;
gdjs.LevelCode.GDOtherBoxObjects1.length = 0;
gdjs.LevelCode.GDOtherBoxObjects2.length = 0;
gdjs.LevelCode.GDOtherBoxObjects3.length = 0;
gdjs.LevelCode.GDOtherBoxObjects4.length = 0;
gdjs.LevelCode.GDScoreObjects1.length = 0;
gdjs.LevelCode.GDScoreObjects2.length = 0;
gdjs.LevelCode.GDScoreObjects3.length = 0;
gdjs.LevelCode.GDScoreObjects4.length = 0;
gdjs.LevelCode.GDArmObjects1.length = 0;
gdjs.LevelCode.GDArmObjects2.length = 0;
gdjs.LevelCode.GDArmObjects3.length = 0;
gdjs.LevelCode.GDArmObjects4.length = 0;
gdjs.LevelCode.GDPrevObjects1.length = 0;
gdjs.LevelCode.GDPrevObjects2.length = 0;
gdjs.LevelCode.GDPrevObjects3.length = 0;
gdjs.LevelCode.GDPrevObjects4.length = 0;
gdjs.LevelCode.GDStarObjects1.length = 0;
gdjs.LevelCode.GDStarObjects2.length = 0;
gdjs.LevelCode.GDStarObjects3.length = 0;
gdjs.LevelCode.GDStarObjects4.length = 0;
gdjs.LevelCode.GDBackGroundObjects1.length = 0;
gdjs.LevelCode.GDBackGroundObjects2.length = 0;
gdjs.LevelCode.GDBackGroundObjects3.length = 0;
gdjs.LevelCode.GDBackGroundObjects4.length = 0;
gdjs.LevelCode.GDLeftBoxObjects1.length = 0;
gdjs.LevelCode.GDLeftBoxObjects2.length = 0;
gdjs.LevelCode.GDLeftBoxObjects3.length = 0;
gdjs.LevelCode.GDLeftBoxObjects4.length = 0;
gdjs.LevelCode.GDRightBoxObjects1.length = 0;
gdjs.LevelCode.GDRightBoxObjects2.length = 0;
gdjs.LevelCode.GDRightBoxObjects3.length = 0;
gdjs.LevelCode.GDRightBoxObjects4.length = 0;
gdjs.LevelCode.GDSpeedValueObjects1.length = 0;
gdjs.LevelCode.GDSpeedValueObjects2.length = 0;
gdjs.LevelCode.GDSpeedValueObjects3.length = 0;
gdjs.LevelCode.GDSpeedValueObjects4.length = 0;
gdjs.LevelCode.GDCleanButtonObjects1.length = 0;
gdjs.LevelCode.GDCleanButtonObjects2.length = 0;
gdjs.LevelCode.GDCleanButtonObjects3.length = 0;
gdjs.LevelCode.GDCleanButtonObjects4.length = 0;
gdjs.LevelCode.GDLifeObjects1.length = 0;
gdjs.LevelCode.GDLifeObjects2.length = 0;
gdjs.LevelCode.GDLifeObjects3.length = 0;
gdjs.LevelCode.GDLifeObjects4.length = 0;
gdjs.LevelCode.GDwaste1Objects1.length = 0;
gdjs.LevelCode.GDwaste1Objects2.length = 0;
gdjs.LevelCode.GDwaste1Objects3.length = 0;
gdjs.LevelCode.GDwaste1Objects4.length = 0;
gdjs.LevelCode.GDwaste2Objects1.length = 0;
gdjs.LevelCode.GDwaste2Objects2.length = 0;
gdjs.LevelCode.GDwaste2Objects3.length = 0;
gdjs.LevelCode.GDwaste2Objects4.length = 0;
gdjs.LevelCode.GDwaste3Objects1.length = 0;
gdjs.LevelCode.GDwaste3Objects2.length = 0;
gdjs.LevelCode.GDwaste3Objects3.length = 0;
gdjs.LevelCode.GDwaste3Objects4.length = 0;
gdjs.LevelCode.GDwaste4Objects1.length = 0;
gdjs.LevelCode.GDwaste4Objects2.length = 0;
gdjs.LevelCode.GDwaste4Objects3.length = 0;
gdjs.LevelCode.GDwaste4Objects4.length = 0;
gdjs.LevelCode.GDwaste5Objects1.length = 0;
gdjs.LevelCode.GDwaste5Objects2.length = 0;
gdjs.LevelCode.GDwaste5Objects3.length = 0;
gdjs.LevelCode.GDwaste5Objects4.length = 0;
gdjs.LevelCode.GDwaste6Objects1.length = 0;
gdjs.LevelCode.GDwaste6Objects2.length = 0;
gdjs.LevelCode.GDwaste6Objects3.length = 0;
gdjs.LevelCode.GDwaste6Objects4.length = 0;
gdjs.LevelCode.GDwaste7Objects1.length = 0;
gdjs.LevelCode.GDwaste7Objects2.length = 0;
gdjs.LevelCode.GDwaste7Objects3.length = 0;
gdjs.LevelCode.GDwaste7Objects4.length = 0;
gdjs.LevelCode.GDwaste8Objects1.length = 0;
gdjs.LevelCode.GDwaste8Objects2.length = 0;
gdjs.LevelCode.GDwaste8Objects3.length = 0;
gdjs.LevelCode.GDwaste8Objects4.length = 0;
gdjs.LevelCode.GDwaste9Objects1.length = 0;
gdjs.LevelCode.GDwaste9Objects2.length = 0;
gdjs.LevelCode.GDwaste9Objects3.length = 0;
gdjs.LevelCode.GDwaste9Objects4.length = 0;
gdjs.LevelCode.GDwaste10Objects1.length = 0;
gdjs.LevelCode.GDwaste10Objects2.length = 0;
gdjs.LevelCode.GDwaste10Objects3.length = 0;
gdjs.LevelCode.GDwaste10Objects4.length = 0;
gdjs.LevelCode.GDwaste11Objects1.length = 0;
gdjs.LevelCode.GDwaste11Objects2.length = 0;
gdjs.LevelCode.GDwaste11Objects3.length = 0;
gdjs.LevelCode.GDwaste11Objects4.length = 0;
gdjs.LevelCode.GDwaste12Objects1.length = 0;
gdjs.LevelCode.GDwaste12Objects2.length = 0;
gdjs.LevelCode.GDwaste12Objects3.length = 0;
gdjs.LevelCode.GDwaste12Objects4.length = 0;
gdjs.LevelCode.GDwaste13Objects1.length = 0;
gdjs.LevelCode.GDwaste13Objects2.length = 0;
gdjs.LevelCode.GDwaste13Objects3.length = 0;
gdjs.LevelCode.GDwaste13Objects4.length = 0;
gdjs.LevelCode.GDwaste14Objects1.length = 0;
gdjs.LevelCode.GDwaste14Objects2.length = 0;
gdjs.LevelCode.GDwaste14Objects3.length = 0;
gdjs.LevelCode.GDwaste14Objects4.length = 0;
gdjs.LevelCode.GDwaste15Objects1.length = 0;
gdjs.LevelCode.GDwaste15Objects2.length = 0;
gdjs.LevelCode.GDwaste15Objects3.length = 0;
gdjs.LevelCode.GDwaste15Objects4.length = 0;
gdjs.LevelCode.GDwaste17Objects1.length = 0;
gdjs.LevelCode.GDwaste17Objects2.length = 0;
gdjs.LevelCode.GDwaste17Objects3.length = 0;
gdjs.LevelCode.GDwaste17Objects4.length = 0;
gdjs.LevelCode.GDwaste16Objects1.length = 0;
gdjs.LevelCode.GDwaste16Objects2.length = 0;
gdjs.LevelCode.GDwaste16Objects3.length = 0;
gdjs.LevelCode.GDwaste16Objects4.length = 0;
gdjs.LevelCode.GDwaste18Objects1.length = 0;
gdjs.LevelCode.GDwaste18Objects2.length = 0;
gdjs.LevelCode.GDwaste18Objects3.length = 0;
gdjs.LevelCode.GDwaste18Objects4.length = 0;
gdjs.LevelCode.GDwaste19Objects1.length = 0;
gdjs.LevelCode.GDwaste19Objects2.length = 0;
gdjs.LevelCode.GDwaste19Objects3.length = 0;
gdjs.LevelCode.GDwaste19Objects4.length = 0;
gdjs.LevelCode.GDwaste20Objects1.length = 0;
gdjs.LevelCode.GDwaste20Objects2.length = 0;
gdjs.LevelCode.GDwaste20Objects3.length = 0;
gdjs.LevelCode.GDwaste20Objects4.length = 0;
gdjs.LevelCode.GDwaste21Objects1.length = 0;
gdjs.LevelCode.GDwaste21Objects2.length = 0;
gdjs.LevelCode.GDwaste21Objects3.length = 0;
gdjs.LevelCode.GDwaste21Objects4.length = 0;
gdjs.LevelCode.GDwaste22Objects1.length = 0;
gdjs.LevelCode.GDwaste22Objects2.length = 0;
gdjs.LevelCode.GDwaste22Objects3.length = 0;
gdjs.LevelCode.GDwaste22Objects4.length = 0;
gdjs.LevelCode.GDwaste23Objects1.length = 0;
gdjs.LevelCode.GDwaste23Objects2.length = 0;
gdjs.LevelCode.GDwaste23Objects3.length = 0;
gdjs.LevelCode.GDwaste23Objects4.length = 0;
gdjs.LevelCode.GDwaste24Objects1.length = 0;
gdjs.LevelCode.GDwaste24Objects2.length = 0;
gdjs.LevelCode.GDwaste24Objects3.length = 0;
gdjs.LevelCode.GDwaste24Objects4.length = 0;
gdjs.LevelCode.GDwaste25Objects1.length = 0;
gdjs.LevelCode.GDwaste25Objects2.length = 0;
gdjs.LevelCode.GDwaste25Objects3.length = 0;
gdjs.LevelCode.GDwaste25Objects4.length = 0;
gdjs.LevelCode.GDwaste26Objects1.length = 0;
gdjs.LevelCode.GDwaste26Objects2.length = 0;
gdjs.LevelCode.GDwaste26Objects3.length = 0;
gdjs.LevelCode.GDwaste26Objects4.length = 0;
gdjs.LevelCode.GDwaste27Objects1.length = 0;
gdjs.LevelCode.GDwaste27Objects2.length = 0;
gdjs.LevelCode.GDwaste27Objects3.length = 0;
gdjs.LevelCode.GDwaste27Objects4.length = 0;
gdjs.LevelCode.GDwaste29Objects1.length = 0;
gdjs.LevelCode.GDwaste29Objects2.length = 0;
gdjs.LevelCode.GDwaste29Objects3.length = 0;
gdjs.LevelCode.GDwaste29Objects4.length = 0;
gdjs.LevelCode.GDwaste28Objects1.length = 0;
gdjs.LevelCode.GDwaste28Objects2.length = 0;
gdjs.LevelCode.GDwaste28Objects3.length = 0;
gdjs.LevelCode.GDwaste28Objects4.length = 0;
gdjs.LevelCode.GDwaste30Objects1.length = 0;
gdjs.LevelCode.GDwaste30Objects2.length = 0;
gdjs.LevelCode.GDwaste30Objects3.length = 0;
gdjs.LevelCode.GDwaste30Objects4.length = 0;
gdjs.LevelCode.GDwaste31Objects1.length = 0;
gdjs.LevelCode.GDwaste31Objects2.length = 0;
gdjs.LevelCode.GDwaste31Objects3.length = 0;
gdjs.LevelCode.GDwaste31Objects4.length = 0;
gdjs.LevelCode.GDwaste32Objects1.length = 0;
gdjs.LevelCode.GDwaste32Objects2.length = 0;
gdjs.LevelCode.GDwaste32Objects3.length = 0;
gdjs.LevelCode.GDwaste32Objects4.length = 0;
gdjs.LevelCode.GDwaste33Objects1.length = 0;
gdjs.LevelCode.GDwaste33Objects2.length = 0;
gdjs.LevelCode.GDwaste33Objects3.length = 0;
gdjs.LevelCode.GDwaste33Objects4.length = 0;
gdjs.LevelCode.GDwaste34Objects1.length = 0;
gdjs.LevelCode.GDwaste34Objects2.length = 0;
gdjs.LevelCode.GDwaste34Objects3.length = 0;
gdjs.LevelCode.GDwaste34Objects4.length = 0;
gdjs.LevelCode.GDwaste35Objects1.length = 0;
gdjs.LevelCode.GDwaste35Objects2.length = 0;
gdjs.LevelCode.GDwaste35Objects3.length = 0;
gdjs.LevelCode.GDwaste35Objects4.length = 0;
gdjs.LevelCode.GDwaste36Objects1.length = 0;
gdjs.LevelCode.GDwaste36Objects2.length = 0;
gdjs.LevelCode.GDwaste36Objects3.length = 0;
gdjs.LevelCode.GDwaste36Objects4.length = 0;
gdjs.LevelCode.GDwaste37Objects1.length = 0;
gdjs.LevelCode.GDwaste37Objects2.length = 0;
gdjs.LevelCode.GDwaste37Objects3.length = 0;
gdjs.LevelCode.GDwaste37Objects4.length = 0;
gdjs.LevelCode.GDwaste38Objects1.length = 0;
gdjs.LevelCode.GDwaste38Objects2.length = 0;
gdjs.LevelCode.GDwaste38Objects3.length = 0;
gdjs.LevelCode.GDwaste38Objects4.length = 0;
gdjs.LevelCode.GDwaste39Objects1.length = 0;
gdjs.LevelCode.GDwaste39Objects2.length = 0;
gdjs.LevelCode.GDwaste39Objects3.length = 0;
gdjs.LevelCode.GDwaste39Objects4.length = 0;
gdjs.LevelCode.GDwaste40Objects1.length = 0;
gdjs.LevelCode.GDwaste40Objects2.length = 0;
gdjs.LevelCode.GDwaste40Objects3.length = 0;
gdjs.LevelCode.GDwaste40Objects4.length = 0;
gdjs.LevelCode.GDSoundObjects1.length = 0;
gdjs.LevelCode.GDSoundObjects2.length = 0;
gdjs.LevelCode.GDSoundObjects3.length = 0;
gdjs.LevelCode.GDSoundObjects4.length = 0;

gdjs.LevelCode.eventsList21(runtimeScene);
return;

}

gdjs['LevelCode'] = gdjs.LevelCode;
