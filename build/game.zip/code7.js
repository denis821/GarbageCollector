gdjs.RatingCode = {};
gdjs.RatingCode.GDRectObjects1= [];
gdjs.RatingCode.GDRectObjects2= [];
gdjs.RatingCode.GDRectObjects3= [];
gdjs.RatingCode.GDtopObjects1= [];
gdjs.RatingCode.GDtopObjects2= [];
gdjs.RatingCode.GDtopObjects3= [];
gdjs.RatingCode.GDRatingTextObjects1= [];
gdjs.RatingCode.GDRatingTextObjects2= [];
gdjs.RatingCode.GDRatingTextObjects3= [];
gdjs.RatingCode.GDNewGameObjects1= [];
gdjs.RatingCode.GDNewGameObjects2= [];
gdjs.RatingCode.GDNewGameObjects3= [];
gdjs.RatingCode.GDBackObjects1= [];
gdjs.RatingCode.GDBackObjects2= [];
gdjs.RatingCode.GDBackObjects3= [];
gdjs.RatingCode.GDUserName1Objects1= [];
gdjs.RatingCode.GDUserName1Objects2= [];
gdjs.RatingCode.GDUserName1Objects3= [];
gdjs.RatingCode.GDUser1Objects1= [];
gdjs.RatingCode.GDUser1Objects2= [];
gdjs.RatingCode.GDUser1Objects3= [];
gdjs.RatingCode.GDUserPoints1Objects1= [];
gdjs.RatingCode.GDUserPoints1Objects2= [];
gdjs.RatingCode.GDUserPoints1Objects3= [];
gdjs.RatingCode.GDUser2Objects1= [];
gdjs.RatingCode.GDUser2Objects2= [];
gdjs.RatingCode.GDUser2Objects3= [];
gdjs.RatingCode.GDUserName2Objects1= [];
gdjs.RatingCode.GDUserName2Objects2= [];
gdjs.RatingCode.GDUserName2Objects3= [];
gdjs.RatingCode.GDUserPoints2Objects1= [];
gdjs.RatingCode.GDUserPoints2Objects2= [];
gdjs.RatingCode.GDUserPoints2Objects3= [];
gdjs.RatingCode.GDUser3Objects1= [];
gdjs.RatingCode.GDUser3Objects2= [];
gdjs.RatingCode.GDUser3Objects3= [];
gdjs.RatingCode.GDUserName3Objects1= [];
gdjs.RatingCode.GDUserName3Objects2= [];
gdjs.RatingCode.GDUserName3Objects3= [];
gdjs.RatingCode.GDUserPoints3Objects1= [];
gdjs.RatingCode.GDUserPoints3Objects2= [];
gdjs.RatingCode.GDUserPoints3Objects3= [];
gdjs.RatingCode.GDUser4Objects1= [];
gdjs.RatingCode.GDUser4Objects2= [];
gdjs.RatingCode.GDUser4Objects3= [];
gdjs.RatingCode.GDUser5Objects1= [];
gdjs.RatingCode.GDUser5Objects2= [];
gdjs.RatingCode.GDUser5Objects3= [];
gdjs.RatingCode.GDUser6Objects1= [];
gdjs.RatingCode.GDUser6Objects2= [];
gdjs.RatingCode.GDUser6Objects3= [];
gdjs.RatingCode.GDUser7Objects1= [];
gdjs.RatingCode.GDUser7Objects2= [];
gdjs.RatingCode.GDUser7Objects3= [];
gdjs.RatingCode.GDUser8Objects1= [];
gdjs.RatingCode.GDUser8Objects2= [];
gdjs.RatingCode.GDUser8Objects3= [];
gdjs.RatingCode.GDUser9Objects1= [];
gdjs.RatingCode.GDUser9Objects2= [];
gdjs.RatingCode.GDUser9Objects3= [];
gdjs.RatingCode.GDUser10Objects1= [];
gdjs.RatingCode.GDUser10Objects2= [];
gdjs.RatingCode.GDUser10Objects3= [];
gdjs.RatingCode.GDUserName4Objects1= [];
gdjs.RatingCode.GDUserName4Objects2= [];
gdjs.RatingCode.GDUserName4Objects3= [];
gdjs.RatingCode.GDUserName5Objects1= [];
gdjs.RatingCode.GDUserName5Objects2= [];
gdjs.RatingCode.GDUserName5Objects3= [];
gdjs.RatingCode.GDUserName6Objects1= [];
gdjs.RatingCode.GDUserName6Objects2= [];
gdjs.RatingCode.GDUserName6Objects3= [];
gdjs.RatingCode.GDUserName7Objects1= [];
gdjs.RatingCode.GDUserName7Objects2= [];
gdjs.RatingCode.GDUserName7Objects3= [];
gdjs.RatingCode.GDUserName8Objects1= [];
gdjs.RatingCode.GDUserName8Objects2= [];
gdjs.RatingCode.GDUserName8Objects3= [];
gdjs.RatingCode.GDStarObjects1= [];
gdjs.RatingCode.GDStarObjects2= [];
gdjs.RatingCode.GDStarObjects3= [];
gdjs.RatingCode.GDUserPoints4Objects1= [];
gdjs.RatingCode.GDUserPoints4Objects2= [];
gdjs.RatingCode.GDUserPoints4Objects3= [];
gdjs.RatingCode.GDUserPoints5Objects1= [];
gdjs.RatingCode.GDUserPoints5Objects2= [];
gdjs.RatingCode.GDUserPoints5Objects3= [];
gdjs.RatingCode.GDUserPoints6Objects1= [];
gdjs.RatingCode.GDUserPoints6Objects2= [];
gdjs.RatingCode.GDUserPoints6Objects3= [];
gdjs.RatingCode.GDUserPoints7Objects1= [];
gdjs.RatingCode.GDUserPoints7Objects2= [];
gdjs.RatingCode.GDUserPoints7Objects3= [];
gdjs.RatingCode.GDUserPoints8Objects1= [];
gdjs.RatingCode.GDUserPoints8Objects2= [];
gdjs.RatingCode.GDUserPoints8Objects3= [];
gdjs.RatingCode.GDUser11Objects1= [];
gdjs.RatingCode.GDUser11Objects2= [];
gdjs.RatingCode.GDUser11Objects3= [];
gdjs.RatingCode.GDUserName9Objects1= [];
gdjs.RatingCode.GDUserName9Objects2= [];
gdjs.RatingCode.GDUserName9Objects3= [];
gdjs.RatingCode.GDUserName10Objects1= [];
gdjs.RatingCode.GDUserName10Objects2= [];
gdjs.RatingCode.GDUserName10Objects3= [];
gdjs.RatingCode.GDUserName11Objects1= [];
gdjs.RatingCode.GDUserName11Objects2= [];
gdjs.RatingCode.GDUserName11Objects3= [];
gdjs.RatingCode.GDUserPoints9Objects1= [];
gdjs.RatingCode.GDUserPoints9Objects2= [];
gdjs.RatingCode.GDUserPoints9Objects3= [];
gdjs.RatingCode.GDUserPoints10Objects1= [];
gdjs.RatingCode.GDUserPoints10Objects2= [];
gdjs.RatingCode.GDUserPoints10Objects3= [];
gdjs.RatingCode.GDUserPoints11Objects1= [];
gdjs.RatingCode.GDUserPoints11Objects2= [];
gdjs.RatingCode.GDUserPoints11Objects3= [];
gdjs.RatingCode.GDLineObjects1= [];
gdjs.RatingCode.GDLineObjects2= [];
gdjs.RatingCode.GDLineObjects3= [];
gdjs.RatingCode.GDUser12Objects1= [];
gdjs.RatingCode.GDUser12Objects2= [];
gdjs.RatingCode.GDUser12Objects3= [];
gdjs.RatingCode.GDUserOwnerObjects1= [];
gdjs.RatingCode.GDUserOwnerObjects2= [];
gdjs.RatingCode.GDUserOwnerObjects3= [];
gdjs.RatingCode.GDUserName12Objects1= [];
gdjs.RatingCode.GDUserName12Objects2= [];
gdjs.RatingCode.GDUserName12Objects3= [];
gdjs.RatingCode.GDUserNameOwnerObjects1= [];
gdjs.RatingCode.GDUserNameOwnerObjects2= [];
gdjs.RatingCode.GDUserNameOwnerObjects3= [];
gdjs.RatingCode.GDUserPoints12Objects1= [];
gdjs.RatingCode.GDUserPoints12Objects2= [];
gdjs.RatingCode.GDUserPoints12Objects3= [];
gdjs.RatingCode.GDUserPointsOwnerObjects1= [];
gdjs.RatingCode.GDUserPointsOwnerObjects2= [];
gdjs.RatingCode.GDUserPointsOwnerObjects3= [];
gdjs.RatingCode.GDSoundObjects1= [];
gdjs.RatingCode.GDSoundObjects2= [];
gdjs.RatingCode.GDSoundObjects3= [];
gdjs.RatingCode.GDYellowObjects1= [];
gdjs.RatingCode.GDYellowObjects2= [];
gdjs.RatingCode.GDYellowObjects3= [];

gdjs.RatingCode.conditionTrue_0 = {val:false};
gdjs.RatingCode.condition0IsTrue_0 = {val:false};
gdjs.RatingCode.condition1IsTrue_0 = {val:false};
gdjs.RatingCode.condition2IsTrue_0 = {val:false};
gdjs.RatingCode.conditionTrue_1 = {val:false};
gdjs.RatingCode.condition0IsTrue_1 = {val:false};
gdjs.RatingCode.condition1IsTrue_1 = {val:false};
gdjs.RatingCode.condition2IsTrue_1 = {val:false};


gdjs.RatingCode.mapOfGDgdjs_46RatingCode_46GDNewGameObjects1Objects = Hashtable.newFrom({"NewGame": gdjs.RatingCode.GDNewGameObjects1});gdjs.RatingCode.eventsList0 = function(runtimeScene) {

{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level", false);
}}

}


};gdjs.RatingCode.eventsList1 = function(runtimeScene) {

{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.RatingCode.GDSoundObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDSoundObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDSoundObjects2[i].setAnimationName("On");
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 0;
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.RatingCode.GDSoundObjects1);
{for(var i = 0, len = gdjs.RatingCode.GDSoundObjects1.length ;i < len;++i) {
    gdjs.RatingCode.GDSoundObjects1[i].setAnimationName("Off");
}
}}

}


};gdjs.RatingCode.eventsList2 = function(runtimeScene) {

{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("0").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User1"), gdjs.RatingCode.GDUser1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser1Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser1Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("1").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User2"), gdjs.RatingCode.GDUser2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser2Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser2Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("2").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User3"), gdjs.RatingCode.GDUser3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser3Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser3Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("3").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User4"), gdjs.RatingCode.GDUser4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser4Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser4Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("4").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User5"), gdjs.RatingCode.GDUser5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser5Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser5Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("5").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User6"), gdjs.RatingCode.GDUser6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser6Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser6Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("6").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User7"), gdjs.RatingCode.GDUser7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser7Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser7Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("7").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User8"), gdjs.RatingCode.GDUser8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser8Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser8Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("8").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User9"), gdjs.RatingCode.GDUser9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser9Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser9Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("9").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User10"), gdjs.RatingCode.GDUser10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser10Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser10Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("10").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User11"), gdjs.RatingCode.GDUser11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser11Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser11Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("11").getChild("name_unique"));
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("User12"), gdjs.RatingCode.GDUser12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects2);
{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects2[i].setY((( gdjs.RatingCode.GDUser12Objects2.length === 0 ) ? 0 :gdjs.RatingCode.GDUser12Objects2[0].getY()) - 5);
}
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) != "null";
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UserNameOwner"), gdjs.RatingCode.GDUserNameOwnerObjects1);
gdjs.copyArray(runtimeScene.getObjects("UserOwner"), gdjs.RatingCode.GDUserOwnerObjects1);
gdjs.copyArray(runtimeScene.getObjects("UserPointsOwner"), gdjs.RatingCode.GDUserPointsOwnerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects1);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)), runtimeScene.getVariables().getFromIndex(4));
}{for(var i = 0, len = gdjs.RatingCode.GDUserNameOwnerObjects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserNameOwnerObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4).getChild("user")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPointsOwnerObjects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPointsOwnerObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4).getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserOwnerObjects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserOwnerObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4).getChild("pos")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects1.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects1[i].setY((( gdjs.RatingCode.GDUserOwnerObjects1.length === 0 ) ? 0 :gdjs.RatingCode.GDUserOwnerObjects1[0].getY()) - 5);
}
}}

}


};gdjs.RatingCode.mapOfGDgdjs_46RatingCode_46GDSoundObjects1Objects = Hashtable.newFrom({"Sound": gdjs.RatingCode.GDSoundObjects1});gdjs.RatingCode.eventsList3 = function(runtimeScene) {

{


gdjs.RatingCode.condition0IsTrue_0.val = false;
gdjs.RatingCode.condition1IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if ( gdjs.RatingCode.condition0IsTrue_0.val ) {
{
gdjs.RatingCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)) == 1;
}}
if (gdjs.RatingCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.RatingCode.GDSoundObjects1, gdjs.RatingCode.GDSoundObjects2);

{runtimeScene.getVariables().getFromIndex(5).setNumber(0);
}{for(var i = 0, len = gdjs.RatingCode.GDSoundObjects2.length ;i < len;++i) {
    gdjs.RatingCode.GDSoundObjects2[i].setAnimationName("Off");
}
}{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(0);
}}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
gdjs.RatingCode.condition1IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 0;
}if ( gdjs.RatingCode.condition0IsTrue_0.val ) {
{
gdjs.RatingCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)) == 1;
}}
if (gdjs.RatingCode.condition1IsTrue_0.val) {
/* Reuse gdjs.RatingCode.GDSoundObjects1 */
{runtimeScene.getVariables().getFromIndex(5).setNumber(0);
}{for(var i = 0, len = gdjs.RatingCode.GDSoundObjects1.length ;i < len;++i) {
    gdjs.RatingCode.GDSoundObjects1[i].setAnimationName("On");
}
}{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(1);
}}

}


};gdjs.RatingCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.RatingCode.GDSoundObjects1);

gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.RatingCode.mapOfGDgdjs_46RatingCode_46GDSoundObjects1Objects, runtimeScene, true, false);
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(5).setNumber(1);
}
{ //Subevents
gdjs.RatingCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.RatingCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewGame"), gdjs.RatingCode.GDNewGameObjects1);

gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.RatingCode.mapOfGDgdjs_46RatingCode_46GDNewGameObjects1Objects, runtimeScene, true, false);
}if (gdjs.RatingCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.RatingCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.RatingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Yellow"), gdjs.RatingCode.GDYellowObjects1);
{gdjs.evtTools.network.sendAsyncRequest("https://kolibri.net.ru/leaderboarder.php", "", "GET", "", runtimeScene.getVariables().getFromIndex(0), runtimeScene.getVariables().getFromIndex(1));
}{gdjs.evtTools.network.sendAsyncRequest("https://kolibri.net.ru/owner.php?user_unique=" + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)), "", "GET", "", runtimeScene.getVariables().getFromIndex(3), runtimeScene.getVariables().getFromIndex(1));
}{runtimeScene.getVariables().getFromIndex(5).setNumber(0);
}{for(var i = 0, len = gdjs.RatingCode.GDYellowObjects1.length ;i < len;++i) {
    gdjs.RatingCode.GDYellowObjects1[i].setX(157);
}
}
{ //Subevents
gdjs.RatingCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
gdjs.RatingCode.condition1IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.5, "Rating");
}if ( gdjs.RatingCode.condition0IsTrue_0.val ) {
{
{gdjs.RatingCode.conditionTrue_1 = gdjs.RatingCode.condition1IsTrue_0;
gdjs.RatingCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12791540);
}
}}
if (gdjs.RatingCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UserName1"), gdjs.RatingCode.GDUserName1Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName10"), gdjs.RatingCode.GDUserName10Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName11"), gdjs.RatingCode.GDUserName11Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName12"), gdjs.RatingCode.GDUserName12Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName2"), gdjs.RatingCode.GDUserName2Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName3"), gdjs.RatingCode.GDUserName3Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName4"), gdjs.RatingCode.GDUserName4Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName5"), gdjs.RatingCode.GDUserName5Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName6"), gdjs.RatingCode.GDUserName6Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName7"), gdjs.RatingCode.GDUserName7Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName8"), gdjs.RatingCode.GDUserName8Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserName9"), gdjs.RatingCode.GDUserName9Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints1"), gdjs.RatingCode.GDUserPoints1Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints10"), gdjs.RatingCode.GDUserPoints10Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints11"), gdjs.RatingCode.GDUserPoints11Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints12"), gdjs.RatingCode.GDUserPoints12Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints2"), gdjs.RatingCode.GDUserPoints2Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints3"), gdjs.RatingCode.GDUserPoints3Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints4"), gdjs.RatingCode.GDUserPoints4Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints5"), gdjs.RatingCode.GDUserPoints5Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints6"), gdjs.RatingCode.GDUserPoints6Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints7"), gdjs.RatingCode.GDUserPoints7Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints8"), gdjs.RatingCode.GDUserPoints8Objects1);
gdjs.copyArray(runtimeScene.getObjects("UserPoints9"), gdjs.RatingCode.GDUserPoints9Objects1);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)), runtimeScene.getVariables().getFromIndex(2));
}{for(var i = 0, len = gdjs.RatingCode.GDUserName1Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName1Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("0").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints1Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints1Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("0").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints2Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints2Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("1").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints3Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints3Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("2").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName2Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName2Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("1").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints4Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints4Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("3").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName3Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName3Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("2").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints6Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints6Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("5").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints5Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints5Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("4").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName4Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName4Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("3").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName5Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName5Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("4").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName6Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName6Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("5").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName8Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName8Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("7").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName7Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName7Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("6").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints8Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints8Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("7").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints7Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints7Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("6").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName9Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName9Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("8").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName10Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName10Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("9").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName11Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName11Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("10").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints10Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints10Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("9").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints9Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints9Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("8").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserName12Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserName12Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("11").getChild("name")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints11Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints11Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("10").getChild("points")));
}
}{for(var i = 0, len = gdjs.RatingCode.GDUserPoints12Objects1.length ;i < len;++i) {
    gdjs.RatingCode.GDUserPoints12Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("11").getChild("points")));
}
}
{ //Subevents
gdjs.RatingCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.RatingCode.condition0IsTrue_0.val = false;
{
gdjs.RatingCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.RatingCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.RatingCode.eventsList4(runtimeScene);} //End of subevents
}

}


};

gdjs.RatingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.RatingCode.GDRectObjects1.length = 0;
gdjs.RatingCode.GDRectObjects2.length = 0;
gdjs.RatingCode.GDRectObjects3.length = 0;
gdjs.RatingCode.GDtopObjects1.length = 0;
gdjs.RatingCode.GDtopObjects2.length = 0;
gdjs.RatingCode.GDtopObjects3.length = 0;
gdjs.RatingCode.GDRatingTextObjects1.length = 0;
gdjs.RatingCode.GDRatingTextObjects2.length = 0;
gdjs.RatingCode.GDRatingTextObjects3.length = 0;
gdjs.RatingCode.GDNewGameObjects1.length = 0;
gdjs.RatingCode.GDNewGameObjects2.length = 0;
gdjs.RatingCode.GDNewGameObjects3.length = 0;
gdjs.RatingCode.GDBackObjects1.length = 0;
gdjs.RatingCode.GDBackObjects2.length = 0;
gdjs.RatingCode.GDBackObjects3.length = 0;
gdjs.RatingCode.GDUserName1Objects1.length = 0;
gdjs.RatingCode.GDUserName1Objects2.length = 0;
gdjs.RatingCode.GDUserName1Objects3.length = 0;
gdjs.RatingCode.GDUser1Objects1.length = 0;
gdjs.RatingCode.GDUser1Objects2.length = 0;
gdjs.RatingCode.GDUser1Objects3.length = 0;
gdjs.RatingCode.GDUserPoints1Objects1.length = 0;
gdjs.RatingCode.GDUserPoints1Objects2.length = 0;
gdjs.RatingCode.GDUserPoints1Objects3.length = 0;
gdjs.RatingCode.GDUser2Objects1.length = 0;
gdjs.RatingCode.GDUser2Objects2.length = 0;
gdjs.RatingCode.GDUser2Objects3.length = 0;
gdjs.RatingCode.GDUserName2Objects1.length = 0;
gdjs.RatingCode.GDUserName2Objects2.length = 0;
gdjs.RatingCode.GDUserName2Objects3.length = 0;
gdjs.RatingCode.GDUserPoints2Objects1.length = 0;
gdjs.RatingCode.GDUserPoints2Objects2.length = 0;
gdjs.RatingCode.GDUserPoints2Objects3.length = 0;
gdjs.RatingCode.GDUser3Objects1.length = 0;
gdjs.RatingCode.GDUser3Objects2.length = 0;
gdjs.RatingCode.GDUser3Objects3.length = 0;
gdjs.RatingCode.GDUserName3Objects1.length = 0;
gdjs.RatingCode.GDUserName3Objects2.length = 0;
gdjs.RatingCode.GDUserName3Objects3.length = 0;
gdjs.RatingCode.GDUserPoints3Objects1.length = 0;
gdjs.RatingCode.GDUserPoints3Objects2.length = 0;
gdjs.RatingCode.GDUserPoints3Objects3.length = 0;
gdjs.RatingCode.GDUser4Objects1.length = 0;
gdjs.RatingCode.GDUser4Objects2.length = 0;
gdjs.RatingCode.GDUser4Objects3.length = 0;
gdjs.RatingCode.GDUser5Objects1.length = 0;
gdjs.RatingCode.GDUser5Objects2.length = 0;
gdjs.RatingCode.GDUser5Objects3.length = 0;
gdjs.RatingCode.GDUser6Objects1.length = 0;
gdjs.RatingCode.GDUser6Objects2.length = 0;
gdjs.RatingCode.GDUser6Objects3.length = 0;
gdjs.RatingCode.GDUser7Objects1.length = 0;
gdjs.RatingCode.GDUser7Objects2.length = 0;
gdjs.RatingCode.GDUser7Objects3.length = 0;
gdjs.RatingCode.GDUser8Objects1.length = 0;
gdjs.RatingCode.GDUser8Objects2.length = 0;
gdjs.RatingCode.GDUser8Objects3.length = 0;
gdjs.RatingCode.GDUser9Objects1.length = 0;
gdjs.RatingCode.GDUser9Objects2.length = 0;
gdjs.RatingCode.GDUser9Objects3.length = 0;
gdjs.RatingCode.GDUser10Objects1.length = 0;
gdjs.RatingCode.GDUser10Objects2.length = 0;
gdjs.RatingCode.GDUser10Objects3.length = 0;
gdjs.RatingCode.GDUserName4Objects1.length = 0;
gdjs.RatingCode.GDUserName4Objects2.length = 0;
gdjs.RatingCode.GDUserName4Objects3.length = 0;
gdjs.RatingCode.GDUserName5Objects1.length = 0;
gdjs.RatingCode.GDUserName5Objects2.length = 0;
gdjs.RatingCode.GDUserName5Objects3.length = 0;
gdjs.RatingCode.GDUserName6Objects1.length = 0;
gdjs.RatingCode.GDUserName6Objects2.length = 0;
gdjs.RatingCode.GDUserName6Objects3.length = 0;
gdjs.RatingCode.GDUserName7Objects1.length = 0;
gdjs.RatingCode.GDUserName7Objects2.length = 0;
gdjs.RatingCode.GDUserName7Objects3.length = 0;
gdjs.RatingCode.GDUserName8Objects1.length = 0;
gdjs.RatingCode.GDUserName8Objects2.length = 0;
gdjs.RatingCode.GDUserName8Objects3.length = 0;
gdjs.RatingCode.GDStarObjects1.length = 0;
gdjs.RatingCode.GDStarObjects2.length = 0;
gdjs.RatingCode.GDStarObjects3.length = 0;
gdjs.RatingCode.GDUserPoints4Objects1.length = 0;
gdjs.RatingCode.GDUserPoints4Objects2.length = 0;
gdjs.RatingCode.GDUserPoints4Objects3.length = 0;
gdjs.RatingCode.GDUserPoints5Objects1.length = 0;
gdjs.RatingCode.GDUserPoints5Objects2.length = 0;
gdjs.RatingCode.GDUserPoints5Objects3.length = 0;
gdjs.RatingCode.GDUserPoints6Objects1.length = 0;
gdjs.RatingCode.GDUserPoints6Objects2.length = 0;
gdjs.RatingCode.GDUserPoints6Objects3.length = 0;
gdjs.RatingCode.GDUserPoints7Objects1.length = 0;
gdjs.RatingCode.GDUserPoints7Objects2.length = 0;
gdjs.RatingCode.GDUserPoints7Objects3.length = 0;
gdjs.RatingCode.GDUserPoints8Objects1.length = 0;
gdjs.RatingCode.GDUserPoints8Objects2.length = 0;
gdjs.RatingCode.GDUserPoints8Objects3.length = 0;
gdjs.RatingCode.GDUser11Objects1.length = 0;
gdjs.RatingCode.GDUser11Objects2.length = 0;
gdjs.RatingCode.GDUser11Objects3.length = 0;
gdjs.RatingCode.GDUserName9Objects1.length = 0;
gdjs.RatingCode.GDUserName9Objects2.length = 0;
gdjs.RatingCode.GDUserName9Objects3.length = 0;
gdjs.RatingCode.GDUserName10Objects1.length = 0;
gdjs.RatingCode.GDUserName10Objects2.length = 0;
gdjs.RatingCode.GDUserName10Objects3.length = 0;
gdjs.RatingCode.GDUserName11Objects1.length = 0;
gdjs.RatingCode.GDUserName11Objects2.length = 0;
gdjs.RatingCode.GDUserName11Objects3.length = 0;
gdjs.RatingCode.GDUserPoints9Objects1.length = 0;
gdjs.RatingCode.GDUserPoints9Objects2.length = 0;
gdjs.RatingCode.GDUserPoints9Objects3.length = 0;
gdjs.RatingCode.GDUserPoints10Objects1.length = 0;
gdjs.RatingCode.GDUserPoints10Objects2.length = 0;
gdjs.RatingCode.GDUserPoints10Objects3.length = 0;
gdjs.RatingCode.GDUserPoints11Objects1.length = 0;
gdjs.RatingCode.GDUserPoints11Objects2.length = 0;
gdjs.RatingCode.GDUserPoints11Objects3.length = 0;
gdjs.RatingCode.GDLineObjects1.length = 0;
gdjs.RatingCode.GDLineObjects2.length = 0;
gdjs.RatingCode.GDLineObjects3.length = 0;
gdjs.RatingCode.GDUser12Objects1.length = 0;
gdjs.RatingCode.GDUser12Objects2.length = 0;
gdjs.RatingCode.GDUser12Objects3.length = 0;
gdjs.RatingCode.GDUserOwnerObjects1.length = 0;
gdjs.RatingCode.GDUserOwnerObjects2.length = 0;
gdjs.RatingCode.GDUserOwnerObjects3.length = 0;
gdjs.RatingCode.GDUserName12Objects1.length = 0;
gdjs.RatingCode.GDUserName12Objects2.length = 0;
gdjs.RatingCode.GDUserName12Objects3.length = 0;
gdjs.RatingCode.GDUserNameOwnerObjects1.length = 0;
gdjs.RatingCode.GDUserNameOwnerObjects2.length = 0;
gdjs.RatingCode.GDUserNameOwnerObjects3.length = 0;
gdjs.RatingCode.GDUserPoints12Objects1.length = 0;
gdjs.RatingCode.GDUserPoints12Objects2.length = 0;
gdjs.RatingCode.GDUserPoints12Objects3.length = 0;
gdjs.RatingCode.GDUserPointsOwnerObjects1.length = 0;
gdjs.RatingCode.GDUserPointsOwnerObjects2.length = 0;
gdjs.RatingCode.GDUserPointsOwnerObjects3.length = 0;
gdjs.RatingCode.GDSoundObjects1.length = 0;
gdjs.RatingCode.GDSoundObjects2.length = 0;
gdjs.RatingCode.GDSoundObjects3.length = 0;
gdjs.RatingCode.GDYellowObjects1.length = 0;
gdjs.RatingCode.GDYellowObjects2.length = 0;
gdjs.RatingCode.GDYellowObjects3.length = 0;

gdjs.RatingCode.eventsList5(runtimeScene);
return;

}

gdjs['RatingCode'] = gdjs.RatingCode;
