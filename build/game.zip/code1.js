gdjs.TrainingLevelCode = {};
gdjs.TrainingLevelCode.GDGlassBoxObjects1_1final = [];

gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final = [];

gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final = [];

gdjs.TrainingLevelCode.GDPaperBoxObjects1_1final = [];

gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final = [];

gdjs.TrainingLevelCode.GDPlasticBoxObjects1_1final = [];

gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final = [];

gdjs.TrainingLevelCode.GDwaste10Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste11Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste12Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste13Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste14Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste15Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste16Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste17Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste18Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste19Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste1Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste20Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste21Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste22Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste23Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste24Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste25Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste26Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste27Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste28Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste29Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste2Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste30Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste31Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste32Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste33Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste34Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste35Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste36Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste37Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste38Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste39Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste3Objects1_1final = [];

gdjs.TrainingLevelCode.GDwaste40Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste4Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste5Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste6Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste7Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste8Objects2_1final = [];

gdjs.TrainingLevelCode.GDwaste9Objects2_1final = [];

gdjs.TrainingLevelCode.GDPlasticBoxObjects1= [];
gdjs.TrainingLevelCode.GDPlasticBoxObjects2= [];
gdjs.TrainingLevelCode.GDPlasticBoxObjects3= [];
gdjs.TrainingLevelCode.GDPlasticBoxObjects4= [];
gdjs.TrainingLevelCode.GDGlassBoxObjects1= [];
gdjs.TrainingLevelCode.GDGlassBoxObjects2= [];
gdjs.TrainingLevelCode.GDGlassBoxObjects3= [];
gdjs.TrainingLevelCode.GDGlassBoxObjects4= [];
gdjs.TrainingLevelCode.GDPaperBoxObjects1= [];
gdjs.TrainingLevelCode.GDPaperBoxObjects2= [];
gdjs.TrainingLevelCode.GDPaperBoxObjects3= [];
gdjs.TrainingLevelCode.GDPaperBoxObjects4= [];
gdjs.TrainingLevelCode.GDOtherBoxObjects1= [];
gdjs.TrainingLevelCode.GDOtherBoxObjects2= [];
gdjs.TrainingLevelCode.GDOtherBoxObjects3= [];
gdjs.TrainingLevelCode.GDOtherBoxObjects4= [];
gdjs.TrainingLevelCode.GDScoreObjects1= [];
gdjs.TrainingLevelCode.GDScoreObjects2= [];
gdjs.TrainingLevelCode.GDScoreObjects3= [];
gdjs.TrainingLevelCode.GDScoreObjects4= [];
gdjs.TrainingLevelCode.GDArmObjects1= [];
gdjs.TrainingLevelCode.GDArmObjects2= [];
gdjs.TrainingLevelCode.GDArmObjects3= [];
gdjs.TrainingLevelCode.GDArmObjects4= [];
gdjs.TrainingLevelCode.GDPrevObjects1= [];
gdjs.TrainingLevelCode.GDPrevObjects2= [];
gdjs.TrainingLevelCode.GDPrevObjects3= [];
gdjs.TrainingLevelCode.GDPrevObjects4= [];
gdjs.TrainingLevelCode.GDStarObjects1= [];
gdjs.TrainingLevelCode.GDStarObjects2= [];
gdjs.TrainingLevelCode.GDStarObjects3= [];
gdjs.TrainingLevelCode.GDStarObjects4= [];
gdjs.TrainingLevelCode.GDBackGroundObjects1= [];
gdjs.TrainingLevelCode.GDBackGroundObjects2= [];
gdjs.TrainingLevelCode.GDBackGroundObjects3= [];
gdjs.TrainingLevelCode.GDBackGroundObjects4= [];
gdjs.TrainingLevelCode.GDLeftBoxObjects1= [];
gdjs.TrainingLevelCode.GDLeftBoxObjects2= [];
gdjs.TrainingLevelCode.GDLeftBoxObjects3= [];
gdjs.TrainingLevelCode.GDLeftBoxObjects4= [];
gdjs.TrainingLevelCode.GDRightBoxObjects1= [];
gdjs.TrainingLevelCode.GDRightBoxObjects2= [];
gdjs.TrainingLevelCode.GDRightBoxObjects3= [];
gdjs.TrainingLevelCode.GDRightBoxObjects4= [];
gdjs.TrainingLevelCode.GDCleanButtonObjects1= [];
gdjs.TrainingLevelCode.GDCleanButtonObjects2= [];
gdjs.TrainingLevelCode.GDCleanButtonObjects3= [];
gdjs.TrainingLevelCode.GDCleanButtonObjects4= [];
gdjs.TrainingLevelCode.GDwaste1Objects1= [];
gdjs.TrainingLevelCode.GDwaste1Objects2= [];
gdjs.TrainingLevelCode.GDwaste1Objects3= [];
gdjs.TrainingLevelCode.GDwaste1Objects4= [];
gdjs.TrainingLevelCode.GDwaste2Objects1= [];
gdjs.TrainingLevelCode.GDwaste2Objects2= [];
gdjs.TrainingLevelCode.GDwaste2Objects3= [];
gdjs.TrainingLevelCode.GDwaste2Objects4= [];
gdjs.TrainingLevelCode.GDwaste3Objects1= [];
gdjs.TrainingLevelCode.GDwaste3Objects2= [];
gdjs.TrainingLevelCode.GDwaste3Objects3= [];
gdjs.TrainingLevelCode.GDwaste3Objects4= [];
gdjs.TrainingLevelCode.GDwaste4Objects1= [];
gdjs.TrainingLevelCode.GDwaste4Objects2= [];
gdjs.TrainingLevelCode.GDwaste4Objects3= [];
gdjs.TrainingLevelCode.GDwaste4Objects4= [];
gdjs.TrainingLevelCode.GDwaste5Objects1= [];
gdjs.TrainingLevelCode.GDwaste5Objects2= [];
gdjs.TrainingLevelCode.GDwaste5Objects3= [];
gdjs.TrainingLevelCode.GDwaste5Objects4= [];
gdjs.TrainingLevelCode.GDwaste6Objects1= [];
gdjs.TrainingLevelCode.GDwaste6Objects2= [];
gdjs.TrainingLevelCode.GDwaste6Objects3= [];
gdjs.TrainingLevelCode.GDwaste6Objects4= [];
gdjs.TrainingLevelCode.GDwaste7Objects1= [];
gdjs.TrainingLevelCode.GDwaste7Objects2= [];
gdjs.TrainingLevelCode.GDwaste7Objects3= [];
gdjs.TrainingLevelCode.GDwaste7Objects4= [];
gdjs.TrainingLevelCode.GDwaste8Objects1= [];
gdjs.TrainingLevelCode.GDwaste8Objects2= [];
gdjs.TrainingLevelCode.GDwaste8Objects3= [];
gdjs.TrainingLevelCode.GDwaste8Objects4= [];
gdjs.TrainingLevelCode.GDwaste9Objects1= [];
gdjs.TrainingLevelCode.GDwaste9Objects2= [];
gdjs.TrainingLevelCode.GDwaste9Objects3= [];
gdjs.TrainingLevelCode.GDwaste9Objects4= [];
gdjs.TrainingLevelCode.GDSpeedValueObjects1= [];
gdjs.TrainingLevelCode.GDSpeedValueObjects2= [];
gdjs.TrainingLevelCode.GDSpeedValueObjects3= [];
gdjs.TrainingLevelCode.GDSpeedValueObjects4= [];
gdjs.TrainingLevelCode.GDwaste10Objects1= [];
gdjs.TrainingLevelCode.GDwaste10Objects2= [];
gdjs.TrainingLevelCode.GDwaste10Objects3= [];
gdjs.TrainingLevelCode.GDwaste10Objects4= [];
gdjs.TrainingLevelCode.GDwaste11Objects1= [];
gdjs.TrainingLevelCode.GDwaste11Objects2= [];
gdjs.TrainingLevelCode.GDwaste11Objects3= [];
gdjs.TrainingLevelCode.GDwaste11Objects4= [];
gdjs.TrainingLevelCode.GDwaste12Objects1= [];
gdjs.TrainingLevelCode.GDwaste12Objects2= [];
gdjs.TrainingLevelCode.GDwaste12Objects3= [];
gdjs.TrainingLevelCode.GDwaste12Objects4= [];
gdjs.TrainingLevelCode.GDwaste13Objects1= [];
gdjs.TrainingLevelCode.GDwaste13Objects2= [];
gdjs.TrainingLevelCode.GDwaste13Objects3= [];
gdjs.TrainingLevelCode.GDwaste13Objects4= [];
gdjs.TrainingLevelCode.GDwaste14Objects1= [];
gdjs.TrainingLevelCode.GDwaste14Objects2= [];
gdjs.TrainingLevelCode.GDwaste14Objects3= [];
gdjs.TrainingLevelCode.GDwaste14Objects4= [];
gdjs.TrainingLevelCode.GDwaste15Objects1= [];
gdjs.TrainingLevelCode.GDwaste15Objects2= [];
gdjs.TrainingLevelCode.GDwaste15Objects3= [];
gdjs.TrainingLevelCode.GDwaste15Objects4= [];
gdjs.TrainingLevelCode.GDwaste17Objects1= [];
gdjs.TrainingLevelCode.GDwaste17Objects2= [];
gdjs.TrainingLevelCode.GDwaste17Objects3= [];
gdjs.TrainingLevelCode.GDwaste17Objects4= [];
gdjs.TrainingLevelCode.GDwaste16Objects1= [];
gdjs.TrainingLevelCode.GDwaste16Objects2= [];
gdjs.TrainingLevelCode.GDwaste16Objects3= [];
gdjs.TrainingLevelCode.GDwaste16Objects4= [];
gdjs.TrainingLevelCode.GDwaste18Objects1= [];
gdjs.TrainingLevelCode.GDwaste18Objects2= [];
gdjs.TrainingLevelCode.GDwaste18Objects3= [];
gdjs.TrainingLevelCode.GDwaste18Objects4= [];
gdjs.TrainingLevelCode.GDwaste19Objects1= [];
gdjs.TrainingLevelCode.GDwaste19Objects2= [];
gdjs.TrainingLevelCode.GDwaste19Objects3= [];
gdjs.TrainingLevelCode.GDwaste19Objects4= [];
gdjs.TrainingLevelCode.GDwaste20Objects1= [];
gdjs.TrainingLevelCode.GDwaste20Objects2= [];
gdjs.TrainingLevelCode.GDwaste20Objects3= [];
gdjs.TrainingLevelCode.GDwaste20Objects4= [];
gdjs.TrainingLevelCode.GDwaste21Objects1= [];
gdjs.TrainingLevelCode.GDwaste21Objects2= [];
gdjs.TrainingLevelCode.GDwaste21Objects3= [];
gdjs.TrainingLevelCode.GDwaste21Objects4= [];
gdjs.TrainingLevelCode.GDwaste22Objects1= [];
gdjs.TrainingLevelCode.GDwaste22Objects2= [];
gdjs.TrainingLevelCode.GDwaste22Objects3= [];
gdjs.TrainingLevelCode.GDwaste22Objects4= [];
gdjs.TrainingLevelCode.GDwaste23Objects1= [];
gdjs.TrainingLevelCode.GDwaste23Objects2= [];
gdjs.TrainingLevelCode.GDwaste23Objects3= [];
gdjs.TrainingLevelCode.GDwaste23Objects4= [];
gdjs.TrainingLevelCode.GDwaste24Objects1= [];
gdjs.TrainingLevelCode.GDwaste24Objects2= [];
gdjs.TrainingLevelCode.GDwaste24Objects3= [];
gdjs.TrainingLevelCode.GDwaste24Objects4= [];
gdjs.TrainingLevelCode.GDwaste25Objects1= [];
gdjs.TrainingLevelCode.GDwaste25Objects2= [];
gdjs.TrainingLevelCode.GDwaste25Objects3= [];
gdjs.TrainingLevelCode.GDwaste25Objects4= [];
gdjs.TrainingLevelCode.GDwaste26Objects1= [];
gdjs.TrainingLevelCode.GDwaste26Objects2= [];
gdjs.TrainingLevelCode.GDwaste26Objects3= [];
gdjs.TrainingLevelCode.GDwaste26Objects4= [];
gdjs.TrainingLevelCode.GDwaste27Objects1= [];
gdjs.TrainingLevelCode.GDwaste27Objects2= [];
gdjs.TrainingLevelCode.GDwaste27Objects3= [];
gdjs.TrainingLevelCode.GDwaste27Objects4= [];
gdjs.TrainingLevelCode.GDwaste29Objects1= [];
gdjs.TrainingLevelCode.GDwaste29Objects2= [];
gdjs.TrainingLevelCode.GDwaste29Objects3= [];
gdjs.TrainingLevelCode.GDwaste29Objects4= [];
gdjs.TrainingLevelCode.GDwaste28Objects1= [];
gdjs.TrainingLevelCode.GDwaste28Objects2= [];
gdjs.TrainingLevelCode.GDwaste28Objects3= [];
gdjs.TrainingLevelCode.GDwaste28Objects4= [];
gdjs.TrainingLevelCode.GDwaste30Objects1= [];
gdjs.TrainingLevelCode.GDwaste30Objects2= [];
gdjs.TrainingLevelCode.GDwaste30Objects3= [];
gdjs.TrainingLevelCode.GDwaste30Objects4= [];
gdjs.TrainingLevelCode.GDwaste31Objects1= [];
gdjs.TrainingLevelCode.GDwaste31Objects2= [];
gdjs.TrainingLevelCode.GDwaste31Objects3= [];
gdjs.TrainingLevelCode.GDwaste31Objects4= [];
gdjs.TrainingLevelCode.GDwaste32Objects1= [];
gdjs.TrainingLevelCode.GDwaste32Objects2= [];
gdjs.TrainingLevelCode.GDwaste32Objects3= [];
gdjs.TrainingLevelCode.GDwaste32Objects4= [];
gdjs.TrainingLevelCode.GDwaste33Objects1= [];
gdjs.TrainingLevelCode.GDwaste33Objects2= [];
gdjs.TrainingLevelCode.GDwaste33Objects3= [];
gdjs.TrainingLevelCode.GDwaste33Objects4= [];
gdjs.TrainingLevelCode.GDwaste34Objects1= [];
gdjs.TrainingLevelCode.GDwaste34Objects2= [];
gdjs.TrainingLevelCode.GDwaste34Objects3= [];
gdjs.TrainingLevelCode.GDwaste34Objects4= [];
gdjs.TrainingLevelCode.GDwaste35Objects1= [];
gdjs.TrainingLevelCode.GDwaste35Objects2= [];
gdjs.TrainingLevelCode.GDwaste35Objects3= [];
gdjs.TrainingLevelCode.GDwaste35Objects4= [];
gdjs.TrainingLevelCode.GDwaste36Objects1= [];
gdjs.TrainingLevelCode.GDwaste36Objects2= [];
gdjs.TrainingLevelCode.GDwaste36Objects3= [];
gdjs.TrainingLevelCode.GDwaste36Objects4= [];
gdjs.TrainingLevelCode.GDwaste37Objects1= [];
gdjs.TrainingLevelCode.GDwaste37Objects2= [];
gdjs.TrainingLevelCode.GDwaste37Objects3= [];
gdjs.TrainingLevelCode.GDwaste37Objects4= [];
gdjs.TrainingLevelCode.GDwaste38Objects1= [];
gdjs.TrainingLevelCode.GDwaste38Objects2= [];
gdjs.TrainingLevelCode.GDwaste38Objects3= [];
gdjs.TrainingLevelCode.GDwaste38Objects4= [];
gdjs.TrainingLevelCode.GDwaste39Objects1= [];
gdjs.TrainingLevelCode.GDwaste39Objects2= [];
gdjs.TrainingLevelCode.GDwaste39Objects3= [];
gdjs.TrainingLevelCode.GDwaste39Objects4= [];
gdjs.TrainingLevelCode.GDwaste40Objects1= [];
gdjs.TrainingLevelCode.GDwaste40Objects2= [];
gdjs.TrainingLevelCode.GDwaste40Objects3= [];
gdjs.TrainingLevelCode.GDwaste40Objects4= [];
gdjs.TrainingLevelCode.GDSoundObjects1= [];
gdjs.TrainingLevelCode.GDSoundObjects2= [];
gdjs.TrainingLevelCode.GDSoundObjects3= [];
gdjs.TrainingLevelCode.GDSoundObjects4= [];
gdjs.TrainingLevelCode.GDSpeedObjects1= [];
gdjs.TrainingLevelCode.GDSpeedObjects2= [];
gdjs.TrainingLevelCode.GDSpeedObjects3= [];
gdjs.TrainingLevelCode.GDSpeedObjects4= [];
gdjs.TrainingLevelCode.GDLifeObjects1= [];
gdjs.TrainingLevelCode.GDLifeObjects2= [];
gdjs.TrainingLevelCode.GDLifeObjects3= [];
gdjs.TrainingLevelCode.GDLifeObjects4= [];

gdjs.TrainingLevelCode.conditionTrue_0 = {val:false};
gdjs.TrainingLevelCode.condition0IsTrue_0 = {val:false};
gdjs.TrainingLevelCode.condition1IsTrue_0 = {val:false};
gdjs.TrainingLevelCode.condition2IsTrue_0 = {val:false};
gdjs.TrainingLevelCode.condition3IsTrue_0 = {val:false};
gdjs.TrainingLevelCode.condition4IsTrue_0 = {val:false};
gdjs.TrainingLevelCode.conditionTrue_1 = {val:false};
gdjs.TrainingLevelCode.condition0IsTrue_1 = {val:false};
gdjs.TrainingLevelCode.condition1IsTrue_1 = {val:false};
gdjs.TrainingLevelCode.condition2IsTrue_1 = {val:false};
gdjs.TrainingLevelCode.condition3IsTrue_1 = {val:false};
gdjs.TrainingLevelCode.condition4IsTrue_1 = {val:false};
gdjs.TrainingLevelCode.conditionTrue_2 = {val:false};
gdjs.TrainingLevelCode.condition0IsTrue_2 = {val:false};
gdjs.TrainingLevelCode.condition1IsTrue_2 = {val:false};
gdjs.TrainingLevelCode.condition2IsTrue_2 = {val:false};
gdjs.TrainingLevelCode.condition3IsTrue_2 = {val:false};
gdjs.TrainingLevelCode.condition4IsTrue_2 = {val:false};


gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects1Objects = Hashtable.newFrom({"PlasticBox": gdjs.TrainingLevelCode.GDPlasticBoxObjects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects1Objects = Hashtable.newFrom({"GlassBox": gdjs.TrainingLevelCode.GDGlassBoxObjects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects1Objects = Hashtable.newFrom({"PaperBox": gdjs.TrainingLevelCode.GDPaperBoxObjects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects1Objects = Hashtable.newFrom({"OtherBox": gdjs.TrainingLevelCode.GDOtherBoxObjects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste3Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste6Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste13Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects1Objects = Hashtable.newFrom({"waste1": gdjs.TrainingLevelCode.GDwaste1Objects1, "waste2": gdjs.TrainingLevelCode.GDwaste2Objects1, "waste3": gdjs.TrainingLevelCode.GDwaste3Objects1, "waste4": gdjs.TrainingLevelCode.GDwaste4Objects1, "waste5": gdjs.TrainingLevelCode.GDwaste5Objects1, "waste6": gdjs.TrainingLevelCode.GDwaste6Objects1, "waste7": gdjs.TrainingLevelCode.GDwaste7Objects1, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects1, "waste9": gdjs.TrainingLevelCode.GDwaste9Objects1, "waste10": gdjs.TrainingLevelCode.GDwaste10Objects1, "waste11": gdjs.TrainingLevelCode.GDwaste11Objects1, "waste12": gdjs.TrainingLevelCode.GDwaste12Objects1, "waste13": gdjs.TrainingLevelCode.GDwaste13Objects1, "waste14": gdjs.TrainingLevelCode.GDwaste14Objects1, "waste15": gdjs.TrainingLevelCode.GDwaste15Objects1, "waste17": gdjs.TrainingLevelCode.GDwaste17Objects1, "waste18": gdjs.TrainingLevelCode.GDwaste18Objects1, "waste19": gdjs.TrainingLevelCode.GDwaste19Objects1, "waste16": gdjs.TrainingLevelCode.GDwaste16Objects1, "waste20": gdjs.TrainingLevelCode.GDwaste20Objects1, "waste21": gdjs.TrainingLevelCode.GDwaste21Objects1, "waste22": gdjs.TrainingLevelCode.GDwaste22Objects1, "waste23": gdjs.TrainingLevelCode.GDwaste23Objects1, "waste24": gdjs.TrainingLevelCode.GDwaste24Objects1, "waste25": gdjs.TrainingLevelCode.GDwaste25Objects1, "waste26": gdjs.TrainingLevelCode.GDwaste26Objects1, "waste27": gdjs.TrainingLevelCode.GDwaste27Objects1, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects1, "waste30": gdjs.TrainingLevelCode.GDwaste30Objects1, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects1, "waste32": gdjs.TrainingLevelCode.GDwaste32Objects1, "waste33": gdjs.TrainingLevelCode.GDwaste33Objects1, "waste34": gdjs.TrainingLevelCode.GDwaste34Objects1, "waste35": gdjs.TrainingLevelCode.GDwaste35Objects1, "waste36": gdjs.TrainingLevelCode.GDwaste36Objects1, "waste37": gdjs.TrainingLevelCode.GDwaste37Objects1, "waste38": gdjs.TrainingLevelCode.GDwaste38Objects1, "waste39": gdjs.TrainingLevelCode.GDwaste39Objects1, "waste40": gdjs.TrainingLevelCode.GDwaste40Objects1, "waste28": gdjs.TrainingLevelCode.GDwaste28Objects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste2Objects1Objects = Hashtable.newFrom({"waste2": gdjs.TrainingLevelCode.GDwaste2Objects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects1ObjectsGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects1ObjectsGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects1ObjectsGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects1Objects = Hashtable.newFrom({"PlasticBox": gdjs.TrainingLevelCode.GDPlasticBoxObjects1, "GlassBox": gdjs.TrainingLevelCode.GDGlassBoxObjects1, "PaperBox": gdjs.TrainingLevelCode.GDPaperBoxObjects1, "OtherBox": gdjs.TrainingLevelCode.GDOtherBoxObjects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste3Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste6Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste13Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects1Objects = Hashtable.newFrom({"waste1": gdjs.TrainingLevelCode.GDwaste1Objects1, "waste2": gdjs.TrainingLevelCode.GDwaste2Objects1, "waste3": gdjs.TrainingLevelCode.GDwaste3Objects1, "waste4": gdjs.TrainingLevelCode.GDwaste4Objects1, "waste5": gdjs.TrainingLevelCode.GDwaste5Objects1, "waste6": gdjs.TrainingLevelCode.GDwaste6Objects1, "waste7": gdjs.TrainingLevelCode.GDwaste7Objects1, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects1, "waste9": gdjs.TrainingLevelCode.GDwaste9Objects1, "waste10": gdjs.TrainingLevelCode.GDwaste10Objects1, "waste11": gdjs.TrainingLevelCode.GDwaste11Objects1, "waste12": gdjs.TrainingLevelCode.GDwaste12Objects1, "waste13": gdjs.TrainingLevelCode.GDwaste13Objects1, "waste14": gdjs.TrainingLevelCode.GDwaste14Objects1, "waste15": gdjs.TrainingLevelCode.GDwaste15Objects1, "waste17": gdjs.TrainingLevelCode.GDwaste17Objects1, "waste18": gdjs.TrainingLevelCode.GDwaste18Objects1, "waste19": gdjs.TrainingLevelCode.GDwaste19Objects1, "waste16": gdjs.TrainingLevelCode.GDwaste16Objects1, "waste20": gdjs.TrainingLevelCode.GDwaste20Objects1, "waste21": gdjs.TrainingLevelCode.GDwaste21Objects1, "waste22": gdjs.TrainingLevelCode.GDwaste22Objects1, "waste23": gdjs.TrainingLevelCode.GDwaste23Objects1, "waste24": gdjs.TrainingLevelCode.GDwaste24Objects1, "waste25": gdjs.TrainingLevelCode.GDwaste25Objects1, "waste26": gdjs.TrainingLevelCode.GDwaste26Objects1, "waste27": gdjs.TrainingLevelCode.GDwaste27Objects1, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects1, "waste30": gdjs.TrainingLevelCode.GDwaste30Objects1, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects1, "waste32": gdjs.TrainingLevelCode.GDwaste32Objects1, "waste33": gdjs.TrainingLevelCode.GDwaste33Objects1, "waste34": gdjs.TrainingLevelCode.GDwaste34Objects1, "waste35": gdjs.TrainingLevelCode.GDwaste35Objects1, "waste36": gdjs.TrainingLevelCode.GDwaste36Objects1, "waste37": gdjs.TrainingLevelCode.GDwaste37Objects1, "waste38": gdjs.TrainingLevelCode.GDwaste38Objects1, "waste39": gdjs.TrainingLevelCode.GDwaste39Objects1, "waste40": gdjs.TrainingLevelCode.GDwaste40Objects1, "waste28": gdjs.TrainingLevelCode.GDwaste28Objects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste6Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects2Objects = Hashtable.newFrom({"waste6": gdjs.TrainingLevelCode.GDwaste6Objects2, "waste7": gdjs.TrainingLevelCode.GDwaste7Objects2, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects2, "waste12": gdjs.TrainingLevelCode.GDwaste12Objects2, "waste24": gdjs.TrainingLevelCode.GDwaste24Objects2, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects2, "waste30": gdjs.TrainingLevelCode.GDwaste30Objects2, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects2, "waste39": gdjs.TrainingLevelCode.GDwaste39Objects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects2Objects = Hashtable.newFrom({"PlasticBox": gdjs.TrainingLevelCode.GDPlasticBoxObjects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3Objects = Hashtable.newFrom({"waste7": gdjs.TrainingLevelCode.GDwaste7Objects3, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects3, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects3, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects3Objects = Hashtable.newFrom({"PlasticBox": gdjs.TrainingLevelCode.GDPlasticBoxObjects3});gdjs.TrainingLevelCode.eventsList0 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects2, gdjs.TrainingLevelCode.GDPlasticBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects2, gdjs.TrainingLevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects2, gdjs.TrainingLevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects2, gdjs.TrainingLevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects2, gdjs.TrainingLevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects2, gdjs.TrainingLevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects2, gdjs.TrainingLevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects2, gdjs.TrainingLevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects2, gdjs.TrainingLevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects2, gdjs.TrainingLevelCode.GDwaste8Objects3);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.TrainingLevelCode.conditionTrue_1 = gdjs.TrainingLevelCode.condition0IsTrue_0;
gdjs.TrainingLevelCode.condition0IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste6Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste6Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste6Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste6Objects3[k] = gdjs.TrainingLevelCode.GDwaste6Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste6Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste7Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste7Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste7Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste7Objects3[k] = gdjs.TrainingLevelCode.GDwaste7Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste7Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste8Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste8Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste8Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste8Objects3[k] = gdjs.TrainingLevelCode.GDwaste8Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste8Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste12Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste12Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste12Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste12Objects3[k] = gdjs.TrainingLevelCode.GDwaste12Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste12Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste24Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste24Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste24Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste24Objects3[k] = gdjs.TrainingLevelCode.GDwaste24Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste24Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste29Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste29Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste29Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste29Objects3[k] = gdjs.TrainingLevelCode.GDwaste29Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste29Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste30Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste30Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste30Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste30Objects3[k] = gdjs.TrainingLevelCode.GDwaste30Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste30Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste31Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste31Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste31Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste31Objects3[k] = gdjs.TrainingLevelCode.GDwaste31Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste31Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste39Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste39Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste39Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste39Objects3[k] = gdjs.TrainingLevelCode.GDwaste39Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste39Objects3.length = k;}if ( gdjs.TrainingLevelCode.condition0IsTrue_1.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects3Objects, false, runtimeScene, false);
}}
gdjs.TrainingLevelCode.conditionTrue_1.val = true && gdjs.TrainingLevelCode.condition0IsTrue_1.val && gdjs.TrainingLevelCode.condition1IsTrue_1.val;
}
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.TrainingLevelCode.GDScoreObjects2, gdjs.TrainingLevelCode.GDScoreObjects3);

{runtimeScene.getVariables().get("UserScore").add(1);
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDScoreObjects3.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDScoreObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("UserScore"))));
}
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste3Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects2Objects = Hashtable.newFrom({"waste3": gdjs.TrainingLevelCode.GDwaste3Objects2, "waste10": gdjs.TrainingLevelCode.GDwaste10Objects2, "waste17": gdjs.TrainingLevelCode.GDwaste17Objects2, "waste18": gdjs.TrainingLevelCode.GDwaste18Objects2, "waste19": gdjs.TrainingLevelCode.GDwaste19Objects2, "waste16": gdjs.TrainingLevelCode.GDwaste16Objects2, "waste20": gdjs.TrainingLevelCode.GDwaste20Objects2, "waste21": gdjs.TrainingLevelCode.GDwaste21Objects2, "waste25": gdjs.TrainingLevelCode.GDwaste25Objects2, "waste26": gdjs.TrainingLevelCode.GDwaste26Objects2, "waste32": gdjs.TrainingLevelCode.GDwaste32Objects2, "waste33": gdjs.TrainingLevelCode.GDwaste33Objects2, "waste34": gdjs.TrainingLevelCode.GDwaste34Objects2, "waste37": gdjs.TrainingLevelCode.GDwaste37Objects2, "waste36": gdjs.TrainingLevelCode.GDwaste36Objects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects2Objects = Hashtable.newFrom({"OtherBox": gdjs.TrainingLevelCode.GDOtherBoxObjects2});gdjs.TrainingLevelCode.eventsList2 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects2Objects = Hashtable.newFrom({"waste1": gdjs.TrainingLevelCode.GDwaste1Objects2, "waste4": gdjs.TrainingLevelCode.GDwaste4Objects2, "waste9": gdjs.TrainingLevelCode.GDwaste9Objects2, "waste11": gdjs.TrainingLevelCode.GDwaste11Objects2, "waste15": gdjs.TrainingLevelCode.GDwaste15Objects2, "waste22": gdjs.TrainingLevelCode.GDwaste22Objects2, "waste38": gdjs.TrainingLevelCode.GDwaste38Objects2, "waste40": gdjs.TrainingLevelCode.GDwaste40Objects2, "waste5": gdjs.TrainingLevelCode.GDwaste5Objects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects2Objects = Hashtable.newFrom({"PaperBox": gdjs.TrainingLevelCode.GDPaperBoxObjects2});gdjs.TrainingLevelCode.eventsList3 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste13Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects2Objects = Hashtable.newFrom({"waste13": gdjs.TrainingLevelCode.GDwaste13Objects2, "waste14": gdjs.TrainingLevelCode.GDwaste14Objects2, "waste2": gdjs.TrainingLevelCode.GDwaste2Objects2, "waste23": gdjs.TrainingLevelCode.GDwaste23Objects2, "waste27": gdjs.TrainingLevelCode.GDwaste27Objects2, "waste28": gdjs.TrainingLevelCode.GDwaste28Objects2, "waste35": gdjs.TrainingLevelCode.GDwaste35Objects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects2Objects = Hashtable.newFrom({"GlassBox": gdjs.TrainingLevelCode.GDGlassBoxObjects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste27Objects3Objects = Hashtable.newFrom({"waste27": gdjs.TrainingLevelCode.GDwaste27Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects3Objects = Hashtable.newFrom({"GlassBox": gdjs.TrainingLevelCode.GDGlassBoxObjects3});gdjs.TrainingLevelCode.eventsList4 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects2, gdjs.TrainingLevelCode.GDGlassBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects2, gdjs.TrainingLevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects2, gdjs.TrainingLevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects2, gdjs.TrainingLevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects2, gdjs.TrainingLevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects2, gdjs.TrainingLevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects2, gdjs.TrainingLevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects2, gdjs.TrainingLevelCode.GDwaste35Objects3);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.TrainingLevelCode.conditionTrue_1 = gdjs.TrainingLevelCode.condition0IsTrue_0;
gdjs.TrainingLevelCode.condition0IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste13Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste13Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste13Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste13Objects3[k] = gdjs.TrainingLevelCode.GDwaste13Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste13Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste14Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste14Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste14Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste14Objects3[k] = gdjs.TrainingLevelCode.GDwaste14Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste14Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste2Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste2Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste2Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste2Objects3[k] = gdjs.TrainingLevelCode.GDwaste2Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste23Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste23Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste23Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste23Objects3[k] = gdjs.TrainingLevelCode.GDwaste23Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste23Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste27Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste27Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste27Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste27Objects3[k] = gdjs.TrainingLevelCode.GDwaste27Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste27Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste28Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste28Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste28Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste28Objects3[k] = gdjs.TrainingLevelCode.GDwaste28Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste28Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste35Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste35Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste35Objects3[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_1.val = true;
        gdjs.TrainingLevelCode.GDwaste35Objects3[k] = gdjs.TrainingLevelCode.GDwaste35Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste35Objects3.length = k;}if ( gdjs.TrainingLevelCode.condition0IsTrue_1.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste27Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects3Objects, false, runtimeScene, false);
}}
gdjs.TrainingLevelCode.conditionTrue_1.val = true && gdjs.TrainingLevelCode.condition0IsTrue_1.val && gdjs.TrainingLevelCode.condition1IsTrue_1.val;
}
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.TrainingLevelCode.GDScoreObjects2, gdjs.TrainingLevelCode.GDScoreObjects3);

{runtimeScene.getVariables().get("UserScore").add(1);
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDScoreObjects3.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDScoreObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("UserScore"))));
}
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Ninja Jump 04.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste6Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects3Objects = Hashtable.newFrom({"waste6": gdjs.TrainingLevelCode.GDwaste6Objects3, "waste7": gdjs.TrainingLevelCode.GDwaste7Objects3, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects3, "waste12": gdjs.TrainingLevelCode.GDwaste12Objects3, "waste24": gdjs.TrainingLevelCode.GDwaste24Objects3, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects3, "waste30": gdjs.TrainingLevelCode.GDwaste30Objects3, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects3, "waste39": gdjs.TrainingLevelCode.GDwaste39Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects3Objects = Hashtable.newFrom({"GlassBox": gdjs.TrainingLevelCode.GDGlassBoxObjects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste6Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects3Objects = Hashtable.newFrom({"waste6": gdjs.TrainingLevelCode.GDwaste6Objects3, "waste7": gdjs.TrainingLevelCode.GDwaste7Objects3, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects3, "waste12": gdjs.TrainingLevelCode.GDwaste12Objects3, "waste24": gdjs.TrainingLevelCode.GDwaste24Objects3, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects3, "waste30": gdjs.TrainingLevelCode.GDwaste30Objects3, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects3, "waste39": gdjs.TrainingLevelCode.GDwaste39Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects3Objects = Hashtable.newFrom({"PaperBox": gdjs.TrainingLevelCode.GDPaperBoxObjects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste6Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects3Objects = Hashtable.newFrom({"waste6": gdjs.TrainingLevelCode.GDwaste6Objects3, "waste7": gdjs.TrainingLevelCode.GDwaste7Objects3, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects3, "waste12": gdjs.TrainingLevelCode.GDwaste12Objects3, "waste24": gdjs.TrainingLevelCode.GDwaste24Objects3, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects3, "waste30": gdjs.TrainingLevelCode.GDwaste30Objects3, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects3, "waste39": gdjs.TrainingLevelCode.GDwaste39Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects3Objects = Hashtable.newFrom({"OtherBox": gdjs.TrainingLevelCode.GDOtherBoxObjects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3Objects = Hashtable.newFrom({"waste7": gdjs.TrainingLevelCode.GDwaste7Objects3, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects3, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects3, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects3Objects = Hashtable.newFrom({"PlasticBox": gdjs.TrainingLevelCode.GDPlasticBoxObjects3});gdjs.TrainingLevelCode.eventsList6 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt man 05.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste13Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects3Objects = Hashtable.newFrom({"waste13": gdjs.TrainingLevelCode.GDwaste13Objects3, "waste14": gdjs.TrainingLevelCode.GDwaste14Objects3, "waste2": gdjs.TrainingLevelCode.GDwaste2Objects3, "waste23": gdjs.TrainingLevelCode.GDwaste23Objects3, "waste27": gdjs.TrainingLevelCode.GDwaste27Objects3, "waste28": gdjs.TrainingLevelCode.GDwaste28Objects3, "waste35": gdjs.TrainingLevelCode.GDwaste35Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects3Objects = Hashtable.newFrom({"PlasticBox": gdjs.TrainingLevelCode.GDPlasticBoxObjects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste13Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects3Objects = Hashtable.newFrom({"waste13": gdjs.TrainingLevelCode.GDwaste13Objects3, "waste14": gdjs.TrainingLevelCode.GDwaste14Objects3, "waste2": gdjs.TrainingLevelCode.GDwaste2Objects3, "waste23": gdjs.TrainingLevelCode.GDwaste23Objects3, "waste27": gdjs.TrainingLevelCode.GDwaste27Objects3, "waste28": gdjs.TrainingLevelCode.GDwaste28Objects3, "waste35": gdjs.TrainingLevelCode.GDwaste35Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects3Objects = Hashtable.newFrom({"PaperBox": gdjs.TrainingLevelCode.GDPaperBoxObjects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste13Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects3Objects = Hashtable.newFrom({"waste13": gdjs.TrainingLevelCode.GDwaste13Objects3, "waste14": gdjs.TrainingLevelCode.GDwaste14Objects3, "waste2": gdjs.TrainingLevelCode.GDwaste2Objects3, "waste23": gdjs.TrainingLevelCode.GDwaste23Objects3, "waste27": gdjs.TrainingLevelCode.GDwaste27Objects3, "waste28": gdjs.TrainingLevelCode.GDwaste28Objects3, "waste35": gdjs.TrainingLevelCode.GDwaste35Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects3Objects = Hashtable.newFrom({"OtherBox": gdjs.TrainingLevelCode.GDOtherBoxObjects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste27Objects3Objects = Hashtable.newFrom({"waste27": gdjs.TrainingLevelCode.GDwaste27Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects3Objects = Hashtable.newFrom({"GlassBox": gdjs.TrainingLevelCode.GDGlassBoxObjects3});gdjs.TrainingLevelCode.eventsList7 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt man 05.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects3Objects = Hashtable.newFrom({"waste1": gdjs.TrainingLevelCode.GDwaste1Objects3, "waste4": gdjs.TrainingLevelCode.GDwaste4Objects3, "waste9": gdjs.TrainingLevelCode.GDwaste9Objects3, "waste11": gdjs.TrainingLevelCode.GDwaste11Objects3, "waste15": gdjs.TrainingLevelCode.GDwaste15Objects3, "waste22": gdjs.TrainingLevelCode.GDwaste22Objects3, "waste38": gdjs.TrainingLevelCode.GDwaste38Objects3, "waste40": gdjs.TrainingLevelCode.GDwaste40Objects3, "waste5": gdjs.TrainingLevelCode.GDwaste5Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects3Objects = Hashtable.newFrom({"PlasticBox": gdjs.TrainingLevelCode.GDPlasticBoxObjects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects3Objects = Hashtable.newFrom({"waste1": gdjs.TrainingLevelCode.GDwaste1Objects3, "waste4": gdjs.TrainingLevelCode.GDwaste4Objects3, "waste9": gdjs.TrainingLevelCode.GDwaste9Objects3, "waste11": gdjs.TrainingLevelCode.GDwaste11Objects3, "waste15": gdjs.TrainingLevelCode.GDwaste15Objects3, "waste22": gdjs.TrainingLevelCode.GDwaste22Objects3, "waste38": gdjs.TrainingLevelCode.GDwaste38Objects3, "waste40": gdjs.TrainingLevelCode.GDwaste40Objects3, "waste5": gdjs.TrainingLevelCode.GDwaste5Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects3Objects = Hashtable.newFrom({"GlassBox": gdjs.TrainingLevelCode.GDGlassBoxObjects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects3Objects = Hashtable.newFrom({"waste1": gdjs.TrainingLevelCode.GDwaste1Objects3, "waste4": gdjs.TrainingLevelCode.GDwaste4Objects3, "waste9": gdjs.TrainingLevelCode.GDwaste9Objects3, "waste11": gdjs.TrainingLevelCode.GDwaste11Objects3, "waste15": gdjs.TrainingLevelCode.GDwaste15Objects3, "waste22": gdjs.TrainingLevelCode.GDwaste22Objects3, "waste38": gdjs.TrainingLevelCode.GDwaste38Objects3, "waste40": gdjs.TrainingLevelCode.GDwaste40Objects3, "waste5": gdjs.TrainingLevelCode.GDwaste5Objects3});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects3Objects = Hashtable.newFrom({"OtherBox": gdjs.TrainingLevelCode.GDOtherBoxObjects3});gdjs.TrainingLevelCode.eventsList8 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt man 05.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste3Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects2Objects = Hashtable.newFrom({"waste3": gdjs.TrainingLevelCode.GDwaste3Objects2, "waste10": gdjs.TrainingLevelCode.GDwaste10Objects2, "waste17": gdjs.TrainingLevelCode.GDwaste17Objects2, "waste18": gdjs.TrainingLevelCode.GDwaste18Objects2, "waste19": gdjs.TrainingLevelCode.GDwaste19Objects2, "waste16": gdjs.TrainingLevelCode.GDwaste16Objects2, "waste20": gdjs.TrainingLevelCode.GDwaste20Objects2, "waste21": gdjs.TrainingLevelCode.GDwaste21Objects2, "waste25": gdjs.TrainingLevelCode.GDwaste25Objects2, "waste26": gdjs.TrainingLevelCode.GDwaste26Objects2, "waste32": gdjs.TrainingLevelCode.GDwaste32Objects2, "waste33": gdjs.TrainingLevelCode.GDwaste33Objects2, "waste34": gdjs.TrainingLevelCode.GDwaste34Objects2, "waste37": gdjs.TrainingLevelCode.GDwaste37Objects2, "waste36": gdjs.TrainingLevelCode.GDwaste36Objects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects2Objects = Hashtable.newFrom({"PlasticBox": gdjs.TrainingLevelCode.GDPlasticBoxObjects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste3Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects2Objects = Hashtable.newFrom({"waste3": gdjs.TrainingLevelCode.GDwaste3Objects2, "waste10": gdjs.TrainingLevelCode.GDwaste10Objects2, "waste17": gdjs.TrainingLevelCode.GDwaste17Objects2, "waste18": gdjs.TrainingLevelCode.GDwaste18Objects2, "waste19": gdjs.TrainingLevelCode.GDwaste19Objects2, "waste16": gdjs.TrainingLevelCode.GDwaste16Objects2, "waste20": gdjs.TrainingLevelCode.GDwaste20Objects2, "waste21": gdjs.TrainingLevelCode.GDwaste21Objects2, "waste25": gdjs.TrainingLevelCode.GDwaste25Objects2, "waste26": gdjs.TrainingLevelCode.GDwaste26Objects2, "waste32": gdjs.TrainingLevelCode.GDwaste32Objects2, "waste33": gdjs.TrainingLevelCode.GDwaste33Objects2, "waste34": gdjs.TrainingLevelCode.GDwaste34Objects2, "waste37": gdjs.TrainingLevelCode.GDwaste37Objects2, "waste36": gdjs.TrainingLevelCode.GDwaste36Objects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects2Objects = Hashtable.newFrom({"GlassBox": gdjs.TrainingLevelCode.GDGlassBoxObjects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste3Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects2Objects = Hashtable.newFrom({"waste3": gdjs.TrainingLevelCode.GDwaste3Objects2, "waste10": gdjs.TrainingLevelCode.GDwaste10Objects2, "waste17": gdjs.TrainingLevelCode.GDwaste17Objects2, "waste18": gdjs.TrainingLevelCode.GDwaste18Objects2, "waste19": gdjs.TrainingLevelCode.GDwaste19Objects2, "waste16": gdjs.TrainingLevelCode.GDwaste16Objects2, "waste20": gdjs.TrainingLevelCode.GDwaste20Objects2, "waste21": gdjs.TrainingLevelCode.GDwaste21Objects2, "waste25": gdjs.TrainingLevelCode.GDwaste25Objects2, "waste26": gdjs.TrainingLevelCode.GDwaste26Objects2, "waste32": gdjs.TrainingLevelCode.GDwaste32Objects2, "waste33": gdjs.TrainingLevelCode.GDwaste33Objects2, "waste34": gdjs.TrainingLevelCode.GDwaste34Objects2, "waste37": gdjs.TrainingLevelCode.GDwaste37Objects2, "waste36": gdjs.TrainingLevelCode.GDwaste36Objects2});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects2Objects = Hashtable.newFrom({"PaperBox": gdjs.TrainingLevelCode.GDPaperBoxObjects2});gdjs.TrainingLevelCode.eventsList9 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt man 05.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1, gdjs.TrainingLevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects2);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste6Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects2Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects2Objects, false, runtimeScene, false);
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.TrainingLevelCode.GDScoreObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste12Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste24Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste29Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste30Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste31Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste39Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste6Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste7Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste8Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects2);

{runtimeScene.getVariables().get("UserScore").add(1);
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDScoreObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("UserScore"))));
}
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects1, gdjs.TrainingLevelCode.GDOtherBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste3Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects2Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects2Objects, false, runtimeScene, false);
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.TrainingLevelCode.GDScoreObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste10Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste16Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste17Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste18Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste19Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste20Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste21Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste25Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste26Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste3Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste32Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste33Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste34Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste36Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste37Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects2);

{runtimeScene.getVariables().get("UserScore").add(1);
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDScoreObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("UserScore"))));
}
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects1, gdjs.TrainingLevelCode.GDPaperBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects2);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects2Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects2Objects, false, runtimeScene, false);
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.TrainingLevelCode.GDScoreObjects2);
/* Reuse gdjs.TrainingLevelCode.GDwaste1Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste11Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste15Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste22Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste38Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste4Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste40Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste5Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste9Objects2 */
{runtimeScene.getVariables().get("UserScore").add(1);
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDScoreObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("UserScore"))));
}
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1, gdjs.TrainingLevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects2);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste13Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects2Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects2Objects, false, runtimeScene, false);
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.TrainingLevelCode.GDScoreObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste13Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste14Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste2Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste23Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste27Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste28Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste35Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects2);

{runtimeScene.getVariables().get("UserScore").add(1);
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDScoreObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("UserScore"))));
}
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1, gdjs.TrainingLevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects1, gdjs.TrainingLevelCode.GDOtherBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects1, gdjs.TrainingLevelCode.GDPaperBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1, gdjs.TrainingLevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects2);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 1;
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.TrainingLevelCode.conditionTrue_1 = gdjs.TrainingLevelCode.condition1IsTrue_0;
gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste12Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste24Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste29Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste30Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste31Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste39Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste6Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste7Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste8Objects2_1final.length = 0;gdjs.TrainingLevelCode.condition0IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition2IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition3IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1, gdjs.TrainingLevelCode.GDGlassBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects3);

gdjs.TrainingLevelCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste6Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition0IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDGlassBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDGlassBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDGlassBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste12Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste12Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste12Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste12Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste12Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste24Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste24Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste24Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste24Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste24Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste29Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste29Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste29Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste29Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste29Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste30Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste30Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste30Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste30Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste30Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste31Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste31Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste31Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste31Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste31Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste39Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste39Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste39Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste39Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste39Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste6Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste6Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste6Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste6Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste6Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste7Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste7Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste7Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste7Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste7Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste8Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste8Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste8Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste8Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste8Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects1, gdjs.TrainingLevelCode.GDPaperBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects3);

gdjs.TrainingLevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste6Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition1IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDPaperBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDPaperBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDPaperBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste12Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste12Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste12Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste12Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste12Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste24Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste24Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste24Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste24Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste24Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste29Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste29Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste29Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste29Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste29Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste30Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste30Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste30Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste30Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste30Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste31Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste31Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste31Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste31Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste31Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste39Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste39Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste39Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste39Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste39Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste6Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste6Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste6Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste6Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste6Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste7Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste7Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste7Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste7Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste7Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste8Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste8Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste8Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste8Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste8Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects1, gdjs.TrainingLevelCode.GDOtherBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects3);

gdjs.TrainingLevelCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste6Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition2IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDOtherBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDOtherBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDOtherBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste12Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste12Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste12Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste12Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste12Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste24Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste24Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste24Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste24Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste24Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste29Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste29Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste29Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste29Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste29Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste30Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste30Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste30Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste30Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste30Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste31Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste31Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste31Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste31Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste31Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste39Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste39Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste39Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste39Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste39Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste6Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste6Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste6Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste6Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste6Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste7Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste7Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste7Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste7Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste7Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste8Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste8Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste8Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste8Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste8Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1, gdjs.TrainingLevelCode.GDPlasticBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects3);

{gdjs.TrainingLevelCode.conditionTrue_2 = gdjs.TrainingLevelCode.condition3IsTrue_1;
gdjs.TrainingLevelCode.condition0IsTrue_2.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_2.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste7Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects3Objects, false, runtimeScene, false);
}if ( gdjs.TrainingLevelCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste6Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste6Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste6Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste6Objects3[k] = gdjs.TrainingLevelCode.GDwaste6Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste6Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste7Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste7Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste7Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste7Objects3[k] = gdjs.TrainingLevelCode.GDwaste7Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste7Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste8Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste8Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste8Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste8Objects3[k] = gdjs.TrainingLevelCode.GDwaste8Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste8Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste12Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste12Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste12Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste12Objects3[k] = gdjs.TrainingLevelCode.GDwaste12Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste12Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste24Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste24Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste24Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste24Objects3[k] = gdjs.TrainingLevelCode.GDwaste24Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste24Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste29Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste29Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste29Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste29Objects3[k] = gdjs.TrainingLevelCode.GDwaste29Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste29Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste30Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste30Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste30Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste30Objects3[k] = gdjs.TrainingLevelCode.GDwaste30Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste30Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste31Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste31Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste31Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste31Objects3[k] = gdjs.TrainingLevelCode.GDwaste31Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste31Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste39Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste39Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste39Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste39Objects3[k] = gdjs.TrainingLevelCode.GDwaste39Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste39Objects3.length = k;}}
gdjs.TrainingLevelCode.conditionTrue_2.val = true && gdjs.TrainingLevelCode.condition0IsTrue_2.val && gdjs.TrainingLevelCode.condition1IsTrue_2.val;
}
if( gdjs.TrainingLevelCode.condition3IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDPlasticBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDPlasticBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDPlasticBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste12Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste12Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste12Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste12Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste12Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste24Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste24Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste24Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste24Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste24Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste29Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste29Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste29Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste29Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste29Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste30Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste30Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste30Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste30Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste30Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste31Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste31Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste31Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste31Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste31Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste39Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste39Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste39Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste39Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste39Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste6Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste6Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste6Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste6Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste6Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste7Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste7Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste7Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste7Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste7Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste8Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste8Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste8Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste8Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste8Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final, gdjs.TrainingLevelCode.GDGlassBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final, gdjs.TrainingLevelCode.GDOtherBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final, gdjs.TrainingLevelCode.GDPaperBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final, gdjs.TrainingLevelCode.GDPlasticBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects2_1final, gdjs.TrainingLevelCode.GDwaste12Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects2_1final, gdjs.TrainingLevelCode.GDwaste24Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects2_1final, gdjs.TrainingLevelCode.GDwaste29Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects2_1final, gdjs.TrainingLevelCode.GDwaste30Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects2_1final, gdjs.TrainingLevelCode.GDwaste31Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects2_1final, gdjs.TrainingLevelCode.GDwaste39Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects2_1final, gdjs.TrainingLevelCode.GDwaste6Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects2_1final, gdjs.TrainingLevelCode.GDwaste7Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects2_1final, gdjs.TrainingLevelCode.GDwaste8Objects2);
}
}
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste12Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste24Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste29Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste30Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste31Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste39Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste6Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste7Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste8Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects2);

{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Plastic");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Help");
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1, gdjs.TrainingLevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects1, gdjs.TrainingLevelCode.GDOtherBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects1, gdjs.TrainingLevelCode.GDPaperBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1, gdjs.TrainingLevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects2);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 2;
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.TrainingLevelCode.conditionTrue_1 = gdjs.TrainingLevelCode.condition1IsTrue_0;
gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste13Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste14Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste2Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste23Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste27Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste28Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste35Objects2_1final.length = 0;gdjs.TrainingLevelCode.condition0IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition2IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition3IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1, gdjs.TrainingLevelCode.GDPlasticBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects3);

gdjs.TrainingLevelCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste13Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition0IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDPlasticBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDPlasticBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDPlasticBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste13Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste13Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste13Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste13Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste13Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste14Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste14Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste14Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste14Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste14Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste2Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste2Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste2Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste2Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste23Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste23Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste23Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste23Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste23Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste27Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste27Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste27Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste27Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste27Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste28Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste28Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste28Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste28Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste28Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste35Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste35Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste35Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste35Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste35Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects1, gdjs.TrainingLevelCode.GDPaperBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects3);

gdjs.TrainingLevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste13Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition1IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDPaperBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDPaperBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDPaperBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste13Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste13Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste13Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste13Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste13Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste14Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste14Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste14Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste14Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste14Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste2Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste2Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste2Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste2Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste23Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste23Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste23Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste23Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste23Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste27Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste27Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste27Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste27Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste27Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste28Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste28Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste28Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste28Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste28Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste35Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste35Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste35Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste35Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste35Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects1, gdjs.TrainingLevelCode.GDOtherBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects3);

gdjs.TrainingLevelCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste13Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition2IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDOtherBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDOtherBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDOtherBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste13Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste13Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste13Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste13Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste13Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste14Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste14Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste14Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste14Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste14Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste2Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste2Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste2Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste2Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste23Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste23Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste23Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste23Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste23Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste27Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste27Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste27Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste27Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste27Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste28Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste28Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste28Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste28Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste28Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste35Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste35Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste35Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste35Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste35Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1, gdjs.TrainingLevelCode.GDGlassBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects3);

{gdjs.TrainingLevelCode.conditionTrue_2 = gdjs.TrainingLevelCode.condition3IsTrue_1;
gdjs.TrainingLevelCode.condition0IsTrue_2.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_2.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste27Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects3Objects, false, runtimeScene, false);
}if ( gdjs.TrainingLevelCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste13Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste13Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste13Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste13Objects3[k] = gdjs.TrainingLevelCode.GDwaste13Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste13Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste14Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste14Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste14Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste14Objects3[k] = gdjs.TrainingLevelCode.GDwaste14Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste14Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste2Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste2Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste2Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste2Objects3[k] = gdjs.TrainingLevelCode.GDwaste2Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste23Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste23Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste23Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste23Objects3[k] = gdjs.TrainingLevelCode.GDwaste23Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste23Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste27Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste27Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste27Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste27Objects3[k] = gdjs.TrainingLevelCode.GDwaste27Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste27Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste28Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste28Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste28Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste28Objects3[k] = gdjs.TrainingLevelCode.GDwaste28Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste28Objects3.length = k;for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste35Objects3.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste35Objects3[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste35Objects3[i].getVariables().get("Clean")) == 0 ) {
        gdjs.TrainingLevelCode.condition1IsTrue_2.val = true;
        gdjs.TrainingLevelCode.GDwaste35Objects3[k] = gdjs.TrainingLevelCode.GDwaste35Objects3[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste35Objects3.length = k;}}
gdjs.TrainingLevelCode.conditionTrue_2.val = true && gdjs.TrainingLevelCode.condition0IsTrue_2.val && gdjs.TrainingLevelCode.condition1IsTrue_2.val;
}
if( gdjs.TrainingLevelCode.condition3IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDGlassBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDGlassBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDGlassBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste13Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste13Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste13Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste13Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste13Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste14Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste14Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste14Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste14Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste14Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste2Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste2Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste2Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste2Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste23Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste23Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste23Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste23Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste23Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste27Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste27Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste27Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste27Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste27Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste28Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste28Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste28Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste28Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste28Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste35Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste35Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste35Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste35Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste35Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final, gdjs.TrainingLevelCode.GDGlassBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final, gdjs.TrainingLevelCode.GDOtherBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects2_1final, gdjs.TrainingLevelCode.GDPaperBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final, gdjs.TrainingLevelCode.GDPlasticBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects2_1final, gdjs.TrainingLevelCode.GDwaste13Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects2_1final, gdjs.TrainingLevelCode.GDwaste14Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects2_1final, gdjs.TrainingLevelCode.GDwaste2Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects2_1final, gdjs.TrainingLevelCode.GDwaste23Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects2_1final, gdjs.TrainingLevelCode.GDwaste27Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects2_1final, gdjs.TrainingLevelCode.GDwaste28Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects2_1final, gdjs.TrainingLevelCode.GDwaste35Objects2);
}
}
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste13Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste14Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste2Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste23Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste27Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste28Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste35Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects2);

{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Glass");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Help");
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1, gdjs.TrainingLevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects1, gdjs.TrainingLevelCode.GDOtherBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1, gdjs.TrainingLevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects2);


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 3;
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.TrainingLevelCode.conditionTrue_1 = gdjs.TrainingLevelCode.condition1IsTrue_0;
gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste1Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste11Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste15Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste22Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste38Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste4Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste40Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste5Objects2_1final.length = 0;gdjs.TrainingLevelCode.GDwaste9Objects2_1final.length = 0;gdjs.TrainingLevelCode.condition0IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1, gdjs.TrainingLevelCode.GDPlasticBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects3);

gdjs.TrainingLevelCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition0IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDPlasticBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDPlasticBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDPlasticBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste1Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste1Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste1Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste1Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste1Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste11Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste11Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste11Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste11Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste11Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste15Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste15Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste15Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste15Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste15Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste22Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste22Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste22Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste22Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste22Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste38Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste38Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste38Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste38Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste38Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste4Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste4Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste4Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste4Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste4Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste40Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste40Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste40Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste40Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste40Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste5Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste5Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste5Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste5Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste5Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste9Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste9Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste9Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste9Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste9Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1, gdjs.TrainingLevelCode.GDGlassBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects3);

gdjs.TrainingLevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition1IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDGlassBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDGlassBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDGlassBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste1Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste1Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste1Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste1Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste1Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste11Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste11Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste11Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste11Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste11Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste15Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste15Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste15Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste15Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste15Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste22Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste22Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste22Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste22Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste22Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste38Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste38Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste38Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste38Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste38Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste4Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste4Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste4Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste4Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste4Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste40Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste40Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste40Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste40Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste40Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste5Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste5Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste5Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste5Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste5Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste9Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste9Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste9Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste9Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste9Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects1, gdjs.TrainingLevelCode.GDOtherBoxObjects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects1, gdjs.TrainingLevelCode.GDwaste1Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects1, gdjs.TrainingLevelCode.GDwaste11Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects1, gdjs.TrainingLevelCode.GDwaste15Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects1, gdjs.TrainingLevelCode.GDwaste22Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects1, gdjs.TrainingLevelCode.GDwaste38Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects1, gdjs.TrainingLevelCode.GDwaste4Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects1, gdjs.TrainingLevelCode.GDwaste40Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects1, gdjs.TrainingLevelCode.GDwaste5Objects3);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects1, gdjs.TrainingLevelCode.GDwaste9Objects3);

gdjs.TrainingLevelCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects3ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects3Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects3Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition2IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDOtherBoxObjects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.indexOf(gdjs.TrainingLevelCode.GDOtherBoxObjects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final.push(gdjs.TrainingLevelCode.GDOtherBoxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste1Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste1Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste1Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste1Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste1Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste11Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste11Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste11Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste11Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste11Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste15Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste15Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste15Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste15Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste15Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste22Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste22Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste22Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste22Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste22Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste38Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste38Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste38Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste38Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste38Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste4Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste4Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste4Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste4Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste4Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste40Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste40Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste40Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste40Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste40Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste5Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste5Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste5Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste5Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste5Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste9Objects3.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste9Objects2_1final.indexOf(gdjs.TrainingLevelCode.GDwaste9Objects3[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste9Objects2_1final.push(gdjs.TrainingLevelCode.GDwaste9Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects2_1final, gdjs.TrainingLevelCode.GDGlassBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDOtherBoxObjects2_1final, gdjs.TrainingLevelCode.GDOtherBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects2_1final, gdjs.TrainingLevelCode.GDPlasticBoxObjects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste1Objects2_1final, gdjs.TrainingLevelCode.GDwaste1Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste11Objects2_1final, gdjs.TrainingLevelCode.GDwaste11Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste15Objects2_1final, gdjs.TrainingLevelCode.GDwaste15Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste22Objects2_1final, gdjs.TrainingLevelCode.GDwaste22Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste38Objects2_1final, gdjs.TrainingLevelCode.GDwaste38Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste4Objects2_1final, gdjs.TrainingLevelCode.GDwaste4Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste40Objects2_1final, gdjs.TrainingLevelCode.GDwaste40Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste5Objects2_1final, gdjs.TrainingLevelCode.GDwaste5Objects2);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste9Objects2_1final, gdjs.TrainingLevelCode.GDwaste9Objects2);
}
}
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste1Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste11Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste12Objects1, gdjs.TrainingLevelCode.GDwaste12Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste13Objects1, gdjs.TrainingLevelCode.GDwaste13Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste14Objects1, gdjs.TrainingLevelCode.GDwaste14Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste15Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste2Objects1, gdjs.TrainingLevelCode.GDwaste2Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste22Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste23Objects1, gdjs.TrainingLevelCode.GDwaste23Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste24Objects1, gdjs.TrainingLevelCode.GDwaste24Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste27Objects1, gdjs.TrainingLevelCode.GDwaste27Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste28Objects1, gdjs.TrainingLevelCode.GDwaste28Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste29Objects1, gdjs.TrainingLevelCode.GDwaste29Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste30Objects1, gdjs.TrainingLevelCode.GDwaste30Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste31Objects1, gdjs.TrainingLevelCode.GDwaste31Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste35Objects1, gdjs.TrainingLevelCode.GDwaste35Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste38Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste39Objects1, gdjs.TrainingLevelCode.GDwaste39Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste4Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste40Objects2 */
/* Reuse gdjs.TrainingLevelCode.GDwaste5Objects2 */
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste6Objects1, gdjs.TrainingLevelCode.GDwaste6Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste7Objects1, gdjs.TrainingLevelCode.GDwaste7Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste8Objects1, gdjs.TrainingLevelCode.GDwaste8Objects2);

/* Reuse gdjs.TrainingLevelCode.GDwaste9Objects2 */
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Paper");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Help1");
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TrainingLevelCode.GDGlassBoxObjects1 */
/* Reuse gdjs.TrainingLevelCode.GDPaperBoxObjects1 */
/* Reuse gdjs.TrainingLevelCode.GDPlasticBoxObjects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste10Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste16Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste17Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste18Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste19Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste20Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste21Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste25Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste26Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste3Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste32Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste33Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste34Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste36Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste37Objects1 */

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 4;
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.TrainingLevelCode.conditionTrue_1 = gdjs.TrainingLevelCode.condition1IsTrue_0;
gdjs.TrainingLevelCode.GDGlassBoxObjects1_1final.length = 0;gdjs.TrainingLevelCode.GDPaperBoxObjects1_1final.length = 0;gdjs.TrainingLevelCode.GDPlasticBoxObjects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste10Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste16Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste17Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste18Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste19Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste20Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste21Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste25Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste26Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste3Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste32Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste33Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste34Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste36Objects1_1final.length = 0;gdjs.TrainingLevelCode.GDwaste37Objects1_1final.length = 0;gdjs.TrainingLevelCode.condition0IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_1.val = false;
gdjs.TrainingLevelCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1, gdjs.TrainingLevelCode.GDPlasticBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

gdjs.TrainingLevelCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste3Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects2Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects2Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition0IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDPlasticBoxObjects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDPlasticBoxObjects1_1final.indexOf(gdjs.TrainingLevelCode.GDPlasticBoxObjects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDPlasticBoxObjects1_1final.push(gdjs.TrainingLevelCode.GDPlasticBoxObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste10Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste10Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste10Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste10Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste10Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste16Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste16Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste16Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste16Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste16Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste17Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste17Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste17Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste17Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste17Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste18Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste18Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste18Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste18Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste18Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste19Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste19Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste19Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste19Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste19Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste20Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste20Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste20Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste20Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste20Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste21Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste21Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste21Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste21Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste21Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste25Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste25Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste25Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste25Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste25Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste26Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste26Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste26Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste26Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste26Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste3Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste3Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste3Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste3Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste32Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste32Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste32Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste32Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste32Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste33Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste33Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste33Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste33Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste33Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste34Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste34Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste34Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste34Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste34Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste36Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste36Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste36Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste36Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste36Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste37Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste37Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste37Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste37Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste37Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1, gdjs.TrainingLevelCode.GDGlassBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

gdjs.TrainingLevelCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste3Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects2Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects2Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition1IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDGlassBoxObjects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDGlassBoxObjects1_1final.indexOf(gdjs.TrainingLevelCode.GDGlassBoxObjects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDGlassBoxObjects1_1final.push(gdjs.TrainingLevelCode.GDGlassBoxObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste10Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste10Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste10Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste10Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste10Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste16Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste16Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste16Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste16Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste16Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste17Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste17Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste17Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste17Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste17Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste18Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste18Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste18Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste18Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste18Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste19Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste19Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste19Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste19Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste19Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste20Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste20Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste20Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste20Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste20Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste21Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste21Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste21Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste21Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste21Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste25Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste25Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste25Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste25Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste25Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste26Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste26Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste26Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste26Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste26Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste3Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste3Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste3Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste3Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste32Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste32Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste32Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste32Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste32Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste33Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste33Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste33Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste33Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste33Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste34Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste34Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste34Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste34Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste34Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste36Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste36Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste36Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste36Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste36Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste37Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste37Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste37Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste37Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste37Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects1, gdjs.TrainingLevelCode.GDPaperBoxObjects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1, gdjs.TrainingLevelCode.GDwaste10Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1, gdjs.TrainingLevelCode.GDwaste16Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1, gdjs.TrainingLevelCode.GDwaste17Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1, gdjs.TrainingLevelCode.GDwaste18Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1, gdjs.TrainingLevelCode.GDwaste19Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1, gdjs.TrainingLevelCode.GDwaste20Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1, gdjs.TrainingLevelCode.GDwaste21Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1, gdjs.TrainingLevelCode.GDwaste25Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1, gdjs.TrainingLevelCode.GDwaste26Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1, gdjs.TrainingLevelCode.GDwaste3Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1, gdjs.TrainingLevelCode.GDwaste32Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1, gdjs.TrainingLevelCode.GDwaste33Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1, gdjs.TrainingLevelCode.GDwaste34Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1, gdjs.TrainingLevelCode.GDwaste36Objects2);

gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1, gdjs.TrainingLevelCode.GDwaste37Objects2);

gdjs.TrainingLevelCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste3Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects2ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects2Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects2Objects, false, runtimeScene, false);
if( gdjs.TrainingLevelCode.condition2IsTrue_1.val ) {
    gdjs.TrainingLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDPaperBoxObjects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDPaperBoxObjects1_1final.indexOf(gdjs.TrainingLevelCode.GDPaperBoxObjects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDPaperBoxObjects1_1final.push(gdjs.TrainingLevelCode.GDPaperBoxObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste10Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste10Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste10Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste10Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste10Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste16Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste16Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste16Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste16Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste16Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste17Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste17Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste17Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste17Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste17Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste18Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste18Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste18Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste18Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste18Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste19Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste19Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste19Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste19Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste19Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste20Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste20Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste20Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste20Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste20Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste21Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste21Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste21Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste21Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste21Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste25Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste25Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste25Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste25Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste25Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste26Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste26Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste26Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste26Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste26Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste3Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste3Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste3Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste3Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste32Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste32Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste32Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste32Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste32Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste33Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste33Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste33Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste33Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste33Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste34Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste34Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste34Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste34Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste34Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste36Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste36Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste36Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste36Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste36Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.TrainingLevelCode.GDwaste37Objects2.length;j<jLen;++j) {
        if ( gdjs.TrainingLevelCode.GDwaste37Objects1_1final.indexOf(gdjs.TrainingLevelCode.GDwaste37Objects2[j]) === -1 )
            gdjs.TrainingLevelCode.GDwaste37Objects1_1final.push(gdjs.TrainingLevelCode.GDwaste37Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TrainingLevelCode.GDGlassBoxObjects1_1final, gdjs.TrainingLevelCode.GDGlassBoxObjects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDPaperBoxObjects1_1final, gdjs.TrainingLevelCode.GDPaperBoxObjects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDPlasticBoxObjects1_1final, gdjs.TrainingLevelCode.GDPlasticBoxObjects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste10Objects1_1final, gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste16Objects1_1final, gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste17Objects1_1final, gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste18Objects1_1final, gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste19Objects1_1final, gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste20Objects1_1final, gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste21Objects1_1final, gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste25Objects1_1final, gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste26Objects1_1final, gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste3Objects1_1final, gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste32Objects1_1final, gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste33Objects1_1final, gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste34Objects1_1final, gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste36Objects1_1final, gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(gdjs.TrainingLevelCode.GDwaste37Objects1_1final, gdjs.TrainingLevelCode.GDwaste37Objects1);
}
}
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste1Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste10Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste11Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste12Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste13Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste14Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste15Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste16Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste17Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste18Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste19Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste2Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste20Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste21Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste22Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste23Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste24Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste25Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste26Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste27Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste28Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste29Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste3Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste30Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste31Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste32Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste33Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste34Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste35Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste36Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste37Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste38Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste39Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste4Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste40Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste5Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste6Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste7Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste8Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste9Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Other");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Help1");
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPrevObjects1Objects = Hashtable.newFrom({"Prev": gdjs.TrainingLevelCode.GDPrevObjects1});gdjs.TrainingLevelCode.eventsList11 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "start.mp3", 1, true, 100, 1);
}}

}


};gdjs.TrainingLevelCode.eventsList12 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "ModeMenu", false);
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste3Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste6Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste13Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects1Objects = Hashtable.newFrom({"waste1": gdjs.TrainingLevelCode.GDwaste1Objects1, "waste2": gdjs.TrainingLevelCode.GDwaste2Objects1, "waste3": gdjs.TrainingLevelCode.GDwaste3Objects1, "waste4": gdjs.TrainingLevelCode.GDwaste4Objects1, "waste5": gdjs.TrainingLevelCode.GDwaste5Objects1, "waste6": gdjs.TrainingLevelCode.GDwaste6Objects1, "waste7": gdjs.TrainingLevelCode.GDwaste7Objects1, "waste8": gdjs.TrainingLevelCode.GDwaste8Objects1, "waste9": gdjs.TrainingLevelCode.GDwaste9Objects1, "waste10": gdjs.TrainingLevelCode.GDwaste10Objects1, "waste11": gdjs.TrainingLevelCode.GDwaste11Objects1, "waste12": gdjs.TrainingLevelCode.GDwaste12Objects1, "waste13": gdjs.TrainingLevelCode.GDwaste13Objects1, "waste14": gdjs.TrainingLevelCode.GDwaste14Objects1, "waste15": gdjs.TrainingLevelCode.GDwaste15Objects1, "waste17": gdjs.TrainingLevelCode.GDwaste17Objects1, "waste18": gdjs.TrainingLevelCode.GDwaste18Objects1, "waste19": gdjs.TrainingLevelCode.GDwaste19Objects1, "waste16": gdjs.TrainingLevelCode.GDwaste16Objects1, "waste20": gdjs.TrainingLevelCode.GDwaste20Objects1, "waste21": gdjs.TrainingLevelCode.GDwaste21Objects1, "waste22": gdjs.TrainingLevelCode.GDwaste22Objects1, "waste23": gdjs.TrainingLevelCode.GDwaste23Objects1, "waste24": gdjs.TrainingLevelCode.GDwaste24Objects1, "waste25": gdjs.TrainingLevelCode.GDwaste25Objects1, "waste26": gdjs.TrainingLevelCode.GDwaste26Objects1, "waste27": gdjs.TrainingLevelCode.GDwaste27Objects1, "waste29": gdjs.TrainingLevelCode.GDwaste29Objects1, "waste30": gdjs.TrainingLevelCode.GDwaste30Objects1, "waste31": gdjs.TrainingLevelCode.GDwaste31Objects1, "waste32": gdjs.TrainingLevelCode.GDwaste32Objects1, "waste33": gdjs.TrainingLevelCode.GDwaste33Objects1, "waste34": gdjs.TrainingLevelCode.GDwaste34Objects1, "waste35": gdjs.TrainingLevelCode.GDwaste35Objects1, "waste36": gdjs.TrainingLevelCode.GDwaste36Objects1, "waste37": gdjs.TrainingLevelCode.GDwaste37Objects1, "waste38": gdjs.TrainingLevelCode.GDwaste38Objects1, "waste39": gdjs.TrainingLevelCode.GDwaste39Objects1, "waste40": gdjs.TrainingLevelCode.GDwaste40Objects1, "waste28": gdjs.TrainingLevelCode.GDwaste28Objects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDCleanButtonObjects1Objects = Hashtable.newFrom({"CleanButton": gdjs.TrainingLevelCode.GDCleanButtonObjects1});gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDCleanButtonObjects1Objects = Hashtable.newFrom({"CleanButton": gdjs.TrainingLevelCode.GDCleanButtonObjects1});gdjs.TrainingLevelCode.eventsList13 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "помыть.wav", false, 100, 1);
}}

}


};gdjs.TrainingLevelCode.eventsList14 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste1Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste2Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste3Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste4Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste5Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste6Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste7Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste8Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste9Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste10Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste11Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste12Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste13Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste14Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste15Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste17Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste18Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste19Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste16Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste20Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste21Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste22Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste23Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste24Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste25Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste26Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste27Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste29Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste30Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste31Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste32Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste33Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste34Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste35Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste36Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste37Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste38Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste39Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste40Objects1[i].getVariables().get("Clean")).setNumber(1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste28Objects1[i].getVariables().get("Clean")).setNumber(1);
}
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.TrainingLevelCode.eventsList15 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.TrainingLevelCode.GDSoundObjects2);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDSoundObjects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDSoundObjects2[i].setAnimationName("On");
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "play.mp3", 1, true, 70, 1);
}}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 0;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.TrainingLevelCode.GDSoundObjects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDSoundObjects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDSoundObjects1[i].setAnimationName("Off");
}
}}

}


};gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDSoundObjects1Objects = Hashtable.newFrom({"Sound": gdjs.TrainingLevelCode.GDSoundObjects1});gdjs.TrainingLevelCode.eventsList16 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 0;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "play.mp3", 1, false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}}

}


};gdjs.TrainingLevelCode.eventsList17 = function(runtimeScene) {

{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.TrainingLevelCode.GDSoundObjects1, gdjs.TrainingLevelCode.GDSoundObjects2);

{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(0);
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDSoundObjects2.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDSoundObjects2[i].setAnimationName("Off");
}
}{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 0;
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDSoundObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(1);
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDSoundObjects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDSoundObjects1[i].setAnimationName("On");
}
}{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.TrainingLevelCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.TrainingLevelCode.GDSoundObjects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDSoundObjects1Objects, runtimeScene, true, false);
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.TrainingLevelCode.eventsList19 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlasticBox"), gdjs.TrainingLevelCode.GDPlasticBoxObjects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDPlasticBoxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlasticBox"), gdjs.TrainingLevelCode.GDPlasticBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPlasticBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GlassBox"), gdjs.TrainingLevelCode.GDGlassBoxObjects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDGlassBoxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(2);
}}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GlassBox"), gdjs.TrainingLevelCode.GDGlassBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDGlassBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDGlassBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(2);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PaperBox"), gdjs.TrainingLevelCode.GDPaperBoxObjects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDPaperBoxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(3);
}}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PaperBox"), gdjs.TrainingLevelCode.GDPaperBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDPaperBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDPaperBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(3);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("OtherBox"), gdjs.TrainingLevelCode.GDOtherBoxObjects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDOtherBoxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(4);
}}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("OtherBox"), gdjs.TrainingLevelCode.GDOtherBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addForceTowardObject((gdjs.TrainingLevelCode.GDOtherBoxObjects1.length !== 0 ? gdjs.TrainingLevelCode.GDOtherBoxObjects1[0] : null), 5000, 1);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber(4);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
gdjs.TrainingLevelCode.condition1IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "WasteCreation");
}if ( gdjs.TrainingLevelCode.condition0IsTrue_0.val ) {
{
gdjs.TrainingLevelCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste3Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste6Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste13Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects1Objects) < 1;
}}
if (gdjs.TrainingLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste1Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste10Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste11Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste12Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste13Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste14Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste15Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste16Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste17Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste18Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste19Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste2Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste20Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste21Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste22Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste23Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste24Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste25Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste26Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste27Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste28Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste29Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste3Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste30Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste31Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste32Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste33Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste34Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste35Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste36Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste37Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste38Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste39Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste4Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste40Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste5Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste6Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste7Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste8Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste9Objects1 */
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "WasteCreation");
}{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste1Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste2Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste3Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste4Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste5Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste6Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste7Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste8Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste9Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste10Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste11Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste12Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste13Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste14Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste15Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste17Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste18Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste19Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste16Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste20Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste21Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste22Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste23Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste24Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste25Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste26Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste27Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste29Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste30Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste31Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste32Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste33Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste34Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste35Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste36Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste37Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste38Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste39Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste40Objects1[i].getVariables().get("Clean")).setNumber(0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].returnVariable(gdjs.TrainingLevelCode.GDwaste28Objects1[i].getVariables().get("Clean")).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setString("waste" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 40)));
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste2Objects1Objects, gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)), 376, 360, "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}}

}


{



}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 0;
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addPolarForce(90, 50 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)), 0);
}
}}

}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = !(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 0);
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].addPolarForce(0, 0, 0);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].addPolarForce(0, 0, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GlassBox"), gdjs.TrainingLevelCode.GDGlassBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("OtherBox"), gdjs.TrainingLevelCode.GDOtherBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("PaperBox"), gdjs.TrainingLevelCode.GDPaperBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlasticBox"), gdjs.TrainingLevelCode.GDPlasticBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPlasticBoxObjects1ObjectsGDgdjs_46TrainingLevelCode_46GDGlassBoxObjects1ObjectsGDgdjs_46TrainingLevelCode_46GDPaperBoxObjects1ObjectsGDgdjs_46TrainingLevelCode_46GDOtherBoxObjects1Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste3Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste6Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste13Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects1Objects, false, runtimeScene, true);
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.TrainingLevelCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Prev"), gdjs.TrainingLevelCode.GDPrevObjects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDPrevObjects1Objects, runtimeScene, true, false);
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.TrainingLevelCode.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("CleanButton"), gdjs.TrainingLevelCode.GDCleanButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("waste1"), gdjs.TrainingLevelCode.GDwaste1Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste10"), gdjs.TrainingLevelCode.GDwaste10Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste11"), gdjs.TrainingLevelCode.GDwaste11Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste12"), gdjs.TrainingLevelCode.GDwaste12Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste13"), gdjs.TrainingLevelCode.GDwaste13Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste14"), gdjs.TrainingLevelCode.GDwaste14Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste15"), gdjs.TrainingLevelCode.GDwaste15Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste16"), gdjs.TrainingLevelCode.GDwaste16Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste17"), gdjs.TrainingLevelCode.GDwaste17Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste18"), gdjs.TrainingLevelCode.GDwaste18Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste19"), gdjs.TrainingLevelCode.GDwaste19Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste2"), gdjs.TrainingLevelCode.GDwaste2Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste20"), gdjs.TrainingLevelCode.GDwaste20Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste21"), gdjs.TrainingLevelCode.GDwaste21Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste22"), gdjs.TrainingLevelCode.GDwaste22Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste23"), gdjs.TrainingLevelCode.GDwaste23Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste24"), gdjs.TrainingLevelCode.GDwaste24Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste25"), gdjs.TrainingLevelCode.GDwaste25Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste26"), gdjs.TrainingLevelCode.GDwaste26Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste28"), gdjs.TrainingLevelCode.GDwaste28Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste3"), gdjs.TrainingLevelCode.GDwaste3Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste30"), gdjs.TrainingLevelCode.GDwaste30Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste32"), gdjs.TrainingLevelCode.GDwaste32Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste33"), gdjs.TrainingLevelCode.GDwaste33Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste34"), gdjs.TrainingLevelCode.GDwaste34Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste35"), gdjs.TrainingLevelCode.GDwaste35Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste36"), gdjs.TrainingLevelCode.GDwaste36Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste37"), gdjs.TrainingLevelCode.GDwaste37Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste38"), gdjs.TrainingLevelCode.GDwaste38Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste39"), gdjs.TrainingLevelCode.GDwaste39Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste4"), gdjs.TrainingLevelCode.GDwaste4Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste40"), gdjs.TrainingLevelCode.GDwaste40Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste5"), gdjs.TrainingLevelCode.GDwaste5Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste6"), gdjs.TrainingLevelCode.GDwaste6Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);
gdjs.copyArray(runtimeScene.getObjects("waste9"), gdjs.TrainingLevelCode.GDwaste9Objects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDwaste1Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste2Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste3Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste4Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste5Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste6Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste7Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste8Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste9Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste10Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste11Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste12Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste13Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste14Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste15Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste17Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste18Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste19Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste16Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste20Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste21Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste22Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste23Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste24Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste25Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste26Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste27Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste29Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste30Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste31Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste32Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste33Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste34Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste35Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste36Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste37Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste38Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste39Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste40Objects1ObjectsGDgdjs_46TrainingLevelCode_46GDwaste28Objects1Objects, gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDCleanButtonObjects1Objects, false, runtimeScene, false);
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste1Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste10Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste11Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste12Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste13Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste14Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste15Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste16Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste17Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste18Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste19Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste2Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste20Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste21Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste22Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste23Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste24Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste25Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste26Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste27Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste28Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste29Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste3Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste30Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste31Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste32Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste33Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste34Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste35Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste36Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste37Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste38Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste39Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste4Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste40Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste5Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste6Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste7Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste8Objects1 */
/* Reuse gdjs.TrainingLevelCode.GDwaste9Objects1 */
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste1Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste2Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste3Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste4Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste5Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste6Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste9Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste9Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste10Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste10Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste11Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste11Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste12Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste12Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste13Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste13Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste14Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste14Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste15Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste15Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste17Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste17Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste18Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste18Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste19Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste19Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste16Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste16Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste20Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste20Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste21Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste21Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste22Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste22Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste23Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste23Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste24Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste24Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste25Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste25Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste26Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste26Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste30Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste30Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste32Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste32Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste33Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste33Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste34Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste34Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste35Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste35Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste36Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste36Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste37Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste37Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste38Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste38Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste39Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste39Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste40Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste40Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste28Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste28Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).sub(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CleanButton"), gdjs.TrainingLevelCode.GDCleanButtonObjects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrainingLevelCode.mapOfGDgdjs_46TrainingLevelCode_46GDCleanButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.TrainingLevelCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste31"), gdjs.TrainingLevelCode.GDwaste31Objects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste31Objects1.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste31Objects1[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste31Objects1[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_0.val = true;
        gdjs.TrainingLevelCode.GDwaste31Objects1[k] = gdjs.TrainingLevelCode.GDwaste31Objects1[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste31Objects1.length = k;}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste31Objects1 */
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste31Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste31Objects1[i].setAnimationName("Clean");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste29"), gdjs.TrainingLevelCode.GDwaste29Objects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste29Objects1.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste29Objects1[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste29Objects1[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_0.val = true;
        gdjs.TrainingLevelCode.GDwaste29Objects1[k] = gdjs.TrainingLevelCode.GDwaste29Objects1[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste29Objects1.length = k;}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste29Objects1 */
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste29Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste29Objects1[i].setAnimationName("Clean");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste27"), gdjs.TrainingLevelCode.GDwaste27Objects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste27Objects1.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste27Objects1[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste27Objects1[i].getVariables().get("Clean")) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_0.val = true;
        gdjs.TrainingLevelCode.GDwaste27Objects1[k] = gdjs.TrainingLevelCode.GDwaste27Objects1[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste27Objects1.length = k;}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste27Objects1 */
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste27Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste27Objects1[i].setAnimationName("Clean");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste8"), gdjs.TrainingLevelCode.GDwaste8Objects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste8Objects1.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste8Objects1[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste8Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_0.val = true;
        gdjs.TrainingLevelCode.GDwaste8Objects1[k] = gdjs.TrainingLevelCode.GDwaste8Objects1[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste8Objects1.length = k;}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste8Objects1 */
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste8Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste8Objects1[i].setAnimationName("Clean");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("waste7"), gdjs.TrainingLevelCode.GDwaste7Objects1);

gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TrainingLevelCode.GDwaste7Objects1.length;i<l;++i) {
    if ( gdjs.TrainingLevelCode.GDwaste7Objects1[i].getVariableNumber(gdjs.TrainingLevelCode.GDwaste7Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.TrainingLevelCode.condition0IsTrue_0.val = true;
        gdjs.TrainingLevelCode.GDwaste7Objects1[k] = gdjs.TrainingLevelCode.GDwaste7Objects1[i];
        ++k;
    }
}
gdjs.TrainingLevelCode.GDwaste7Objects1.length = k;}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrainingLevelCode.GDwaste7Objects1 */
{for(var i = 0, len = gdjs.TrainingLevelCode.GDwaste7Objects1.length ;i < len;++i) {
    gdjs.TrainingLevelCode.GDwaste7Objects1[i].setAnimationName("Clean");
}
}}

}


{



}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("UserScore").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}
{ //Subevents
gdjs.TrainingLevelCode.eventsList15(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.TrainingLevelCode.condition0IsTrue_0.val = false;
{
gdjs.TrainingLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrainingLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.TrainingLevelCode.eventsList18(runtimeScene);} //End of subevents
}

}


};

gdjs.TrainingLevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TrainingLevelCode.GDPlasticBoxObjects1.length = 0;
gdjs.TrainingLevelCode.GDPlasticBoxObjects2.length = 0;
gdjs.TrainingLevelCode.GDPlasticBoxObjects3.length = 0;
gdjs.TrainingLevelCode.GDPlasticBoxObjects4.length = 0;
gdjs.TrainingLevelCode.GDGlassBoxObjects1.length = 0;
gdjs.TrainingLevelCode.GDGlassBoxObjects2.length = 0;
gdjs.TrainingLevelCode.GDGlassBoxObjects3.length = 0;
gdjs.TrainingLevelCode.GDGlassBoxObjects4.length = 0;
gdjs.TrainingLevelCode.GDPaperBoxObjects1.length = 0;
gdjs.TrainingLevelCode.GDPaperBoxObjects2.length = 0;
gdjs.TrainingLevelCode.GDPaperBoxObjects3.length = 0;
gdjs.TrainingLevelCode.GDPaperBoxObjects4.length = 0;
gdjs.TrainingLevelCode.GDOtherBoxObjects1.length = 0;
gdjs.TrainingLevelCode.GDOtherBoxObjects2.length = 0;
gdjs.TrainingLevelCode.GDOtherBoxObjects3.length = 0;
gdjs.TrainingLevelCode.GDOtherBoxObjects4.length = 0;
gdjs.TrainingLevelCode.GDScoreObjects1.length = 0;
gdjs.TrainingLevelCode.GDScoreObjects2.length = 0;
gdjs.TrainingLevelCode.GDScoreObjects3.length = 0;
gdjs.TrainingLevelCode.GDScoreObjects4.length = 0;
gdjs.TrainingLevelCode.GDArmObjects1.length = 0;
gdjs.TrainingLevelCode.GDArmObjects2.length = 0;
gdjs.TrainingLevelCode.GDArmObjects3.length = 0;
gdjs.TrainingLevelCode.GDArmObjects4.length = 0;
gdjs.TrainingLevelCode.GDPrevObjects1.length = 0;
gdjs.TrainingLevelCode.GDPrevObjects2.length = 0;
gdjs.TrainingLevelCode.GDPrevObjects3.length = 0;
gdjs.TrainingLevelCode.GDPrevObjects4.length = 0;
gdjs.TrainingLevelCode.GDStarObjects1.length = 0;
gdjs.TrainingLevelCode.GDStarObjects2.length = 0;
gdjs.TrainingLevelCode.GDStarObjects3.length = 0;
gdjs.TrainingLevelCode.GDStarObjects4.length = 0;
gdjs.TrainingLevelCode.GDBackGroundObjects1.length = 0;
gdjs.TrainingLevelCode.GDBackGroundObjects2.length = 0;
gdjs.TrainingLevelCode.GDBackGroundObjects3.length = 0;
gdjs.TrainingLevelCode.GDBackGroundObjects4.length = 0;
gdjs.TrainingLevelCode.GDLeftBoxObjects1.length = 0;
gdjs.TrainingLevelCode.GDLeftBoxObjects2.length = 0;
gdjs.TrainingLevelCode.GDLeftBoxObjects3.length = 0;
gdjs.TrainingLevelCode.GDLeftBoxObjects4.length = 0;
gdjs.TrainingLevelCode.GDRightBoxObjects1.length = 0;
gdjs.TrainingLevelCode.GDRightBoxObjects2.length = 0;
gdjs.TrainingLevelCode.GDRightBoxObjects3.length = 0;
gdjs.TrainingLevelCode.GDRightBoxObjects4.length = 0;
gdjs.TrainingLevelCode.GDCleanButtonObjects1.length = 0;
gdjs.TrainingLevelCode.GDCleanButtonObjects2.length = 0;
gdjs.TrainingLevelCode.GDCleanButtonObjects3.length = 0;
gdjs.TrainingLevelCode.GDCleanButtonObjects4.length = 0;
gdjs.TrainingLevelCode.GDwaste1Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste1Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste1Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste1Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste2Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste2Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste2Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste2Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste3Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste3Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste3Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste3Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste4Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste4Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste4Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste4Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste5Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste5Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste5Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste5Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste6Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste6Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste6Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste6Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste7Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste7Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste7Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste7Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste8Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste8Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste8Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste8Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste9Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste9Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste9Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste9Objects4.length = 0;
gdjs.TrainingLevelCode.GDSpeedValueObjects1.length = 0;
gdjs.TrainingLevelCode.GDSpeedValueObjects2.length = 0;
gdjs.TrainingLevelCode.GDSpeedValueObjects3.length = 0;
gdjs.TrainingLevelCode.GDSpeedValueObjects4.length = 0;
gdjs.TrainingLevelCode.GDwaste10Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste10Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste10Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste10Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste11Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste11Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste11Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste11Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste12Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste12Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste12Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste12Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste13Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste13Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste13Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste13Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste14Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste14Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste14Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste14Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste15Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste15Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste15Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste15Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste17Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste17Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste17Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste17Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste16Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste16Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste16Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste16Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste18Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste18Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste18Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste18Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste19Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste19Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste19Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste19Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste20Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste20Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste20Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste20Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste21Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste21Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste21Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste21Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste22Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste22Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste22Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste22Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste23Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste23Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste23Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste23Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste24Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste24Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste24Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste24Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste25Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste25Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste25Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste25Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste26Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste26Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste26Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste26Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste27Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste27Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste27Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste27Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste29Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste29Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste29Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste29Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste28Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste28Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste28Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste28Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste30Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste30Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste30Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste30Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste31Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste31Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste31Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste31Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste32Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste32Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste32Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste32Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste33Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste33Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste33Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste33Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste34Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste34Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste34Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste34Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste35Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste35Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste35Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste35Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste36Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste36Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste36Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste36Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste37Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste37Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste37Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste37Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste38Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste38Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste38Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste38Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste39Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste39Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste39Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste39Objects4.length = 0;
gdjs.TrainingLevelCode.GDwaste40Objects1.length = 0;
gdjs.TrainingLevelCode.GDwaste40Objects2.length = 0;
gdjs.TrainingLevelCode.GDwaste40Objects3.length = 0;
gdjs.TrainingLevelCode.GDwaste40Objects4.length = 0;
gdjs.TrainingLevelCode.GDSoundObjects1.length = 0;
gdjs.TrainingLevelCode.GDSoundObjects2.length = 0;
gdjs.TrainingLevelCode.GDSoundObjects3.length = 0;
gdjs.TrainingLevelCode.GDSoundObjects4.length = 0;
gdjs.TrainingLevelCode.GDSpeedObjects1.length = 0;
gdjs.TrainingLevelCode.GDSpeedObjects2.length = 0;
gdjs.TrainingLevelCode.GDSpeedObjects3.length = 0;
gdjs.TrainingLevelCode.GDSpeedObjects4.length = 0;
gdjs.TrainingLevelCode.GDLifeObjects1.length = 0;
gdjs.TrainingLevelCode.GDLifeObjects2.length = 0;
gdjs.TrainingLevelCode.GDLifeObjects3.length = 0;
gdjs.TrainingLevelCode.GDLifeObjects4.length = 0;

gdjs.TrainingLevelCode.eventsList19(runtimeScene);
return;

}

gdjs['TrainingLevelCode'] = gdjs.TrainingLevelCode;
